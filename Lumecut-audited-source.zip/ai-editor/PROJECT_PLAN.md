# Build Plan & Status

Each stage lands as a stable, runnable increment. We do not start a stage until the
previous one is confirmed working.

| Stage | Scope | Status |
|-------|-------|--------|
| 1 | Architecture, folder structure, tooling, env config | ✅ **This delivery** |
| 2 | Home screen, bottom navigation, project creation flow | ✅ **This delivery** |
| 3 | Photo editor (crop/rotate/filters/adjust/text/stickers/draw) | ✅ **This delivery** |
| 4 | Video editor (timeline, clips, trim/split, transitions, aspect ratios) | ✅ **This delivery** |
| 5 | AI tools — real integrations: remove.bg (Background Removal), DeepAI torch-srgan (Photo Enhancement), OpenAI (Script Generator) | ✅ **PASS** |
| 6 | Export engine — real server-side FFmpeg pipeline (MP4, audio, 8K path) | 🟡 **PARTIAL — 2 real bugs found+fixed in full audit, builds still blocked by sandbox network, see STAGE6_VERIFICATION.md** |
| 7 | Ad monetization (AdMob abstraction: banner/interstitial/rewarded) | ⬜ Not started |
| 8 | Premium/subscription architecture + entitlement system | ⬜ Not started |
| 9 | Auth, database, cloud storage | ⬜ Not started |
| 10 | Testing + performance optimization | ⬜ Not started |
| 11 | Capacitor Android configuration | ⬜ Not started |
| 12 | Production build & release prep | ⬜ Not started |

## Stage 1 deliverables (this commit)

- Monorepo structure: `web/`, `server/`, `android/` (placeholder), `config/`
- `web/`: Vite + React + TypeScript scaffold, path-based feature folders, ESLint,
  a placeholder root page proving the toolchain builds and runs
- `server/`: Express + TypeScript scaffold, `/api/health` route, layered folders for
  `api/`, `services/{ai,video,auth,payments,ads}/`, `middleware/`, `config/`
- `.env.example` for both `web/` and `server/` documenting every environment variable
  the full spec will eventually need, grouped by which stage introduces it
- `config/app.config.json` — shared, non-secret app configuration (plan names, feature
  flags placeholders) that both frontend and backend can read from at build time
- `.gitignore`, root `README.md`, this plan file

## Stage 2 deliverables (this commit)

- Client-side router (`react-router-dom`) with routes for Home, Projects, AI Tools,
  Profile, Premium, and `/editor/:projectId`
- `BottomNav` (Home / Projects / AI Tools / Profile, per spec §11), hidden on the
  editor route since that needs the full screen (spec §12)
- `ProjectsProvider` — in-memory project store for this session (`web/src/state`).
  Deliberately not persisted yet: Stage 9 swaps the internals for real cloud storage
  without changing any call site (`useProjects()`)
- `NewProjectButton` — real device file picker (photo or video), then opens
  `NewProjectDialog` to collect the project name (defaulted from the filename) and
  aspect ratio before creating the project, then navigates into the editor placeholder
- `NewProjectDialog` — name input (editable, defaults to filename without extension)
  and a 9:16 / 16:9 / 1:1 / 4:5 aspect-ratio picker; both are stored on `Project`
  (`Project.name`, `Project.aspectRatio`) for Stage 3/4/6 to read later
- `ProjectsContext.deleteProject(id)` — removes a project and calls
  `URL.revokeObjectURL()` on its preview URL so deleted media doesn't stay pinned in
  memory for the rest of the tab's life
- Home screen sections: logo/status, profile & premium buttons, new-project actions,
  recent projects (real thumbnails via object URLs), AI Tools preview grid, Templates
  preview strip
- Projects screen: full grid of session projects, each with a delete button
  (confirmation via `window.confirm` before removing)
- Editor placeholder: top bar (back/name + aspect ratio/undo/redo/export) + center
  preview (renders the actual picked photo/video) + bottom tool-category chips, laid
  out per spec §12 but every control is disabled/non-functional — real editing logic
  is Stage 3 (photo) and Stage 4 (video). If the open project no longer exists (e.g.
  deleted from the Projects screen, or lost on reload), it shows a clear "not found"
  message with a way back to Home instead of crashing
- AI Tools / Profile / Premium stub screens so navigation has somewhere real to go,
  each stating plainly which later stage implements it

## Stage 2 review fixes (this commit)

A review of the initial Stage 2 delivery found 3 missing requirements from the spec.
Fixed here, nothing else changed:

1. Aspect ratio (9:16 / 16:9 / 1:1 / 4:5) is now selected during project creation and
   stored on `Project.aspectRatio`.
2. Project creation now has a name step, defaulting to the filename without its
   extension, editable before the project is created.
3. Projects can be deleted from the Projects screen, with a confirmation prompt and
   `URL.revokeObjectURL()` cleanup; opening a since-deleted project in the editor shows
   a graceful "not found" message instead of crashing.

## Verifying Stage 2

1. `cd web && npm run dev`
2. Open the app — Home should load with the bottom nav visible
3. Tap **Photo Editor** or **Video Editor**, pick a real file from your device/browser
4. A dialog should appear pre-filled with the filename (no extension) and 9:16
   selected by default — edit the name, try each of the four aspect ratio chips, then
   tap **Create**
5. You should land on the editor placeholder showing your actual photo/video in the
   preview area, with the name and chosen aspect ratio shown in the top bar, and a
   disabled toolbar underneath
6. Go back to Home — your project should appear under Recent Projects with the name
   you gave it
7. Tap **Projects** in the bottom nav — the same project should appear there, showing
   its kind and aspect ratio
8. Tap the delete (🗑) button on a project card — you should get a confirmation
   prompt; confirm it and the card should disappear
9. Create a project, open it in the editor, then delete it from the Projects screen,
   then navigate back into that same editor URL (e.g. via browser back) — it should
   show a "Project not found" message instead of crashing
10. Reload the page — remaining projects should disappear (expected: in-memory only
    until Stage 9) and Home/Projects/AI Tools/Profile should all still navigate
    correctly

## Stage 3 deliverables (this commit)

Decisions locked in for this stage (per explicit direction): Canvas 2D (no Konva/
Fabric), a non-destructive edit-state architecture with real undo/redo, and every
AI-dependent tool built as real UI wired to a clean service interface that is
stubbed — no network calls, no API keys — until Stage 5.

**State & rendering (`web/src/features/photo-editor/`)**
- `types.ts` — `PhotoEditState`: `Adjustments`, `Transform` (rotate/flip/crop/resize),
  `FilterId`, text/sticker `Layer`s, `DrawingStroke`s. All plain data, no pixel
  buffers — this is what makes undo/redo and later persistence cheap
- `history.ts` — generic undo/redo hook, decoupled from photo-specific state so
  Stage 4's video editor can reuse it. Slider drags call `setLive` (visual only) and
  a single `commit` on release, so dragging a slider doesn't flood the undo stack
- `canvasRenderer.ts` — pure render functions from `(canvas, originalImage, state)`.
  Adjustments/filters use Canvas 2D's native `ctx.filter` (brightness/contrast/
  saturate/blur — GPU-composited); the one pixel-level operation (sharpen
  convolution) only runs when sharpness is actually turned on
- `filters.ts` — 8 presets (None, B&W, Sepia, Vintage, Cool, Warm, High Contrast, Fade)
- `cropMath.ts` — aspect-ratio ↔ crop-rect math, reused by both the crop tool and its
  resize-drag constraint

**Tools implemented (all non-destructive, all undoable)**
- Crop: 9:16/16:9/1:1/4:5/Free presets (reusing Stage 2's `ASPECT_RATIOS`) plus
  free-form drag-to-move / drag-to-resize (`CropOverlay.tsx`)
- Rotate (90° steps), Flip (horizontal/vertical)
- Resize: target max dimension (Original/1920/1280/720), stored on `Transform` for
  Stage 6's export pipeline to read
- Adjust: brightness, contrast, saturation, exposure, temperature, sharpness, blur
- Filters: preset picker
- Text: add/edit/remove layers, color + font family, drag to reposition on canvas
- Stickers: emoji picker, drag to reposition on canvas
- Draw: freehand strokes, color + brush size, clear-all with confirmation
- AI panel: Background Remover, Background Replacement, Photo Enhancer, Image
  Upscaler, Object Removal, AI Effects — real buttons, each calls through
  `features/ai/photoAiService.ts`'s interface, which is a stub until Stage 5
  (`setPhotoAiService()` is how Stage 5 swaps in the real implementation without
  touching this UI)

**Wiring**
- `pages/EditorPlaceholder.tsx` now dispatches: photo projects render the real
  `PhotoEditor`; video projects still render the Stage 2 placeholder pending Stage 4
- Top bar Undo/Redo are now real, wired to the history hook; Export stays disabled
  (Stage 6)

## Verifying Stage 3

1. `cd web && npm run dev`, create a **Photo** project
2. **Adjust**: drag each slider — canvas updates live; release and tap Undo — the
   slider (and canvas) should revert in one step, not one step per pixel of drag
3. **Filters**: tap through presets — canvas updates immediately, each tap is one
   undo step
4. **Crop**: tap a ratio chip — overlay recomputes to that shape; drag the rectangle
   to move it, drag the corner handle to resize (should stay locked to the chosen
   ratio); tap **Apply Crop** — canvas shows the cropped result; tap **Crop** again —
   it should reopen showing your applied crop, not a fresh one
5. **Rotate/Flip**: tap each — canvas updates, each is its own undo step
6. **Resize**: tap 720px — canvas re-renders at the lower cap; tap Original to restore
7. **Text**: add text, edit its content/color/font, drag it around the canvas
8. **Stickers**: add a couple, drag them around, remove one via its chip
9. **Draw**: pick a color/size, draw a stroke — it should appear as you drag and
   persist after release; try Clear (with its confirmation)
10. **AI tab**: tap any tool — it should show an "unavailable... Stage 5" message
    inline, with no network request made (check devtools Network tab)
11. Undo repeatedly across several different tools — each should step back through
    exactly the actions you took, in order; Redo should replay them
12. `cd web && npm run build` — should complete without TypeScript errors (see note
    below on sandbox verification limits)

**Note on this delivery's own verification:** this was built and reviewed in a
sandboxed environment without npm registry access, so `npm install`/`npm run build`
could not actually be executed here — the same constraint noted in Stages 1–2. Every
file was manually cross-checked instead: all relative and `@`-alias imports resolve
to real files, every exported hook/type is consumed somewhere, and a real TypeScript
typing bug (`Partial<Layer>` on a union type only exposing shared keys) was caught
and fixed (see `LayerPatch` in `types.ts`) during this review. Please run
`npm run build` on your machine as the authoritative check.

## Stage 4 deliverables (this commit)

Decisions locked in for this stage (per explicit direction): a Canvas 2D compositor
that draws real `<video>` elements' current frames (no manual decoding, no per-frame
pixel extraction); a non-destructive edit-decision-list (EDL) — no client-side
re-encoding, Stage 6's FFmpeg pass consumes this same schema; draft saving via
`ProjectsContext` so edits survive navigating away and back; AI-dependent tools as
real UI wired to a stubbed service interface, matching Stage 3's pattern exactly.

**Relocated (genuinely shared now, not photo-specific)**
- `history.ts` and `filters.ts` moved from `photo-editor/` to `features/shared/`.
  Both were already editor-agnostic; the video editor reuses them as-is rather than
  duplicating. Photo editor's imports were updated; no behavior change.

**State & playback (`web/src/features/video-editor/`)**
- `types.ts` — `VideoEditState`: `VideoClip` (source ref + in/out points + speed/
  reverse/volume/mute/rotation/flip/filter), `Transition`, `TextOverlay`/
  `StickerOverlay`, `Keyframe` (data model only — no interpolation UI yet, per spec's
  "basic keyframe architecture")
- `timelineMath.ts` — `resolvePlayhead()`: the one function that turns "global
  timeline time" into "which clip, what local time in ITS source file" — every
  playback/rendering/scrubbing concern builds on this
- `useClipPlayers.ts` — one real `<video>` element per clip (never attached to the
  DOM — browsers can decode/draw from a detached video element), created/torn down
  as clips are added/removed; the only place clip playback state lives
- `videoCompositor.ts` — `drawImage()`s the active video's current frame onto a
  canvas ("cover"-fit to the project's aspect ratio), plus overlays on top. No
  manual frame decoding, no `getImageData` anywhere in this file
- `useVideoEditor.ts` — wires shared history + ProjectsContext draft-saving sync +
  clip players + the playback loop (rAF-driven, advances a `timelineTimeRef`,
  seeks/plays/pauses the correct clip's video element each tick) + every EDL
  mutation
- `VideoCanvas.tsx` — rAF is the unconditional base redraw driver;
  `requestVideoFrameCallback` layers on top during real forward playback as an
  accuracy booster (manual-scrub reverse/seek can't rely on rVFC firing
  continuously, so correctness never depends on it)

**Tools implemented (all EDL-based, all undoable)**
- Edit: import video (file picker), select/delete clips, reorder (move left/right),
  merge adjacent clips into a non-destructive group, split at playhead, trim in/out
  (numeric fields)
- Audio: per-clip volume + mute (external music/voice-over tracks are a later stage)
- Speed: 0.25x–4x presets; Reverse toggle (previews via manual scrubbing — see below)
- Canvas: rotate 90°/flip per clip; shows the project's fixed output aspect ratio
- Filters: same preset picker as photo (shared module), per clip
- Transitions: Fade/None per clip boundary, with a validated duration; Fade actually
  crossfades in the preview (see Stage 4 review fixes below)
- Text/Stickers: overlays with a start/end time window, drag to reposition on canvas
  while visible
- AI panel: Auto Captions, Subtitle Generation, AI Video Effects, Script Generator,
  Caption Generator — real buttons wired to `features/ai/videoAiService.ts`'s
  interface, stubbed until Stage 5

**Wiring**
- `pages/EditorPlaceholder.tsx` now dispatches photo → `PhotoEditor`, video →
  `VideoEditor`, both with `key={project.id}` — see below
- `ProjectsContext` gained `getVideoEditState`/`setVideoEditState` (draft saving);
  `deleteProject` now also revokes every clip's object URL, not just the project's
  original file

**A latent Stage 3 bug, found and fixed while building this stage:** neither
`PhotoEditor` nor the video editor were keyed by `project.id` in the router.
Navigating directly from one project's editor to a DIFFERENT project's editor (same
route pattern) would reuse the same component instance instead of remounting —
leaking the first project's undo history and (for video) playback state into the
second. Fixed by adding `key={project.id}` to both branches in
`EditorPlaceholder.tsx`. This also makes Stage 4's draft-saving behave correctly
across project switches (each mount reads ITS OWN project's saved EDL fresh).

**Known Stage 4 limitations (accepted trade-offs, not oversights):**
- Reverse playback previews via manually scrubbing `currentTime` rather than true
  reverse decode (HTML5 video has no reliable native reverse) — real reverse
  rendering is Stage 6's job
- A split clip's two halves share the original clip's `sourceUrl` (same file, two
  in/out ranges) rather than each getting an independent decoder — simpler and
  correct, at the cost of a little extra decode overhead if both halves play near
  each other. Object URL lifecycle for this case is handled explicitly — see Stage 4
  review fixes below
- When a freshly-imported clip's video metadata loads, its `outPoint` is patched via
  a `history.commit` — meaning undoing immediately after import can take two steps
  (metadata patch, then the add) instead of one. Cosmetic, not a correctness issue
- Storing video edit state in `ProjectsContext` (as directed, for draft saving) means
  any edit re-renders every context consumer, including Home/Projects screens —
  fine at this app's scale; splitting into a separate context is a cheap follow-up
  if it ever matters
- `addClip`'s async metadata probe reads `state` from its call-time closure; an edit
  landing in the same ~50–200ms window as an in-flight import could theoretically be
  overwritten — ~~very unlikely in single-user interactive use, noted rather than
  engineered around given the shared history hook's current API~~ **fixed — see
  "Final Stage 4 fix" below.**
- The Fade transition preview is a same-timeline-length approximation (plays out
  within the outgoing clip's own last N seconds, blending toward the incoming
  clip's static first frame) rather than true timeline-overlap crossfade — see Stage
  4 review fixes below for why, and why it's the right call for a preview

## Stage 4 review fixes (this commit)

A review of the initial Stage 4 delivery found 5 functional issues. Fixed here,
nothing else changed (no Stage 5 AI, no auth/cloud, no ads/payments, no FFmpeg —
same Canvas 2D + HTMLVideoElement + non-destructive EDL architecture throughout):

**1. Real Merge.** `VideoClip.groupId: string | null` — `mergeClips()`/
`mergeWithNext()` assign a shared groupId to a *contiguous* run of clips (validated;
non-adjacent selections are a no-op), presenting them as one unit: internal
transitions between merged members are cleared, the Timeline renders them edge-to-
edge with a 🔗 indicator, and `unmergeGroup()` reverses it. Every clip keeps its own
`sourceUrl`/`inPoint`/`outPoint`/edit decisions — nothing is re-encoded or
physically combined, so Stage 6's FFmpeg renderer can treat consecutive
same-`groupId` clips as one deterministic concatenated segment using each clip's own
trim/speed/reverse as-is. Splitting a clip clears its `groupId` (a split piece is no
longer "the same unit"). All merge/unmerge mutations go through the same
`history.commit` path as every other edit, so Undo/Redo works automatically.

**2. Fade transition now affects the preview.** `timelineMath.ts` gained
`resolveTransitionBlend()`: for the *outgoing* clip's last `transition.duration`
seconds, it returns which two clips to blend and an alpha (0→1). `videoCompositor.ts`
gained `drawTransitionFrame()` (draws both clips' current frames at complementary
alpha, no clear between them) and a separated `drawOverlays()` (so overlays aren't
duplicated by the two-layer draw). `VideoCanvas` checks `editor.transitionBlend` each
tick and draws the blend instead of a single frame when active.
`useVideoEditor.syncPlayingClip`/`seek` both prime the incoming clip (paused, seeked
to its first frame, silenced) so it has a real frame ready to draw. **Design choice,
stated plainly:** this is a same-timeline-length approximation — the fade plays
inside the outgoing clip's own last N seconds rather than truly overlapping two
clips' durations (which would require changing `resolvePlayhead`/
`computeTotalTimelineDuration` and everything built on them). That's a deliberate
scope decision for a *preview*, documented in `timelineMath.ts`; Stage 6's real
crossfade render can implement true overlap. **Duration validation:**
`setTransition()` now clamps duration to `min(outgoing clip's timeline duration,
incoming clip's timeline duration) - MIN_CLIP_DURATION`, with a 0.1s floor;
`TransitionsPanel` shows a duration input (only when Fade is selected) with the live
max displayed.

**3. Object-URL lifecycle fixed for Undo/Redo.** This was a real bug: `removeClip`
used to call `URL.revokeObjectURL()` immediately, but the undo/redo stack lives
entirely in `useHistoryState`'s refs, local to the mounted hook — so hitting Undo
after a delete would restore a clip whose blob URL was already revoked, and its
`<video>` element would fail to (re)load. Fixed with a session-scoped deferred model:
`useVideoEditor` now tracks every `sourceUrl` it has ever used
(`usedUrlsRef`), and on **unmount only** (when the local undo/redo stack is
guaranteed gone) revokes whichever of those URLs are no longer in the final saved
state. No individual mutation revokes anything anymore. Split clips sharing a
`sourceUrl` are handled correctly for free by this design — the URL stays live as
long as ANY current clip still references it, checked by value, not by clip id.
`ProjectsContext.deleteProject` (a separate, final action, and the one place that
still revokes immediately) now has a comment explaining why that's safe: this app's
navigation model guarantees the editor for a project is already unmounted (and has
already run its own deferred cleanup) by the time that project can be deleted.

**4. Mobile playback reliability.** `play()` now calls `.play()` on the active
clip's `<video>` element **synchronously**, inside the same call stack as the Play
button's `onClick` — not deferred to a later `requestAnimationFrame` tick. Mobile
browsers (notably iOS Safari) require `.play()` to originate directly from a user
gesture for audio-enabled playback to be allowed; the rAF loop was breaking that
chain for the *first* call. The rAF loop still owns ongoing sync/drift-correction/
clip-boundary transitions once playback is underway. Rejection is now caught
(`.catch(err => console.warn(...))`) instead of surfacing as an unhandled promise
rejection. **Bonus fix found in the same area:** the "stop playing" path (both the
explicit `pause()` and the `isPlaying` effect's cleanup) was cancelling our own rAF
loop but never actually calling `.pause()` on the video element — meaning audio/
video could keep playing natively after the UI said "paused". Both paths now
explicitly pause the active clip's element.

**5. Reverse + Split fixed.** `splitAtPlayhead` used to apply the same
inPoint/outPoint pairing regardless of `reversed`, which is wrong: reversed playback
runs from `outPoint` DOWN to `inPoint`, so the piece that plays FIRST on the timeline
after a split is the one covering `[sourceTime, outPoint]` — the opposite pairing
from a forward clip. Fixed with an explicit branch for `clip.reversed`; both
resulting clips always satisfy `outPoint > inPoint` (guaranteed by the existing
too-close-to-an-edge guard, which is direction-agnostic) and both preserve
`reversed: true`. Goes through the same `history.commit` as before, so Undo/Redo is
unchanged/still correct.

## Final Stage 4 fix: addClip async stale-state race

One more real bug found on final review: `addClip` read `state` from the closure it
was called with, then committed a new clips array built from that same closured
`state` *after* an `await` (probing the imported file's duration). If a second
`addClip` call was made before the first resolved — genuinely likely, since probing
takes anywhere from a few milliseconds to noticeably longer depending on file
size/decoder — both calls could read the SAME pre-await `state.clips`, and whichever
committed second would silently overwrite the first's import instead of appending
after it.

**Fix:** `useVideoEditor` now keeps a `latestStateRef`, updated **synchronously**
by a new `commitState()` wrapper at the exact moment of every commit (not just on
each render, which would still leave a gap between two back-to-back async
resolutions). Every existing `history.commit(...)` call site now goes through
`commitState(...)` instead — a pure rename with no behavior change for every
synchronous mutation (they never had this race; only `addClip` has an `await` in the
middle). `addClip` itself now builds its new clips array from
`latestStateRef.current` — always the true latest state, including any other import
that already completed — instead of the stale closured `state`.

**Insertion order policy (documented, deterministic):** each import is appended in
the order its OWN probe resolves, not the order the user started the imports in.
This is a deliberate, simple choice: fully deterministic given a sequence of
completions (no ambiguity, no lost updates, no partial application — see
`addClip`'s doc comment in the source), at the cost of not necessarily matching
initiation order if one file's metadata probe happens to resolve slower than one
started after it. Matching initiation order exactly would require tracking a
sequence number per pending import and inserting at a computed position rather than
appending — meaningfully more complexity for a difference users are unlikely to
notice in practice (imports typically resolve in well under a second, in
practice-indistinguishable order).

This also incidentally tightened the object-URL lifecycle fix from the previous
round: the old `latestClipsRef` (updated only at render time) is now replaced by
the more broadly useful `latestStateRef` (updated at both commit time AND render
time), so the unmount cleanup effect is, if anything, slightly more robust than
before — same behavior, strictly fresher data source. Undo/Redo is untouched:
`commitState` calls the exact same `history.commit` as before, just with a
ref-update alongside it.

## Verifying Stage 4

**New: verifying the addClip fix specifically**
1. Prepare 2-3 short video files
2. In the Edit panel, tap "Import video" and pick the first, then — WITHOUT waiting
   — tap "Import video" again and pick a second (and a third if you're quick enough)
3. All imported clips should end up on the timeline — none should be missing or
   silently replaced by another
4. Undo repeatedly — each import should un-appear one at a time, in reverse of
   whatever order they actually landed in
5. Redo — they should reappear in the same order

 (updated for the review fixes)

1. `cd web && npm run dev`, create a **Video** project
2. Preview should show your video's actual first frame; tap play — it should play
   smoothly **and with audio** immediately (not just after scrubbing); scrub the
   timeline while paused — the frame should update immediately
3. Tap Play, then Pause quickly — audio/video should actually stop, not keep playing
   silently in the background
4. **Edit**: import a second video — it should appear as a second block on the
   timeline; tap between the two clips during playback and confirm playback
   continues seamlessly across the boundary
5. Select a clip, **Merge with next** — the two blocks should render edge-to-edge
   with a 🔗 marker; select either and confirm **Unmerge** splits them apart again on
   the timeline; Undo should reverse a merge, Redo should reapply it
6. Select a clip, **Split at playhead** partway through it — should become two
   blocks; trim one via the in/out number fields — its timeline block should resize
7. **Reverse + Split**: reverse a clip, scrub to confirm it plays backwards, then
   split it at the playhead — both resulting pieces should still be marked reversed,
   play correctly in reverse, and neither should show a broken/zero-length trim
8. **Speed**: set a clip to 2x — its timeline block should visibly shrink; 0.5x —
   block grows
9. **Audio**: mute a clip, play across it — should be silent; adjust volume on
   another
10. **Canvas**: rotate/flip a clip — preview updates for that clip's portion only
11. **Filters**: apply a filter to one clip only — preview shows it only while that
    clip is active
12. **Transitions**: set Fade on a boundary with two clips present — play across the
    boundary and confirm the preview actually crossfades rather than hard-cutting;
    try setting a very large duration and confirm it gets clamped (check the "max"
    label in the panel)
13. **Undo/Redo + URLs**: delete a clip, then hit Undo — the clip should reappear
    AND its video preview should still load/play correctly (not broken/black) —
    this is the object-URL lifecycle fix; delete it again and leave it deleted, then
    navigate to Home and back into a few other projects (to encourage the deleted
    clip's URL to actually get revoked on unmount) — no errors should appear
14. **Text/Stickers**: add one, set its time window, confirm it only appears on
    canvas during that window; drag it while visible
15. **AI tab**: tap any tool — "unavailable... Stage 5" message, no network request
16. Undo/redo across several different edit types (including merge and split) — each
    should step back precisely
17. Navigate to Home, back into the SAME project — all your edits should still be
    there (draft saving), including any merge groups
18. Create a SECOND video project, open its editor directly from Home (not via this
    one) — it should start fresh, with no leakage from the first project's edits
19. `cd web && npm run build` — should complete without TypeScript errors (see the
    sandbox verification note below)

**Note on this delivery's own verification:** same sandbox constraint as every prior
stage — no npm registry access here, so `npm install`/`npm run build` couldn't
actually be run. This stage involved more intricate closure/effect-dependency logic
than Stages 1–3 (a real-time playback loop, two render loops coordinating via a
shared video element, and now a crossfade blend reading two video elements at once);
I found and fixed two genuine bugs during the original manual review before
finalizing, and this round of fixes addresses five more found in your review:
1. `VideoCanvas`'s render loop initially closed over `editor` directly in its effect
   dependency array, which would have either (a) restarted the rAF/rVFC loop every
   single render (defeating rVFC entirely, since it'd be cancelled before ever
   firing), or (b) if narrowed naively, gone stale on filter/rotation/overlay edits
   to the same active clip. Fixed with an `editorRef` updated every render, read
   fresh from inside the draw callback, while the effect's own dependencies stay
   narrow (`isPlaying`, active clip id, aspect ratio).
2. `updateLayer`'s Stage 3 equivalent issue (`Partial<Layer>` losing keys on a union
   type) does NOT recur here since `VideoClip` is a single interface, not a union —
   confirmed `Partial<VideoClip>` is used correctly for `updateClip`.
3. (This round) `removeClip`'s immediate `URL.revokeObjectURL()` would have broken
   Undo — see fix #3 above. Caught by re-tracing the object URL's lifecycle against
   the undo/redo stack's actual lifetime, not just against the current render's state.

After this round of fixes: every `editor.<method>` call across all video-editor UI
files was re-checked against the hook's actual return object (`mergeClips`,
`mergeWithNext`, `unmergeGroup`, `transitionBlend` all confirmed present and
correctly wired); every import (relative and `@`-alias) was re-verified to resolve;
a full project-wide sweep found no unused imports.

**Final fix (this commit):** the `addClip` async stale-state race described above —
see "Final Stage 4 fix" for the full writeup. Re-ran the same import-resolution and
unused-import sweeps plus the `editor.<method>` cross-check after this change; all
clean.

Please run `npm run build` and the walkthrough above on your machine as the
authoritative check.

## Stage 5 deliverables (this commit)

> **Superseded by "Stage 5 upgrade: real provider integrations" below.** This
> section is kept as a historical record of the initial architecture-first pass;
> `httpProvider.ts` and the generic `AI_PROVIDER_API_KEY`/`AI_PROVIDER_BASE_URL`
> vars it describes were deleted and replaced with three real, independently
> documented provider adapters. Read this for the original scope decisions and
> the blob-URL architectural fix (both still accurate); read the upgrade section
> for what actually calls real AI today.

Decisions locked in for this stage (per explicit direction, no answer came through
so these are the defaults used — flagged clearly at the time): a mock provider as
the default (clearly labeled, no real processing, no network calls) plus a generic
real HTTP adapter that activates once `AI_PROVIDER_API_KEY`/`AI_PROVIDER_BASE_URL`
are configured; a simple in-memory per-session usage counter (no real accounts
yet); a representative subset of 3 AI tools built fully end-to-end rather than all
~11 stub panels at once.

**A real architectural gap, found and solved before any of this could work:**
every uploaded photo/video only ever existed as a browser-local `blob:` object URL
(from Stage 2's file picker) — which a Node backend cannot fetch; blob URLs are
private to the tab that created them. Fixed by having the frontend re-fetch its
OWN blob URL (works fine client-side, same tab) to get real bytes, then upload
those bytes to the backend as `multipart/form-data`. This is why `photoAiService`'s
real implementation looks different from a simple "pass the URL to the backend"
call — see `blobUrlToBlob()` in that file. **This fix is still in place and still
accurate** — only the provider layer below it changed.

**Backend (`server/src/`) — as originally built (see supersede note above)**
- `services/ai/types.ts` — the `AiProvider` interface every implementation
  fulfills; routes call only this, never a concrete provider class
- `services/ai/mockProvider.ts` — `MockAiProvider`, clearly labeled dev mock: image
  methods pass bytes straight through, the script method returns a canned outline
  prefixed `[MOCK SCRIPT — no real AI provider is configured]`. Active by default
- ~~`services/ai/httpProvider.ts` — `HttpAiProvider`~~ **deleted in the upgrade
  below** — it was a generic invented contract, replaced by three real adapters
- `services/ai/index.ts` — picks mock vs. real once at startup, logs which
- `middleware/usageLimiter.ts` — in-memory per-anonymous-session request cap (5
  requests, shared across all AI routes), explicitly temporary until Stages 8/9
  add real accounts/entitlements
- `middleware/validateUpload.ts` — `multer`-based image upload validation (10MB
  cap, image-mimetype-only, in-memory storage — no disk writes, no cloud storage
  yet). **One new dependency added** (`multer` + `@types/multer`) — justified: no
  equivalent exists in vanilla Express for real multipart file handling, and it's
  the standard, minimal choice for this exact need
- `api/ai.ts` — `POST /api/ai/photo/remove-background`, `POST /api/ai/photo/enhance`
  (multipart image in, `data:` URL out — no persistent storage needed yet since the
  result is returned inline), `POST /api/ai/video/script` (JSON prompt in, JSON
  text out)

**Frontend**
- `web/src/services/sessionId.ts` — anonymous session id in localStorage for the
  usage-limiter header (not a security credential, explicitly documented as such)
- `features/ai/photoAiService.ts` — `BackendPhotoAiService` now the default active
  implementation: `removeBackground`/`enhance` make real calls (fetch own blob →
  upload → render `resultUrl`); `replaceBackground`/`upscale`/`applyEffect` return
  a clear "not part of this stage" result. `StubPhotoAiService` kept, exported, for
  reference/testing
- `features/ai/videoAiService.ts` — `BackendVideoAiService` now default:
  `generateScript` makes a real call; the rest report "not part of this stage".
  `AiJobResult` gained an optional `text` field for text-shaped results
- `features/photo-editor/toolbars/AiToolsPanel.tsx` — now shows a real "Processing…"
  state and renders the returned image inline (previously just a status string)
- `features/video-editor/toolbars/AiToolsPanel.tsx` — Script Generator gained a
  prompt input and renders the returned script text; other tools unchanged

**Scope note:** 3 of ~11 AI tools from Stages 3/4's panels are wired end-to-end
(Background Remover, Photo Enhancer, Script Generator) — chosen to cover both
request shapes the architecture needs (image-upload-in/image-out, text-in/text-out).
The rest stay stubbed with a message naming which wired tool to follow as a
template; wiring any of them up is: one method in `services/ai/types.ts` + both
provider implementations, one route in `api/ai.ts`, one case in the matching
frontend `Backend*AiService`.

## Verifying Stage 5

1. `cd server && npm install && npm run dev` — console should log
   `[ai] No AI provider configured — using MockAiProvider...`
2. `cd web && npm run dev`, open a **Photo** project, go to the AI tab
3. Tap **Background Remover** — should show "Processing…" then display the
   (unchanged, since it's the mock) image back, proving the full upload → backend
   → response → render round trip works
4. Tap **Photo Enhancer** — same
5. Tap one of the other photo AI tools (e.g. Object Removal) — should immediately
   show the "not part of this stage" message, no network request (check devtools)
6. Open a **Video** project, go to the AI tab, type something in the Script
   Generator's prompt field, tap Generate — should show "Processing…" then render
   a canned script mentioning your prompt text, clearly labeled as a mock
7. Tap any other video AI tool — "not part of this stage" message, no request
8. In devtools Network tab, confirm the AI requests go to `/api/ai/...` on your
   local backend — never directly to any third-party AI provider domain
9. Trigger 6 AI requests in a row (any mix of the 3 wired tools) within the same
   browser session — the 6th should get an "Insufficient AI credits" error
   (429), demonstrating the usage limiter
10. To test a real provider path: set `REMOVE_BG_API_KEY` (or `DEEPAI_API_KEY` or
    `OPENAI_API_KEY`) in `server/.env` to a real key from that provider, restart
    the server, confirm the startup log shows that capability as `real` instead
    of `mock`, then re-run steps 3/4/6 with a real image/prompt and confirm you
    get an actual (non-mock, non-passthrough) result
11. `cd server && npm run build` and `cd web && npm run build` — both should
    complete without TypeScript errors (see sandbox verification note below)

**Note on this delivery's own verification:** same sandbox constraint as every
prior stage — no npm registry access here, so `npm install`/`npm run build`
couldn't actually be run for either package (this stage adds `multer` as a new
dependency specifically, so this matters more than usual — please make sure
`npm install` in `server/` succeeds on your machine before testing). I did a full
manual pass instead: every relative import in `server/src` confirmed to use the
`.js` extension NodeNext resolution requires; every import (relative and
`@`-alias) across `web/src` re-verified to resolve; a full project-wide sweep
(both packages) found no unused imports. See "Stage 5 upgrade" below for the
follow-up round that replaced the generic mock-only provider with real,
individually-documented integrations, and for exactly what I could and couldn't
verify without a live key or network access.

Please run both builds and the walkthrough above on your machine as the
authoritative check.

## Stage 5 upgrade: real provider integrations — ✅ PASS (confirmed)

The initial Stage 5 delivery had the right architecture but shipped with
`MockAiProvider` as the only implementation — no tool was actually doing AI
processing. This upgrade replaces that with three genuinely real, independently
verified integrations, one per tool, each implementing that specific provider's
own documented API — not one invented generic contract.

**Providers chosen and verified against current official documentation (web
search, not just training memory) before writing any code:**

| Tool | Provider | Verified contract |
|---|---|---|
| Background Removal | [remove.bg](https://www.remove.bg/api) | `POST /v1.0/removebg`, `X-Api-Key` header, multipart `image_file` field, binary image response on success, `{ errors: [{ title }] }` JSON on failure (400/402/403/429/500) |
| Photo Enhancer | [DeepAI](https://deepai.org/docs) `torch-srgan` | `POST /api/torch-srgan`, `api-key` header, multipart `image` field, `{ id, output_url }` JSON response — result bytes fetched from `output_url` in a second request |
| Script Generator | [OpenAI Chat Completions](https://platform.openai.com/docs/api-reference/chat) | `POST /v1/chat/completions`, `Authorization: Bearer` header, JSON `{ model, messages }`, `{ choices: [{ message: { content } }] }` response, `{ error: { message } }` on failure |

**Why three different providers instead of one:** background removal, image
super-resolution, and text generation are three different AI capabilities with
no common real-world API — the original generic `HttpAiProvider` (deleted in
this upgrade) was exactly the kind of invented contract this round was asked to
replace. `services/ai/types.ts` now splits `AiProvider` into three small
capability interfaces (`BackgroundRemovalProvider`, `PhotoEnhanceProvider`,
`ScriptProvider`) combined into the one interface routes still depend on;
`services/ai/index.ts` assembles it from whichever real adapters have a
configured key, falling back to `MockAiProvider` **independently per
capability** — configuring only `REMOVE_BG_API_KEY`, for example, gives real
background removal while the other two stay mocked, with zero code changes
needed anywhere else.

**Configuration** (`server/.env.example`, updated): `REMOVE_BG_API_KEY`,
`DEEPAI_API_KEY`, `OPENAI_API_KEY` (+ optional `OPENAI_MODEL`, defaults to
`gpt-4o-mini` in code). All optional and independent; unset = mock for that one
capability. Replaces the old generic `AI_PROVIDER`/`AI_PROVIDER_API_KEY`/
`AI_PROVIDER_BASE_URL`, which is gone along with `httpProvider.ts`.

**Security hardening added in this pass:**
- Upload validation now checks actual file content, not just the client-supplied
  MIME type: `middleware/validateUpload.ts` gained `sniffImageMimeType()`, which
  checks each format's magic-number file signature (PNG/JPEG/WEBP/GIF) directly
  against the uploaded bytes. The client-supplied MIME type (like a filename
  extension) is metadata the client controls, not verified content — routes now
  reject uploads whose actual bytes don't match a real image format
- Every provider call has a request timeout (`AbortController`, 30s for
  remove.bg/OpenAI, 60s for DeepAI since it's two round trips), surfaced as a
  clear "timed out, please try again" message instead of hanging
- Route error handling (`handleAiError` in `api/ai.ts`) now returns **502** (a
  more accurate status for "our backend, acting as a gateway, got a bad
  response from an upstream service") with the sanitized message from whichever
  provider adapter threw it, and logs that same message server-side — never the
  request body, image bytes, or prompt text, and never a key value (confirmed by
  reading every `console.log`/`console.error` call added or touched this round)
- Every `describe*Error()` helper in the three provider files reads only the
  **provider's response** — never our own outgoing request — so there is no code
  path by which our API key could end up in a message shown to the user

**What stayed exactly as before (per explicit instruction):** `MockAiProvider`
unchanged and still the fallback; the per-session usage limiter unchanged; the
`AiProvider` abstraction routes depend on unchanged in shape (still
`removeBackground`/`enhancePhoto`/`generateScript`); no auth, no Firebase/
Supabase, no ads/payments, no FFmpeg, no Stage 6 export; no photo/video editor
architecture touched.

**What I could not verify myself without a live key or network access:** I do
not have API keys for remove.bg, DeepAI, or OpenAI in this sandbox, and this
sandbox has no network egress to call any of them even with a key. Every
contract above was verified against current official/authoritative
documentation via web search (not solely training memory) rather than a live
test call from me. **The live verification steps below have since been run and
confirmed** — Stage 5 is marked PASS on that basis.

### Verifying the real integrations (do this with real keys)

1. Get a free-tier key from remove.bg, set `REMOVE_BG_API_KEY` in `server/.env`,
   restart the server — startup log should show `Background Removal: real
   (remove.bg)`
2. In the app, run Background Removal on a real photo with a clear subject —
   the result should have an actual transparent/removed background, not the
   original image back
3. Get a DeepAI key, set `DEEPAI_API_KEY`, restart — log should show `Photo
   Enhance: real (DeepAI)`
4. Run Photo Enhancer on a real (ideally lower-resolution) photo — the result
   should be visibly higher-resolution/sharper than the input, not identical to it
5. Get an OpenAI key (requires a funded account), set `OPENAI_API_KEY`, restart
   — log should show `Script Generator: real (OpenAI)`
6. Run Script Generator with a real prompt — the result should be genuinely
   generated text relevant to your prompt, not the `[MOCK SCRIPT ...]` outline
7. Re-run the usage limiter check (6th request in a session → 429) with real
   keys configured — should behave identically to mock mode, since the limiter
   runs before the provider is ever called
8. Try an intentionally bad case (e.g. temporarily use an invalid key, or upload
   a non-image file renamed with a `.png` extension) — confirm you get a clear
   error message and never see a stack trace, the provider's raw response, or
   any key value anywhere in the response or browser console

## Stage 6 deliverables (this commit)

No answer came through on the three architecture questions asked before
starting, so these defaults were used (flagged clearly at the time): a
MediaRecorder-based real-time canvas capture for video export (no FFmpeg); full
resolution range (480p–4K) available now with Premium gating deferred entirely
to Stage 8; photo export renders at the true requested pixel size from the
original source rather than capping to preview resolution.

**Both editors' "Export" buttons are now real** — no longer disabled — and open
a dedicated export screen reading directly from the same non-destructive edit
state the live editor already has, so export always reflects exactly what's on
screen.

**`web/src/features/export/`**
- `constants.ts` — resolution presets (480p–4K) stored as a LONGEST EDGE pixel
  count rather than fixed width×height, since projects can be 9:16/1:1/4:5, not
  just 16:9 — `computeExportDimensions()` applies a preset to whichever aspect
  ratio the project actually is (matches how most short-form video editors
  handle this). FPS options (24/30/60) and quality presets (Standard/High/
  Ultra → bitrate for video, JPEG quality for photo).
- `imageExport.ts` — `exportPhotoToBlob()` renders at the TRUE requested
  resolution (bypassing the editor's smaller working-resolution cap — see
  `renderPhotoEdit`'s new `exactOutputSize` option in
  `photo-editor/canvasRenderer.ts`) and encodes to PNG/JPEG.
  `getEffectiveAspectRatio()` reads the CURRENT crop/rotation state rather than
  the project's original `aspectRatio` field, since Stage 3's crop tool can
  change it. `downloadBlob()` triggers a real browser download.
- `videoExport.ts` — `exportVideo()`: plays the entire EDL through the SAME
  compositor functions the live editor uses
  (`drawVideoFrame`/`drawTransitionFrame`/`drawOverlays`,
  `resolvePlayhead`/`resolveTransitionBlend`) at the target resolution,
  capturing the canvas via `captureStream()` into a real `.webm` file via
  `MediaRecorder`. Reports progress, supports cancellation. Because it reuses
  the exact same playhead/compositor functions rather than a separate
  reimplementation, trims/speed/reverse/filters/fade-transitions all export
  exactly as the preview shows them.
- `PhotoExportPanel.tsx` / `VideoExportPanel.tsx` — the export screens: preset
  pickers, render/progress state, download button, clear error states.

**Known Stage 6 limitations, stated plainly (see `features/export/README.md`
and the doc comment atop `videoExport.ts` for the full reasoning):**
- **Video export has no audio track.** Routing per-clip audio through this
  pipeline (Web Audio nodes rewired at every clip boundary, mixed with
  per-clip volume/mute) is a substantial separate piece of work this sandbox
  has no way to verify without a real browser — shipping a correct video-only
  pipeline now rather than an unverifiable audio attempt was the deliberate
  call.
- **Video export takes roughly real-time duration** — `captureStream` +
  `MediaRecorder` samples in actual wall-clock time; there's no "render faster
  than real-time" with this technique. The progress bar is honest about this.
- **Output is WebM (VP9/VP8), not MP4** — codec support for MP4/H.264 via
  `MediaRecorder` is inconsistent across browsers without a paid codec or a
  server-side transcode (which would mean FFmpeg — explicitly out of scope).
- Resolution/quality presets are not yet gated by plan (per the default used
  above) — Stage 8's job.

**A real bug found and fixed during this stage's own review:** the first draft
of `preparePlayers()` shared ONE `<video>` element across every clip using the
same `sourceUrl` (an easy-looking optimization for split clips, which share a
source). This breaks the moment a transition blend needs its "from" and "to"
clips to sit at two DIFFERENT playback positions simultaneously — a single
shared element only has one `currentTime`. Fixed to give every clip its own
independent element, matching the live editor's `useClipPlayers` model exactly
(same accepted extra-decode-overhead trade-off already documented there).

## Verifying Stage 6

1. `cd web && npm run dev`, open a **Photo** project with some edits applied
   (crop, filter, text, etc.)
2. Tap **Export** — panel should show live-computed pixel dimensions for each
   resolution preset (e.g. if you cropped to 1:1, "1080p" should show
   1080×1080, not 1920×1080)
3. Export as PNG, then as JPEG at different quality levels — both should
   download, open correctly, and show ALL your edits (crop/filter/text/etc.)
   baked in at the real requested resolution — not the smaller editing-preview
   resolution
4. Open a **Video** project with at least 2 clips, a filter on one, and a Fade
   transition between them
5. Tap **Export**, pick a resolution/fps/quality, tap Export — progress bar
   should advance roughly in real time relative to the video's duration
6. Once done, download and play the `.webm` file — it should show the correct
   trims, the filter only on its clip, and an actual visible crossfade at the
   transition boundary, matching what the live preview showed. Confirm there
   is no audio track (expected, documented limitation)
7. Start another export and tap **Cancel** partway through — should stop
   cleanly with no console errors
8. Try exporting a project with a reversed clip — the exported file should
   show it playing in reverse
9. `cd web && npm run build` — should complete without TypeScript errors (see
   sandbox verification note below)

**Note on this delivery's own verification:** same sandbox constraint as every
prior stage — no npm registry access here, so `npm install`/`npm run build`
couldn't be run, and additionally **this sandbox cannot run a real browser at
all**, so the `MediaRecorder`/`captureStream` pipeline — the highest-risk new
code in this stage — could not be executed even once. I did a thorough manual
trace instead (confirmed every function call against its actual signature,
confirmed the canvas/video element lifecycle, and found/fixed the shared-
element bug above by reasoning through the transition-blend case specifically)
plus the full project-wide unused-import and import-resolution sweeps (clean).
**Please treat step 4–8 above as the real completion gate for this stage** —
untested browser media APIs are exactly the kind of thing that can have a
working-on-paper bug that only surfaces with a real `MediaRecorder`
implementation in front of you.

## Stage 6 upgrade: real FFmpeg export pipeline — 🟡 PARTIAL (core pipeline extensively tested against a real FFmpeg binary)

The prior Stage 6 delivery used browser `MediaRecorder` for video export —
explicitly disallowed as a final export engine. **That approach has been
removed entirely** (`videoExport.ts`'s old `MediaRecorder`/`captureStream`
implementation is gone) and replaced with a real server-side FFmpeg pipeline.
**Photo export is completely untouched** — it was already real, client-side,
and working, and nothing about it needed FFmpeg.

**Update from the original draft of this section:** this environment turned
out to actually have a full GPL-enabled FFmpeg build available (`libx264`,
`aac`, `xfade`, `acrossfade`, `drawtext`, `colorbalance`, `curves` all
present) — discovered partway through this work, after initially assuming
(incorrectly) that no FFmpeg would be available at all. Once found, the core
pipeline logic was extracted and run directly against it with real test clips.
**This found and fixed one genuine, non-obvious bug** (below) and confirmed a
long list of behavior that would otherwise have been "written to match
documented behavior" rather than actually checked. What remains unverified —
and why this is still "partial," not "pass" — is detailed at the bottom of
this section.

### Architecture

```
Frontend → upload clip bytes + EDL manifest → backend job → real ffmpeg process → MP4 → download
```

- Clips still exist only as browser `blob:` URLs (no cloud storage until Stage
  9), so each export re-uploads the relevant clip bytes fresh — the same
  pattern Stage 5 established for AI photo tools, extended to video. A split
  clip's two halves share one `sourceKey` and upload once.
- `server/src/services/export/types.ts` — the manifest contract
  (`ExportRequestManifest`) and job state shape.
- `services/export/buildFilterGraph.ts` — constructs a real FFmpeg
  `filter_complex` graph: per-clip `trim`/`reverse`/`setpts` (speed)/
  `transpose`+`hflip`/`vflip` (rotate/flip)/color filter/cover-fit `scale`+
  `crop`/`fps`, chained together with REAL `xfade` (video) + `acrossfade`
  (audio) at a Fade transition, or `concat` for a hard cut. Text/sticker
  overlays via `drawtext` on the final merged stream.
- `services/export/exportJobManager.ts` — spawns the actual `ffmpeg`
  child process, parses ITS OWN real progress output (`-progress pipe:1`,
  `out_time_ms`) rather than simulating progress, supports cancellation
  (kills the process), cleans up temp files, sweeps abandoned jobs.
- `api/export.ts` — `POST /api/export/video` (upload + start job, returns a
  `jobId`), `GET /video/:jobId/progress` (polled every ~1s by the frontend),
  `POST /video/:jobId/cancel`, `GET /video/:jobId/result` (streams the MP4).
- `middleware/validateVideoUpload.ts` — disk-based multipart upload (NOT
  memory — video files can be large; Stage 5's image upload used memory
  storage, which would be wrong here) with a 2GB/file cap and MIME check.

### Two real bugs found and fixed via actual testing (not just review)

1. **Usage limiter counting progress polls.** The limiter (shared with Stage
   5's AI routes) was initially applied to the WHOLE export router via
   `router.use()`. Since the frontend polls `/progress` every ~1 second for
   the entire export duration, this would have exhausted the 5-request
   session limit within seconds of ANY export starting. Fixed: the limiter
   now applies only to the route that starts a new job (`POST /video`).
2. **`drawtext` quote-nesting corruption — found only by running real FFmpeg.**
   A literal apostrophe in overlay text (e.g. `"it's a test"`), when
   backslash-escaped (`\'`) inside a single-quoted filter option value,
   corrupts FFmpeg's quote-nesting for the REST of the filter string —
   causing a LATER, unrelated `enable='between(...)'` option on the same
   filter to fail to parse, with an error pointing at the wrong location
   entirely (`Invalid chars '[vo0]'`). This is exactly the kind of bug that
   looks correct on paper and only surfaces against a real binary. Fixed
   with the POSIX-shell-style workaround (close quote, insert an escaped
   literal quote, reopen quote: `'\''`) instead of a naive backslash-escape —
   see the doc comment on `escapeFilterValue` in `buildFilterGraph.ts`.

### What was ACTUALLY run against a real FFmpeg binary, and the results

Using synthetic test clips generated via `ffmpeg -f lavfi` (testsrc + sine
wave audio) and the actual `buildFilterGraph.ts` logic executed directly via
Node's native TypeScript support:

| Test | Result |
|---|---|
| Single clip passthrough | ✅ Exit 0, correct output |
| Two clips, hard cut (`concat`) | ✅ Exit 0, correct output |
| Two clips, Fade transition (`xfade`+`acrossfade`) | ✅ Exit 0, output duration exactly 7.000s for two 4s clips with a 1s overlap (4+4-1) — confirms the overlap math is correct, not just "didn't crash" |
| Trim + 2x speed + reverse + rotate 90° + flip + sepia filter | ✅ Exit 0, output duration exactly 1.500s for a 3s trimmed segment at 2x speed ((4-1)/2) |
| Muted clip + a clip whose SOURCE has no audio at all, hard cut | ✅ Exit 0, output correctly has both a video AND audio stream (generated silence via `anullsrc`, format-normalized to match real audio for `concat`) |
| Text overlay (`drawtext`) | ❌ then ✅ — this is bug #2 above; failed first, fixed, then confirmed the text VISIBLY renders via a pixel-difference check between a frame inside vs. outside the overlay's time window (253/255 max difference — genuinely different content, not a no-op) |
| Sticker/emoji overlay | ✅ Exit 0 (no crash) but **confirmed via pixel analysis on a plain black background that the emoji renders as ZERO visible pixels with the default DejaVu font** — more precise and worse than the original speculative "likely a tofu box" — see updated limitation below |
| `vintage` (`curves=preset=vintage`) and `cool` (`colorbalance`) filters | ✅ Both confirmed to measurably shift average frame color in the expected direction (cool → more blue), not silently no-op |
| Exact 1080p/2K/4K dimensions at 60fps | ✅ `ffprobe` confirms exactly 1920×1080, 2560×1440, 3840×2160, all at `60/1` fps |
| 8K (7680×4320) | ✅ Confirmed correct output dimensions; a 1-second clip encoded in ~8s with `veryfast`/CRF 28 — technically works, but this says little about resource behavor on a realistic multi-minute 8K export (see limitations) |
| Complex combination: 3 clips, one Fade transition + one hard cut, 3 different color filters, speed change, reverse, 180° rotation, a muted clip, a text overlay AND a sticker overlay together, portrait 720×1280 | ✅ Exit 0, output duration 6.267s vs. expected 6.250s (17ms difference — well within one frame's rounding at 30fps), correct resolution, both streams present |
| Cancel behavior (`SIGKILL` on a running ffmpeg child process) | ✅ Confirmed the process terminates (`code=null, signal='SIGKILL'`) and a resulting partial file can be cleaned up immediately after — matches `exportJobManager.ts`'s actual cancel logic |

### Requirements from this round, and their real status

| # | Requirement | Status |
|---|---|---|
| 1 | Real FFmpeg export, MP4 output, no MediaRecorder | ✅ Tested — `libx264`/`aac`/`+faststart`, MediaRecorder path deleted |
| 2 | Audio preserved, multi-clip, trim/split/merge timing, speed, mute | ✅ Tested — see table above |
| 3 | 480p/720p/1080p/2K/4K/8K | ✅ Tested (1080p/2K/4K/8K exact dims confirmed; 480p/720p use the same code path) |
| 4 | 24/30/60 FPS | ✅ Tested — 24/30/60 all confirmed via `ffprobe` |
| 5 | Respect trim/split/merge/order/speed/reverse/transitions/filters/text/stickers/aspect/mute | ✅ Tested (overlay timing-after-transition and emoji rendering remain documented limitations, now based on measured evidence, not speculation) |
| 6 | Real reverse via FFmpeg | ✅ Tested — `reverse`/`areverse`, correct duration math |
| 7 | Real export-time transitions, not the preview approximation | ✅ Tested — real `xfade`/`acrossfade`, confirmed genuine timeline-overlap (shorter output than naive concat) unlike the preview's same-length approximation |
| 8 | Secrets server-side, simplest reliable Node architecture | ✅ FFmpeg is a local binary, not an API — no secret involved; existing AI keys untouched |
| 9 | Progress, cancel, cleanup, error messages | ✅ Cancel/kill tested directly; progress parsing logic (`out_time_ms`) reviewed but not run inside the full job manager (see below) |
| 10 | Don't load whole video into memory; handle 8K resource failures gracefully | ✅ Implemented — disk-based upload/temp files throughout; 8K path confirmed technically functional |
| 11 | Don't break photo export | ✅ Untouched — verified no shared code path changed under it |
| 12 | Document FFmpeg install/config + licensing | ✅ `server/EXPORT_SETUP.md` — install steps per OS, env vars, explicit GPL/libx264 licensing note on why a bundled static binary was deliberately avoided |
| 13 | No fake FFmpeg wrapper still using MediaRecorder | ✅ Old file deleted; every test above is a real child process invocation |
| 14 | No AdMob/Premium/payments/4K-8K locking/auth/Android | ✅ None added |

### Documented limitations (now based on measured evidence, not speculation)

- **Emoji stickers do not render with the default font — confirmed, not
  speculated.** Tested directly: an emoji drawn via `drawtext` with the
  default DejaVu Sans Bold font on a plain black background produced ZERO
  non-black pixels. This font has no glyph for it and FFmpeg draws nothing at
  all — not even a fallback box. A genuinely color-emoji-capable font would be
  needed for this to work; see `EXPORT_SETUP.md`.
- **Overlay timing can drift slightly after a transition** — still true, not
  re-tested precisely, since it depends on exact multi-transition timelines;
  the mechanism (xfade shortens the timeline; overlay times aren't
  re-adjusted for it) is understood and documented, just not separately
  measured this round.
- **Filter looks are FFmpeg-native approximations** of the browser preview's
  CSS-based filters — confirmed they DO change the image in the expected
  direction, but pixel-for-pixel parity with the CSS preview was never the
  goal and wasn't tested.
- **Merge has no special FFmpeg handling** — confirmed correct: a merged
  group is just adjacent clips with no transition between them, which is
  exactly what the hard-cut `concat` path (tested above) already handles.

### What is STILL not verified — why this remains "partial," not "pass"

The core, highest-risk logic — the actual `filter_complex` construction and
its execution by a real FFmpeg binary — has now been extensively tested, well
beyond "reasoned through." What has NOT been run:

- **The actual Express server as a running process.** `npm install` still
  fails in this sandbox (no npm registry access — same constraint as every
  earlier stage), so the full `server/` TypeScript project has never been
  compiled or run as a whole. The core export logic was tested by copying the
  dependency-free files (`types.ts`, `ffmpegFilters.ts`, `probe.ts`,
  `buildFilterGraph.ts`) out and running them directly via Node's native
  TypeScript support — NOT through Express, multer, or the job manager's
  actual HTTP-facing code paths (`api/export.ts`, `exportJobManager.ts`'s
  process-spawning-within-a-job-object machinery, stdout-buffer progress
  parsing wired to a real job's `progressRatio` field).
- **The frontend end-to-end.** No browser is available in this sandbox — the
  `blob:` URL → `FormData` upload → polling → download flow in
  `videoExport.ts` and `VideoExportPanel.tsx` has been reviewed but not run.
- **Realistic-duration 8K resource behavior.** The 8K test above was 1 second
  of synthetic footage. A real multi-minute 8K export's time/memory/disk
  behavior is genuinely unknown until tried on real hardware.
- **True audio/video sync**, verified by ear/eye rather than by stream
  presence and duration matching.

### What to actually do before trusting this fully

1. Run `npm install` in `server/` (this sandbox couldn't — no registry
   access) and confirm the project builds.
2. Start the real server, confirm the startup log shows
   `[export] FFmpeg: available | ffprobe: available`.
3. From the real app in a real browser, export a simple 1-clip project and
   confirm the full upload → progress → download flow works end to end —
   this exercises everything the sandbox testing above could NOT reach.
4. Then work through trim → speed → reverse → a second clip with a
   transition → a text overlay → a sticker overlay, same incremental order
   used in the sandbox testing above, to isolate anything that's specific to
   the real HTTP/browser path.
5. Test a realistic multi-minute 4K and then 8K export on your actual
   hardware for genuine resource behavior.
6. Update this section with real findings from steps 1–5 — most of the
   underlying logic has real evidence behind it now, but the app-level
   integration around it does not yet.

## Stage 6 — final integration verification round — 🟡 still PARTIAL (precisely-scoped remaining gap)

A follow-up round specifically targeted the gap the section above identified:
"the Express/multer/browser integration layer has not been executed." See
`STAGE6_VERIFICATION.md`'s "FINAL INTEGRATION VERIFICATION" section for the
full test log (TEST-E2E-01 through 15).

**What this round did, concretely:** since `express`/`multer`/`react`/`vite`
still cannot be installed (network confirmed blocked at the firewall level,
re-checked fresh this round), built a minimal Node `http`-only server
implementing the exact same route contract as the real `api/export.ts` +
`validateVideoUpload.ts`, calling the real, unmodified job manager
underneath — then tested it with real `curl` multipart uploads (start,
poll, cancel, download, error cases, a real injection attempt) across
1080p/2K/4K/8K. Separately, found real Chromium browser binaries available
and ran the **actual, unmodified** `videoExport.ts`/`sessionId.ts` source
files (compiled via the project's own `tsc`) in a real headless browser,
performing a genuine upload → poll → download cycle against that server —
the downloaded result was extracted and `ffprobe`-verified.

**Result: 52 of 55 total tests (original 40 + this round's 15) are PASS on
real, executed evidence.** 4 real bugs found and fixed across both rounds
(filter-graph quote-nesting, an unconnected-filter-output failure for
audio-less sources, an error-message-overwrite bug, and the original
usage-limiter-on-polling bug).

**Why this stays PARTIAL, precisely:** 3 items remain BLOCKED — the
frontend build, the backend build, and the literal claim that Express/
multer/React executed. All three share one root cause: this sandbox's
npm registry access is blocked at the firewall level, not a code defect.
The hand-rolled HTTP server and the browser-executed business logic prove
the code those frameworks would call is correct, but the frameworks
themselves never ran here. Per this round's own instruction not to convert
BLOCKED into PASS, Stage 6 stays PARTIAL until `npm install` can actually
run in a real environment and confirm the literal `express`/`multer`
integration and the real React UI.

## Full project audit & stabilization round — Stages 1–6 — Stage 6 remains 🟡 PARTIAL

A dedicated audit round (see `STAGE6_VERIFICATION.md`'s top section, "Round:
Full Project Audit & Stabilization") read through the project specifically
looking for real bugs rather than re-confirming prior results. It found and
fixed two genuine, previously-unnoticed issues:

1. **`PhotoCanvas.tsx` (Stage 3) imported `PhotoTool` from the wrong file** —
   `./types`, which doesn't export it at all, instead of `./constants`, where
   it's actually defined. This would be a real `tsc` compile error. Found by
   building a proper export-existence checker (verifies every named import
   against the actual exports of its resolved file, not just whether the name
   is *used* — a gap in every prior round's sweeps). Fixed; a project-wide
   re-run of the same checker confirms no other instance of this bug class
   exists anywhere in `web/src` or `server/src`.
2. **`web/vite.config.ts` used `__dirname`/`path.resolve`, but
   `web/package.json` never listed `@types/node`** (unlike `server/package.json`,
   which does, since the server actually uses Node's fs/path/os APIs at
   runtime) — a likely real "Cannot find name '__dirname'" build error. Fixed
   two ways: rewrote the config to use `fileURLToPath(new URL(...,
   import.meta.url))` (the modern ESM-native pattern, avoiding `__dirname`
   entirely) AND added `@types/node` to `web/package.json` regardless, since
   even `fileURLToPath` (from Node's `'url'` module) needs Node's type
   declarations to resolve under `moduleResolution: bundler`.

After both fixes, the full Stage 6 FFmpeg pipeline, the real-HTTP integration
flow, and the real-browser flow were all re-run as regression smoke tests
(same proven method as before: real FFmpeg binary, a minimal HTTP server
matching the real route contract since `express`/`multer` still can't be
installed, and a real headless Chromium running the actual, unmodified
`videoExport.ts` logic) — all still pass with real, fresh evidence.

**Stage 6 status is unchanged: PARTIAL.** `npm install` for both `web/` and
`server/` remains blocked by this sandbox's firewall (`host_not_allowed`,
re-confirmed fresh this round) — the real frontend/backend builds have never
run, and neither has the real React UI. This is the same, unchanged,
environment-level gap identified in every prior round, not a code defect —
and it is the only thing separating this from PASS, since everything
testable without it now has real, repeated, reproducible evidence behind it.
See `STAGE6_VERIFICATION.md`'s "Final Summary (this round)" block for the
complete PASS/FAIL/BLOCKED breakdown across Stages 1–6.

## Explicitly NOT in Stage 1

- No actual photo/video editing UI or logic
- No AI calls (mock or real)
- No ads SDK integration
- No payment/billing code
- No authentication implementation
- No Capacitor/Android project (that's Stage 11 — `android/` is an empty placeholder
  with a note explaining why)

## How to verify Stage 1 is stable before moving on

1. `cd web && npm install && npm run dev` — dev server starts, placeholder page renders
2. `cd web && npm run build` — production build completes without errors
3. `cd server && npm install && npm run dev` — server starts, logs the listening port
4. `curl http://localhost:8787/api/health` — returns `{ "status": "ok", "stage": 5 }`
5. `cd server && npm run build` — TypeScript compiles without errors

Once you've run these and they pass in your environment, say so and we'll start Stage 2.
