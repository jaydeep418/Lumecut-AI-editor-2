import type { ReactNode } from 'react';

export function SectionHeader({ title, action }: { title: string; action?: ReactNode }) {
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: 'var(--space-2)',
      }}
    >
      <h2 style={{ fontSize: 16, margin: 0 }}>{title}</h2>
      {action}
    </div>
  );
}
