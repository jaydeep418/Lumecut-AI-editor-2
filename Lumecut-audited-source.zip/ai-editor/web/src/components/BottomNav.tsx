import { NavLink } from 'react-router-dom';

const items = [
  { to: '/', label: 'Home', icon: '⌂', end: true },
  { to: '/projects', label: 'Projects', icon: '▤', end: false },
  { to: '/ai-tools', label: 'AI Tools', icon: '✦', end: false },
  { to: '/profile', label: 'Profile', icon: '◍', end: false },
];

export function BottomNav() {
  return (
    <nav
      style={{
        position: 'sticky',
        bottom: 0,
        display: 'flex',
        background: 'var(--color-surface)',
        borderTop: '1px solid var(--color-border)',
        paddingBottom: 'env(safe-area-inset-bottom)',
      }}
    >
      {items.map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          end={item.end}
          style={({ isActive }) => ({
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 4,
            padding: 'var(--space-2) 0',
            textDecoration: 'none',
            color: isActive ? 'var(--color-accent-strong)' : 'var(--color-text-secondary)',
            fontSize: 12,
          })}
        >
          <span aria-hidden style={{ fontSize: 20 }}>
            {item.icon}
          </span>
          {item.label}
        </NavLink>
      ))}
    </nav>
  );
}
