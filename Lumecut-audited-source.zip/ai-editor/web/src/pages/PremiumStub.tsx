const BENEFITS = [
  'No Ads',
  '4K Export',
  '2K Export',
  'No Watermark',
  'Premium AI Tools',
  'Premium Effects',
  'More AI Credits',
];

export default function PremiumStub() {
  return (
    <div style={{ padding: 'var(--space-4)', display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
      <h1 style={{ fontSize: 22, margin: 0 }}>Unlock Pro Editing</h1>
      <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {BENEFITS.map((b) => (
          <li key={b} style={{ fontSize: 14 }}>
            ✓ {b}
          </li>
        ))}
      </ul>
      <p style={{ color: 'var(--color-text-secondary)', fontSize: 13 }}>
        Plan pricing and purchase flow are built in Stage 8, behind a swappable billing
        provider. Prices will be pulled from configuration, never hardcoded.
      </p>
    </div>
  );
}
