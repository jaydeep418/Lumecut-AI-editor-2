import { useNavigate, useParams } from 'react-router-dom';
import { useProjects } from '@/state/ProjectsContext';
import { PhotoEditor } from '@/features/photo-editor/PhotoEditor';
import { VideoEditor } from '@/features/video-editor/VideoEditor';

/**
 * Editor route entry point. Dispatches to the real photo (Stage 3) or video
 * (Stage 4) editor based on project kind.
 *
 * `key={project.id}` on both branches is deliberate: without it, navigating
 * directly from one project's editor to a different project's editor (same route
 * pattern, so React would otherwise just re-render the existing PhotoEditor/
 * VideoEditor instance with new props) would leak the FIRST project's undo history
 * and playback state into the second. Keying by id forces a clean remount per
 * project, while Stage 4's video draft-saving (ProjectsContext) still restores
 * that specific project's edits on the fresh mount.
 */
export default function EditorRoute() {
  const { projectId } = useParams<{ projectId: string }>();
  const { getProject } = useProjects();
  const navigate = useNavigate();
  const project = projectId ? getProject(projectId) : undefined;

  if (!project) {
    return (
      <div style={{ padding: 'var(--space-4)' }}>
        <p>Project not found. It may have been deleted, or lost on reload (Stage 2 projects are in-memory only).</p>
        <button onClick={() => navigate('/')} style={backButtonStyle}>
          ← Back to Home
        </button>
      </div>
    );
  }

  if (project.kind === 'photo') {
    return <PhotoEditor key={project.id} project={project} />;
  }

  return <VideoEditor key={project.id} project={project} />;
}

const backButtonStyle = {
  marginTop: 'var(--space-3)',
  background: 'var(--color-surface-raised)',
  color: 'var(--color-text-primary)',
  border: '1px solid var(--color-border)',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-2) var(--space-3)',
  cursor: 'pointer',
} as const;
