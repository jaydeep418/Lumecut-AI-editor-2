import type { CSSProperties } from 'react';
import { Link } from 'react-router-dom';
import { useProjects } from '@/state/ProjectsContext';
import { NewProjectButton } from '@components/NewProjectButton';
import { SectionHeader } from '@components/SectionHeader';
import { ConnectionStatusDot } from '@components/ConnectionStatusDot';

const AI_TOOLS_PREVIEW = [
  { label: 'Background Remover', icon: '✂️' },
  { label: 'Photo Enhancer', icon: '✨' },
  { label: 'Auto Captions', icon: '💬' },
  { label: 'Text to Image', icon: '🖼️' },
];

const TEMPLATES_PREVIEW = [
  { label: 'Reel — 9:16' },
  { label: 'Story — 9:16' },
  { label: 'Square Post — 1:1' },
  { label: 'Landscape — 16:9' },
];

export default function Home() {
  const { projects } = useProjects();
  const recent = projects.slice(0, 6);

  return (
    <div style={{ padding: 'var(--space-4)', display: 'flex', flexDirection: 'column', gap: 'var(--space-6)' }}>
      {/* Top bar: logo/name, profile, premium */}
      <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-2)' }}>
          <h1 style={{ fontSize: 20, margin: 0 }}>Lumecut</h1>
          <ConnectionStatusDot />
        </div>
        <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
          <Link to="/premium" style={pillLinkStyle('var(--color-accent)')}>
            ✦ Premium
          </Link>
          <Link to="/profile" style={pillLinkStyle('var(--color-surface-raised)')} aria-label="Profile">
            ◍
          </Link>
        </div>
      </header>

      {/* New project */}
      <section style={{ display: 'flex', gap: 'var(--space-3)', flexWrap: 'wrap' }}>
        <NewProjectButton kind="photo" variant="primary">
          📷 Photo Editor
        </NewProjectButton>
        <NewProjectButton kind="video" variant="secondary">
          🎬 Video Editor
        </NewProjectButton>
      </section>

      {/* Recent projects */}
      <section>
        <SectionHeader
          title="Recent Projects"
          action={
            <Link to="/projects" style={{ fontSize: 13, color: 'var(--color-text-secondary)' }}>
              See all
            </Link>
          }
        />
        {recent.length === 0 ? (
          <EmptyState text="No projects yet — start one above." />
        ) : (
          <div style={{ display: 'flex', gap: 'var(--space-3)', overflowX: 'auto', paddingBottom: 4 }}>
            {recent.map((p) => (
              <Link
                key={p.id}
                to={`/editor/${p.id}`}
                style={{
                  flex: '0 0 120px',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <div
                  style={{
                    height: 160,
                    borderRadius: 'var(--radius-md)',
                    background: 'var(--color-surface)',
                    border: '1px solid var(--color-border)',
                    overflow: 'hidden',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  {p.kind === 'photo' ? (
                    <img src={p.previewUrl} alt={p.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  ) : (
                    <video src={p.previewUrl} muted style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  )}
                </div>
                <p style={{ fontSize: 12, margin: '4px 0 0', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {p.name}
                </p>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* AI Tools preview */}
      <section>
        <SectionHeader
          title="AI Tools"
          action={
            <Link to="/ai-tools" style={{ fontSize: 13, color: 'var(--color-text-secondary)' }}>
              See all
            </Link>
          }
        />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 'var(--space-3)' }}>
          {AI_TOOLS_PREVIEW.map((tool) => (
            <Link key={tool.label} to="/ai-tools" style={cardStyle}>
              <span style={{ fontSize: 22 }}>{tool.icon}</span>
              <span style={{ fontSize: 13 }}>{tool.label}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Templates preview */}
      <section>
        <SectionHeader title="Templates" />
        <div style={{ display: 'flex', gap: 'var(--space-3)', overflowX: 'auto', paddingBottom: 4 }}>
          {TEMPLATES_PREVIEW.map((t) => (
            <div
              key={t.label}
              style={{
                flex: '0 0 140px',
                height: 90,
                borderRadius: 'var(--radius-md)',
                background: 'var(--color-surface)',
                border: '1px dashed var(--color-border)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 12,
                color: 'var(--color-text-secondary)',
                textAlign: 'center',
                padding: 'var(--space-2)',
              }}
            >
              {t.label}
              <br />
              (coming soon)
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div
      style={{
        border: '1px dashed var(--color-border)',
        borderRadius: 'var(--radius-md)',
        padding: 'var(--space-4)',
        color: 'var(--color-text-secondary)',
        fontSize: 13,
        textAlign: 'center',
      }}
    >
      {text}
    </div>
  );
}

function pillLinkStyle(background: string): CSSProperties {
  return {
    background,
    color: '#fff',
    textDecoration: 'none',
    borderRadius: 'var(--radius-pill)',
    padding: 'var(--space-2) var(--space-3)',
    fontSize: 13,
    fontWeight: 600,
  };
}

const cardStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 6,
  height: 84,
  borderRadius: 'var(--radius-md)',
  background: 'var(--color-surface)',
  border: '1px solid var(--color-border)',
  textDecoration: 'none',
  color: 'var(--color-text-primary)',
};
