import type { CSSProperties, MouseEvent } from 'react';
import { Link } from 'react-router-dom';
import { useProjects } from '@/state/ProjectsContext';
import { NewProjectButton } from '@components/NewProjectButton';

export default function Projects() {
  const { projects, deleteProject } = useProjects();

  function handleDelete(e: MouseEvent, id: string, name: string) {
    // Card is a <Link> underneath the delete button — stop the click from also
    // navigating into the editor for a project we're about to remove.
    e.preventDefault();
    e.stopPropagation();
    if (window.confirm(`Delete "${name}"? This can't be undone.`)) {
      deleteProject(id);
    }
  }

  return (
    <div style={{ padding: 'var(--space-4)', display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
      <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <h1 style={{ fontSize: 20, margin: 0 }}>Projects</h1>
        <NewProjectButton variant="primary">+ New</NewProjectButton>
      </header>

      {projects.length === 0 ? (
        <p style={{ color: 'var(--color-text-secondary)', fontSize: 14 }}>
          No projects yet. Projects you create this session will show up here. (Real cloud
          projects that persist across sessions arrive in Stage 9.)
        </p>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 'var(--space-3)' }}>
          {projects.map((p) => (
            <div key={p.id} style={{ position: 'relative' }}>
              <Link to={`/editor/${p.id}`} style={{ textDecoration: 'none', color: 'inherit', display: 'block' }}>
                <div
                  style={{
                    aspectRatio: '1 / 1',
                    borderRadius: 'var(--radius-md)',
                    background: 'var(--color-surface)',
                    border: '1px solid var(--color-border)',
                    overflow: 'hidden',
                  }}
                >
                  {p.kind === 'photo' ? (
                    <img src={p.previewUrl} alt={p.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  ) : (
                    <video src={p.previewUrl} muted style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  )}
                </div>
                <p style={{ fontSize: 13, margin: '4px 0 0' }}>{p.name}</p>
                <p style={{ fontSize: 11, margin: 0, color: 'var(--color-text-secondary)' }}>
                  {p.kind === 'photo' ? 'Photo' : 'Video'} · {p.aspectRatio}
                </p>
              </Link>
              <button
                type="button"
                aria-label={`Delete ${p.name}`}
                title="Delete project"
                onClick={(e) => handleDelete(e, p.id, p.name)}
                style={deleteButtonStyle}
              >
                🗑
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const deleteButtonStyle: CSSProperties = {
  position: 'absolute',
  top: 6,
  right: 6,
  width: 28,
  height: 28,
  minWidth: 28,
  minHeight: 28,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: '50%',
  border: 'none',
  background: 'rgba(0, 0, 0, 0.6)',
  color: '#fff',
  fontSize: 13,
  cursor: 'pointer',
};
