const TOOLS = [
  'Background Remover',
  'Background Generator/Replacement',
  'Photo Enhancer',
  'Image Upscaler',
  'Object Removal',
  'Image Effects',
  'Auto Captions',
  'Subtitle Generation',
  'Video Effects',
  'Text to Image',
  'Image to Video',
  'Script Generator',
  'Caption Generator',
];

export default function AiToolsStub() {
  return (
    <div style={{ padding: 'var(--space-4)', display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
      <h1 style={{ fontSize: 20, margin: 0 }}>AI Tools</h1>
      <p style={{ color: 'var(--color-text-secondary)', fontSize: 13, margin: 0 }}>
        Wired up in Stage 5, behind the backend AI proxy so no provider key ever reaches this
        screen. Layout below previews what will become tappable tool tiles.
      </p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 'var(--space-3)' }}>
        {TOOLS.map((tool) => (
          <div
            key={tool}
            style={{
              padding: 'var(--space-3)',
              borderRadius: 'var(--radius-md)',
              background: 'var(--color-surface)',
              border: '1px dashed var(--color-border)',
              fontSize: 13,
              color: 'var(--color-text-secondary)',
            }}
          >
            {tool}
          </div>
        ))}
      </div>
    </div>
  );
}
