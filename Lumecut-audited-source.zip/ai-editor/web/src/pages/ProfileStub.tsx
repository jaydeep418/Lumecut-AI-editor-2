export default function ProfileStub() {
  return (
    <div style={{ padding: 'var(--space-4)', display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
      <h1 style={{ fontSize: 20, margin: 0 }}>Profile</h1>
      <p style={{ color: 'var(--color-text-secondary)', fontSize: 13 }}>
        Sign up, login, settings, subscription status, AI credits, and export history are built
        in Stage 9 once authentication and the backend database are wired up.
      </p>
    </div>
  );
}
