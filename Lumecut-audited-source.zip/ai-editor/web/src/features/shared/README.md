# Shared editor infrastructure

Code genuinely reused by more than one editor, moved here during Stage 4 (originally
lived under `photo-editor/` when only the photo editor existed):

- `history.ts` — generic undo/redo hook. Editor-agnostic: it only ever sees whatever
  state object type the caller gives it (`PhotoEditState`, `VideoEditState`, …) and
  never inspects its shape. `commit` vs `setLive` is what keeps continuous
  interactions (slider drags, overlay drags) from flooding the undo stack with one
  entry per tick — see the doc comment in the file for the exact mechanism.
- `filters.ts` — filter presets as Canvas 2D `ctx.filter` strings. These apply
  identically whether the thing being drawn is a photo or the current frame of a
  video, so both editors' Filters panels point at the same `FILTERS` array.

If a future editor (e.g. an audio-only tool) needs undo/redo or filter presets, it
reuses these rather than growing its own copy.
