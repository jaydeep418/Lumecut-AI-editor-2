/**
 * Filter presets, shared between the photo editor (Stage 3) and video editor
 * (Stage 4) — a Canvas 2D `ctx.filter` string applies identically whether the
 * source being drawn is an image or the current frame of a video element.
 */
export type FilterId =
  | 'none'
  | 'grayscale'
  | 'sepia'
  | 'vintage'
  | 'cool'
  | 'warm'
  | 'highContrast'
  | 'fade';

export interface FilterDefinition {
  id: FilterId;
  label: string;
  /** Canvas 2D `ctx.filter` value — natively GPU-accelerated by the browser. */
  cssFilter: string;
  /** Optional flat color overlay blended on top for looks a pure CSS filter can't
   *  reach (e.g. a warm vintage tint). Drawn with 'multiply'/'overlay' composite. */
  overlay?: { color: string; opacity: number; composite: GlobalCompositeOperation };
}

export const FILTERS: FilterDefinition[] = [
  { id: 'none', label: 'None', cssFilter: 'none' },
  { id: 'grayscale', label: 'B&W', cssFilter: 'grayscale(1)' },
  {
    id: 'sepia',
    label: 'Sepia',
    cssFilter: 'sepia(0.7) contrast(1.05)',
  },
  {
    id: 'vintage',
    label: 'Vintage',
    cssFilter: 'sepia(0.3) saturate(0.75) contrast(0.95) brightness(1.05)',
    overlay: { color: '#3b2a1a', opacity: 0.08, composite: 'multiply' },
  },
  {
    id: 'cool',
    label: 'Cool',
    cssFilter: 'saturate(1.1) contrast(1.05)',
    overlay: { color: '#3b6bff', opacity: 0.08, composite: 'overlay' },
  },
  {
    id: 'warm',
    label: 'Warm',
    cssFilter: 'saturate(1.1) contrast(1.02)',
    overlay: { color: '#ff9d3b', opacity: 0.08, composite: 'overlay' },
  },
  { id: 'highContrast', label: 'High Contrast', cssFilter: 'contrast(1.4) saturate(1.15)' },
  { id: 'fade', label: 'Fade', cssFilter: 'contrast(0.85) saturate(0.85) brightness(1.08)' },
];

export function getFilterDefinition(id: FilterId): FilterDefinition {
  return FILTERS.find((f) => f.id === id) ?? FILTERS[0];
}
