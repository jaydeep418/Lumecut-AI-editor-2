# Premium feature
Populated in Stage 8: "Unlock Pro Editing" screen, plan selection, purchase state,
restore purchases, and entitlement-aware UI gating. Billing provider is swappable —
see server/src/services/payments.
