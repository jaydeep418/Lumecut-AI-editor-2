import { getSessionId } from '@services/sessionId';

/**
 * Video AI service abstraction — mirrors features/ai/photoAiService.ts.
 *
 * Stage 5 wires up a real implementation (`BackendVideoAiService`, below) for
 * Script Generator only — a representative, end-to-end example of the
 * text-in/text-out request shape (no file upload needed, unlike the photo tools).
 * The remaining tools (Auto Captions, Subtitle Generation, AI Video Effects,
 * Caption Generator) stay stubbed; wiring each up follows the same pattern.
 */

export type AiJobStatus = 'unavailable' | 'queued' | 'processing' | 'done' | 'error';

export interface AiJobResult {
  status: AiJobStatus;
  /** Populated only when status === 'done' and the result is an image/video URL. */
  resultUrl?: string;
  /** Populated only when status === 'done' and the result is text (e.g. a script). */
  text?: string;
  message?: string;
}

export interface VideoAiService {
  generateCaptions(sourceUrl: string): Promise<AiJobResult>;
  generateSubtitles(sourceUrl: string, language: string): Promise<AiJobResult>;
  applyVideoEffect(sourceUrl: string, effectId: string): Promise<AiJobResult>;
  generateScript(prompt: string): Promise<AiJobResult>;
  generateCaptionText(sourceUrl: string): Promise<AiJobResult>;
}

const NOT_IN_THIS_STAGE: AiJobResult = {
  status: 'unavailable',
  message: 'Not part of this Stage 5 build — same interface as Script Generator, ready to wire the same way.',
};

/** Kept for reference/testing — reports every tool as unavailable, makes no calls. */
export class StubVideoAiService implements VideoAiService {
  async generateCaptions(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }
  async generateSubtitles(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }
  async applyVideoEffect(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }
  async generateScript(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }
  async generateCaptionText(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }
}

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8787';

/** Real implementation: calls this app's own backend. Never holds or sees a
 *  provider API key. */
export class BackendVideoAiService implements VideoAiService {
  async generateScript(prompt: string): Promise<AiJobResult> {
    try {
      const response = await fetch(`${API_BASE_URL}/api/ai/video/script`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Session-Id': getSessionId() },
        body: JSON.stringify({ prompt }),
      });
      const data = await response.json();

      if (!response.ok) {
        return { status: 'error', message: typeof data?.message === 'string' ? data.message : 'AI processing failed' };
      }
      return { status: 'done', text: data.text };
    } catch (err) {
      return { status: 'error', message: err instanceof Error ? err.message : 'AI processing failed' };
    }
  }

  async generateCaptions(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }
  async generateSubtitles(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }
  async applyVideoEffect(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }
  async generateCaptionText(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }
}

let activeService: VideoAiService = new BackendVideoAiService();

export function setVideoAiService(service: VideoAiService): void {
  activeService = service;
}

export const videoAiService: VideoAiService = {
  generateCaptions: (sourceUrl) => activeService.generateCaptions(sourceUrl),
  generateSubtitles: (sourceUrl, language) => activeService.generateSubtitles(sourceUrl, language),
  applyVideoEffect: (sourceUrl, effectId) => activeService.applyVideoEffect(sourceUrl, effectId),
  generateScript: (prompt) => activeService.generateScript(prompt),
  generateCaptionText: (sourceUrl) => activeService.generateCaptionText(sourceUrl),
};
