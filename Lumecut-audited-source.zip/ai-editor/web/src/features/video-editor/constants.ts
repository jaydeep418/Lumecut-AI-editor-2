export type VideoTool = 'edit' | 'audio' | 'text' | 'stickers' | 'filters' | 'transitions' | 'speed' | 'canvas' | 'ai';

export const VIDEO_TOOLS: Array<{ id: VideoTool; label: string; icon: string }> = [
  { id: 'edit', label: 'Edit', icon: '✂' },
  { id: 'audio', label: 'Audio', icon: '♪' },
  { id: 'text', label: 'Text', icon: 'T' },
  { id: 'stickers', label: 'Stickers', icon: '☺' },
  { id: 'filters', label: 'Filters', icon: '◐' },
  { id: 'transitions', label: 'Transitions', icon: '⇄' },
  { id: 'speed', label: 'Speed', icon: '⏱' },
  { id: 'canvas', label: 'Canvas', icon: '⬚' },
  { id: 'ai', label: 'AI', icon: '✦' },
];

export const VIDEO_AI_TOOLS: Array<{ id: string; label: string; description: string }> = [
  { id: 'auto-captions', label: 'Auto Captions', description: 'Generate captions synced to speech.' },
  { id: 'subtitles', label: 'Subtitle Generation', description: 'Generate translated/styled subtitles.' },
  { id: 'video-effects', label: 'AI Video Effects', description: 'Apply generative style effects to the clip.' },
  { id: 'script', label: 'Script Generator', description: 'Draft a script or narration outline.' },
  { id: 'caption-text', label: 'Caption Generator', description: 'Generate a social caption for this video.' },
];

export const SPEED_PRESETS = [0.25, 0.5, 1, 1.5, 2, 4];
