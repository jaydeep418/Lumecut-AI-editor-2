import { useState, type CSSProperties } from 'react';
import { useNavigate } from 'react-router-dom';
import { ASPECT_RATIOS } from '@/constants/aspectRatios';
import type { Project } from '@types/project';
import { VideoCanvas } from './VideoCanvas';
import { Timeline } from './Timeline';
import { VIDEO_TOOLS, type VideoTool } from './constants';
import { useVideoEditor } from './useVideoEditor';
import { AudioPanel } from './toolbars/AudioPanel';
import { AiToolsPanel } from './toolbars/AiToolsPanel';
import { CanvasPanel } from './toolbars/CanvasPanel';
import { EditPanel } from './toolbars/EditPanel';
import { FiltersPanel } from './toolbars/FiltersPanel';
import { SpeedPanel } from './toolbars/SpeedPanel';
import { StickersPanel } from './toolbars/StickersPanel';
import { TextPanel } from './toolbars/TextPanel';
import { TransitionsPanel } from './toolbars/TransitionsPanel';
import { VideoExportPanel } from '@/features/export/VideoExportPanel';

export function VideoEditor({ project }: { project: Project }) {
  const navigate = useNavigate();
  const editor = useVideoEditor(project);
  const [activeTool, setActiveTool] = useState<VideoTool>('edit');
  const [selectedClipId, setSelectedClipId] = useState<string | null>(null);
  const [showExport, setShowExport] = useState(false);

  const ratio = ASPECT_RATIOS.find((r) => r.id === project.aspectRatio) ?? { w: 9, h: 16 };
  const activeSourceUrl = editor.activePlayhead?.clip.sourceUrl ?? project.previewUrl;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Top bar */}
      <header
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: 'var(--space-3) var(--space-4)',
          borderBottom: '1px solid var(--color-border)',
          background: 'var(--color-surface)',
        }}
      >
        <button onClick={() => navigate('/')} style={iconButtonStyle} aria-label="Back">
          ←
        </button>
        <span style={{ fontSize: 14, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {project.name}{' '}
          <span style={{ fontWeight: 400, fontSize: 12, color: 'var(--color-text-secondary)' }}>
            · {project.aspectRatio}
          </span>
        </span>
        <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
          <button
            onClick={editor.undo}
            disabled={!editor.canUndo}
            style={{ ...iconButtonStyle, opacity: editor.canUndo ? 1 : 0.35 }}
            title="Undo"
          >
            ↶
          </button>
          <button
            onClick={editor.redo}
            disabled={!editor.canRedo}
            style={{ ...iconButtonStyle, opacity: editor.canRedo ? 1 : 0.35 }}
            title="Redo"
          >
            ↷
          </button>
          <button
            onClick={() => setShowExport(true)}
            disabled={editor.loading || editor.state.clips.length === 0}
            style={{ ...iconButtonStyle, opacity: editor.loading || editor.state.clips.length === 0 ? 0.35 : 1 }}
            title="Export"
          >
            Export
          </button>
        </div>
      </header>

      {/* Center preview */}
      <div style={{ flex: 1, minHeight: 0, background: '#000', position: 'relative' }}>
        {editor.loading ? (
          <div style={centerMessageStyle}>Loading video…</div>
        ) : (
          <>
            <VideoCanvas editor={editor} activeTool={activeTool} aspectRatio={ratio} />
            <button
              type="button"
              onClick={() => (editor.isPlaying ? editor.pause() : editor.play())}
              style={playButtonStyle}
              aria-label={editor.isPlaying ? 'Pause' : 'Play'}
            >
              {editor.isPlaying ? '⏸' : '▶'}
            </button>
          </>
        )}
      </div>

      {/* Timeline */}
      {!editor.loading && <Timeline editor={editor} selectedClipId={selectedClipId} onSelectClip={setSelectedClipId} />}

      {/* Bottom: active tool panel + tool tabs */}
      <div style={{ borderTop: '1px solid var(--color-border)', background: 'var(--color-surface)' }}>
        {!editor.loading && (
          <div>
            {activeTool === 'edit' && <EditPanel editor={editor} selectedClipId={selectedClipId} onSelectClip={setSelectedClipId} />}
            {activeTool === 'audio' && <AudioPanel editor={editor} selectedClipId={selectedClipId} />}
            {activeTool === 'text' && <TextPanel editor={editor} />}
            {activeTool === 'stickers' && <StickersPanel editor={editor} />}
            {activeTool === 'filters' && <FiltersPanel editor={editor} selectedClipId={selectedClipId} />}
            {activeTool === 'transitions' && <TransitionsPanel editor={editor} />}
            {activeTool === 'speed' && <SpeedPanel editor={editor} selectedClipId={selectedClipId} />}
            {activeTool === 'canvas' && (
              <CanvasPanel editor={editor} selectedClipId={selectedClipId} aspectRatio={project.aspectRatio} />
            )}
            {activeTool === 'ai' && <AiToolsPanel sourceUrl={activeSourceUrl} />}
          </div>
        )}

        <div style={{ display: 'flex', overflowX: 'auto', padding: 'var(--space-2) var(--space-2) var(--space-3)', gap: 'var(--space-2)' }}>
          {VIDEO_TOOLS.map((tool) => {
            const active = activeTool === tool.id;
            return (
              <button
                key={tool.id}
                type="button"
                onClick={() => setActiveTool(tool.id)}
                style={{
                  flex: '0 0 auto',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: 2,
                  background: active ? 'var(--color-accent)' : 'var(--color-surface-raised)',
                  border: active ? '1px solid var(--color-accent)' : '1px solid var(--color-border)',
                  color: active ? '#fff' : 'var(--color-text-secondary)',
                  borderRadius: 'var(--radius-pill)',
                  padding: 'var(--space-2) var(--space-3)',
                  fontSize: 11,
                }}
              >
                <span style={{ fontSize: 16 }}>{tool.icon}</span>
                {tool.label}
              </button>
            );
          })}
        </div>
      </div>

      {showExport && (
        <VideoExportPanel editState={editor.state} project={project} onClose={() => setShowExport(false)} />
      )}
    </div>
  );
}

const iconButtonStyle: CSSProperties = {
  background: 'transparent',
  border: 'none',
  color: 'var(--color-text-primary)',
  fontSize: 16,
  cursor: 'pointer',
};

const centerMessageStyle: CSSProperties = {
  height: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  color: 'var(--color-text-secondary)',
  fontSize: 13,
};

const playButtonStyle: CSSProperties = {
  position: 'absolute',
  bottom: 'var(--space-3)',
  left: '50%',
  transform: 'translateX(-50%)',
  width: 48,
  height: 48,
  borderRadius: '50%',
  background: 'rgba(0, 0, 0, 0.6)',
  color: '#fff',
  border: '1px solid rgba(255,255,255,0.3)',
  fontSize: 18,
  cursor: 'pointer',
};
