import { useEffect, useRef, type PointerEvent as ReactPointerEvent } from 'react';
import { getFilterDefinition } from '@/features/shared/filters';
import { computeCanvasSize, drawOverlays, drawTransitionFrame, drawVideoFrame } from './videoCompositor';
import type { Overlay } from './types';
import type { UseVideoEditorResult } from './useVideoEditor';
import type { VideoTool } from './constants';

interface VideoElementWithRVFC extends HTMLVideoElement {
  requestVideoFrameCallback(callback: (now: number, metadata: unknown) => void): number;
  cancelVideoFrameCallback(handle: number): void;
}

function supportsRVFC(video: HTMLVideoElement): video is VideoElementWithRVFC {
  return typeof (video as Partial<VideoElementWithRVFC>).requestVideoFrameCallback === 'function';
}

interface VideoCanvasProps {
  editor: UseVideoEditorResult;
  activeTool: VideoTool;
  aspectRatio: { w: number; h: number };
}

const OVERLAY_HIT_RADIUS = 0.08;

export function VideoCanvas({ editor, activeTool, aspectRatio }: VideoCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mediaRef = useRef<HTMLDivElement>(null);
  const draggingOverlayId = useRef<string | null>(null);
  // draw() runs from rAF/rVFC callbacks whose enclosing effect only re-runs when
  // isPlaying/active-clip-id/aspectRatio change (see deps below) — but filter,
  // rotation, and overlay edits on the SAME active clip can happen in between.
  // Routing every read through this ref (updated every render) keeps draw() honest
  // without needing the render loop to restart on every state change.
  const editorRef = useRef(editor);
  editorRef.current = editor;

  // --- Render loop: draws whatever frame is currently active, every tick ---
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const outputSize = computeCanvasSize(aspectRatio.w, aspectRatio.h);
    let rafId: number | null = null;
    let rvfcVideo: VideoElementWithRVFC | null = null;
    let rvfcHandle: number | null = null;

    function draw() {
      const ed = editorRef.current;
      const activeOverlays = ed.state.overlays.filter(
        (o) => ed.timelineTime >= o.startTime && ed.timelineTime <= o.endTime
      );

      const blend = ed.transitionBlend;
      if (blend) {
        const fromVideo = ed.getPlayer(blend.fromClip.id) ?? null;
        const toVideo = ed.getPlayer(blend.toClip.id) ?? null;
        drawTransitionFrame(
          canvas!,
          fromVideo,
          toVideo,
          blend.alpha,
          outputSize,
          {
            filterCssFilter: getFilterDefinition(blend.fromClip.filter).cssFilter,
            rotationDeg: blend.fromClip.rotationDeg,
            flipHorizontal: blend.fromClip.flipHorizontal,
            flipVertical: blend.fromClip.flipVertical,
          },
          {
            filterCssFilter: getFilterDefinition(blend.toClip.filter).cssFilter,
            rotationDeg: blend.toClip.rotationDeg,
            flipHorizontal: blend.toClip.flipHorizontal,
            flipVertical: blend.toClip.flipVertical,
          }
        );
      } else {
        const resolution = ed.activePlayhead;
        const video = resolution ? (ed.getPlayer(resolution.clip.id) ?? null) : null;
        drawVideoFrame(canvas!, video, outputSize, {
          filterCssFilter: resolution ? getFilterDefinition(resolution.clip.filter).cssFilter : undefined,
          rotationDeg: resolution?.clip.rotationDeg,
          flipHorizontal: resolution?.clip.flipHorizontal,
          flipVertical: resolution?.clip.flipVertical,
        });
      }

      drawOverlays(canvas!, outputSize, activeOverlays);
    }

    function rafLoop() {
      draw();
      rafId = requestAnimationFrame(rafLoop);
    }

    // rAF is the unconditional base driver — every tick redraws regardless of rVFC,
    // so correctness (including manual-scrub reverse/seek preview, which never
    // fires rVFC continuously) never depends on it. Where the active clip DOES
    // support rVFC and IS actually playing forward, layer it in as an accuracy
    // booster: it draws an extra time exactly when the decoder presents a new
    // frame. Worst case it redraws the same frame twice in a tick (harmless).
    const resolution = editorRef.current.activePlayhead;
    const activeVideo = resolution ? editorRef.current.getPlayer(resolution.clip.id) : undefined;
    if (editorRef.current.isPlaying && activeVideo && !resolution?.clip.reversed && supportsRVFC(activeVideo)) {
      rvfcVideo = activeVideo;
      const onFrame = () => {
        draw();
        if (rvfcVideo) {
          rvfcHandle = rvfcVideo.requestVideoFrameCallback(onFrame);
        }
      };
      rvfcHandle = rvfcVideo.requestVideoFrameCallback(onFrame);
    }

    rafLoop();

    return () => {
      if (rafId !== null) cancelAnimationFrame(rafId);
      if (rvfcVideo && rvfcHandle !== null) {
        rvfcVideo.cancelVideoFrameCallback(rvfcHandle);
      }
    };
    // Deliberately narrow: only truly needs to restart when playback starts/stops,
    // the ACTIVE clip changes, or the output frame shape changes. Everything else
    // draw() needs is read fresh from editorRef on every tick (see above).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editor.isPlaying, editor.activePlayhead?.clip.id, aspectRatio.w, aspectRatio.h]);

  // --- Overlay drag (text/sticker), only for overlays visible at the current time ---
  function getNormalizedPoint(e: ReactPointerEvent): { x: number; y: number } | null {
    const rect = mediaRef.current?.getBoundingClientRect();
    if (!rect || rect.width === 0 || rect.height === 0) return null;
    return {
      x: Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width)),
      y: Math.min(1, Math.max(0, (e.clientY - rect.top) / rect.height)),
    };
  }

  function activeOverlaysNow(): Overlay[] {
    return editor.state.overlays.filter(
      (o) => editor.timelineTime >= o.startTime && editor.timelineTime <= o.endTime
    );
  }

  function hitTestOverlay(point: { x: number; y: number }): Overlay | null {
    const overlays = activeOverlaysNow();
    for (let i = overlays.length - 1; i >= 0; i--) {
      const overlay = overlays[i];
      if (activeTool === 'text' && overlay.type !== 'text') continue;
      if (activeTool === 'stickers' && overlay.type !== 'sticker') continue;
      const dx = overlay.x - point.x;
      const dy = overlay.y - point.y;
      if (Math.sqrt(dx * dx + dy * dy) < OVERLAY_HIT_RADIUS) return overlay;
    }
    return null;
  }

  function handlePointerDown(e: ReactPointerEvent) {
    if (activeTool !== 'text' && activeTool !== 'stickers') return;
    const point = getNormalizedPoint(e);
    if (!point) return;
    const hit = hitTestOverlay(point);
    if (hit) {
      draggingOverlayId.current = hit.id;
      (e.target as Element).setPointerCapture?.(e.pointerId);
    }
  }

  function handlePointerMove(e: ReactPointerEvent) {
    if (!draggingOverlayId.current) return;
    const point = getNormalizedPoint(e);
    if (!point) return;
    editor.previewOverlayPosition(draggingOverlayId.current, point.x, point.y);
  }

  function handlePointerUp() {
    const id = draggingOverlayId.current;
    draggingOverlayId.current = null;
    if (!id) return;
    const overlay = editor.state.overlays.find((o) => o.id === id);
    if (overlay) editor.updateOverlay(id, { x: overlay.x, y: overlay.y });
  }

  const outputSize = computeCanvasSize(aspectRatio.w, aspectRatio.h);

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div
        ref={mediaRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        style={{
          position: 'relative',
          display: 'inline-block',
          lineHeight: 0,
          maxWidth: '100%',
          maxHeight: '100%',
          aspectRatio: `${outputSize.width} / ${outputSize.height}`,
          touchAction: activeTool === 'text' || activeTool === 'stickers' ? 'none' : 'auto',
          userSelect: 'none',
        }}
      >
        <canvas ref={canvasRef} style={{ display: 'block', width: '100%', height: '100%' }} />
      </div>
    </div>
  );
}
