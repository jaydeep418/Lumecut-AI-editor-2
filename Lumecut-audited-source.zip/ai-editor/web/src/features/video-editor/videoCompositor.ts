import type { Overlay } from './types';

/** Lower than the photo editor's cap — decoding + drawing a video frame every tick
 *  is heavier than a one-off image redraw, so Stage 4 keeps the working canvas
 *  smaller. Stage 6's export targets the real requested resolution separately. */
const MAX_WORKING_DIMENSION = 1280;

export interface OutputSize {
  width: number;
  height: number;
}

export function computeCanvasSize(aspectW: number, aspectH: number): OutputSize {
  const scale = MAX_WORKING_DIMENSION / Math.max(aspectW, aspectH);
  return { width: Math.max(1, Math.round(aspectW * scale)), height: Math.max(1, Math.round(aspectH * scale)) };
}

export interface DrawFrameOptions {
  filterCssFilter?: string;
  rotationDeg?: 0 | 90 | 180 | 270;
  flipHorizontal?: boolean;
  flipVertical?: boolean;
}

function ensureCanvasSize(canvas: HTMLCanvasElement, { width, height }: OutputSize) {
  if (canvas.width !== width || canvas.height !== height) {
    canvas.width = width;
    canvas.height = height;
  }
}

/** Draws one video's current frame at a given opacity — no clear, no overlays.
 *  Internal building block for both the single-frame and blended-transition draws. */
function drawBaseFrame(
  ctx: CanvasRenderingContext2D,
  video: HTMLVideoElement | null,
  outputSize: OutputSize,
  options: DrawFrameOptions,
  alpha: number
): void {
  // readyState >= HAVE_CURRENT_DATA (2) means there's an actual frame to draw —
  // guards against drawing a blank/black frame before the source has loaded.
  if (!video || video.readyState < 2 || video.videoWidth <= 0 || alpha <= 0) return;

  const { width, height } = outputSize;
  const rotationDeg = options.rotationDeg ?? 0;
  const rotated = rotationDeg === 90 || rotationDeg === 270;
  const videoW = video.videoWidth;
  const videoH = video.videoHeight;

  ctx.save();
  ctx.globalAlpha = Math.min(1, Math.max(0, alpha));
  ctx.translate(width / 2, height / 2);
  ctx.rotate((rotationDeg * Math.PI) / 180);
  ctx.scale(options.flipHorizontal ? -1 : 1, options.flipVertical ? -1 : 1);

  const frameW = rotated ? height : width;
  const frameH = rotated ? width : height;
  // "Cover" fit: fill the frame, cropping overflow — matches how most short-form
  // video editors handle mixed source aspect ratios.
  const scale = Math.max(frameW / videoW, frameH / videoH);
  const drawW = videoW * scale;
  const drawH = videoH * scale;

  if (options.filterCssFilter) ctx.filter = options.filterCssFilter;
  ctx.drawImage(video, -drawW / 2, -drawH / 2, drawW, drawH);
  ctx.restore();
}

function clearToBlack(ctx: CanvasRenderingContext2D, { width, height }: OutputSize) {
  ctx.save();
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, width, height);
  ctx.restore();
}

/**
 * Draws the CURRENT frame of `video` onto `canvas` at a fixed output size,
 * "cover"-fit. Clears the canvas first. Use `drawOverlays` separately afterward —
 * overlays are timeline-level, not tied to a single clip's draw call.
 */
export function drawVideoFrame(
  canvas: HTMLCanvasElement,
  video: HTMLVideoElement | null,
  outputSize: OutputSize,
  options: DrawFrameOptions = {}
): void {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ensureCanvasSize(canvas, outputSize);
  clearToBlack(ctx, outputSize);
  drawBaseFrame(ctx, video, outputSize, options, 1);
}

/**
 * Stage 4 preview-only fade: clears the canvas, draws the outgoing clip's frame at
 * (1 - alpha), then the incoming clip's frame at alpha on top. Does not clear
 * between the two draws, so they genuinely blend. See resolveTransitionBlend in
 * timelineMath.ts for how alpha/which-two-clips is decided; the real crossfade
 * render is Stage 6's job — this is a same-timeline-length approximation for
 * in-editor preview.
 */
export function drawTransitionFrame(
  canvas: HTMLCanvasElement,
  fromVideo: HTMLVideoElement | null,
  toVideo: HTMLVideoElement | null,
  alpha: number,
  outputSize: OutputSize,
  fromOptions: DrawFrameOptions = {},
  toOptions: DrawFrameOptions = {}
): void {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ensureCanvasSize(canvas, outputSize);
  clearToBlack(ctx, outputSize);
  drawBaseFrame(ctx, fromVideo, outputSize, fromOptions, 1 - alpha);
  drawBaseFrame(ctx, toVideo, outputSize, toOptions, alpha);
}

/** Draws text/sticker overlays only — no clear. Call after the base frame (single
 *  or blended) is drawn, since overlays sit on top regardless of any transition. */
export function drawOverlays(canvas: HTMLCanvasElement, outputSize: OutputSize, overlays: Overlay[]): void {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  const { width, height } = outputSize;

  for (const overlay of overlays) {
    ctx.save();
    ctx.translate(overlay.x * width, overlay.y * height);
    ctx.rotate((overlay.rotationDeg * Math.PI) / 180);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    if (overlay.type === 'sticker') {
      const size = (overlay.scale * width) / 8;
      ctx.font = `${size}px sans-serif`;
      ctx.fillText(overlay.emoji, 0, 0);
    } else {
      const fontSize = (overlay.fontSize / 1000) * width;
      ctx.font = `${fontSize}px ${overlay.fontFamily}`;
      ctx.fillStyle = overlay.color;
      ctx.fillText(overlay.text, 0, 0);
    }
    ctx.restore();
  }
}
