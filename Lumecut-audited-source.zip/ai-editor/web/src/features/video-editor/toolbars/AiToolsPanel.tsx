import { useState } from 'react';
import { VIDEO_AI_TOOLS } from '../constants';
import { videoAiService, type AiJobResult } from '@/features/ai/videoAiService';

interface AiToolsPanelProps {
  sourceUrl: string;
}

/**
 * Script Generator calls the real backend built in Stage 5 (text-in/text-out —
 * no file upload needed, unlike the photo tools). The rest stay on the stub and
 * report a clear "not part of this stage" message.
 */
export function AiToolsPanel({ sourceUrl }: AiToolsPanelProps) {
  const [statusByTool, setStatusByTool] = useState<Record<string, AiJobResult | undefined>>({});
  const [pendingTool, setPendingTool] = useState<string | null>(null);
  const [scriptPrompt, setScriptPrompt] = useState('');

  async function runTool(id: string) {
    setPendingTool(id);
    let result: AiJobResult;
    switch (id) {
      case 'auto-captions':
        result = await videoAiService.generateCaptions(sourceUrl);
        break;
      case 'subtitles':
        result = await videoAiService.generateSubtitles(sourceUrl, 'en');
        break;
      case 'script':
        result = await videoAiService.generateScript(scriptPrompt);
        break;
      case 'caption-text':
        result = await videoAiService.generateCaptionText(sourceUrl);
        break;
      default:
        result = await videoAiService.applyVideoEffect(sourceUrl, id);
    }
    setStatusByTool((prev) => ({ ...prev, [id]: result }));
    setPendingTool(null);
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-2)', padding: 'var(--space-3) var(--space-4)' }}>
      <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', margin: 0 }}>
        Script Generator calls the real backend now (dev mock by default — see
        server/.env.example to point it at a real provider). The rest are wired the
        same way but not part of this stage's build.
      </p>
      {VIDEO_AI_TOOLS.map((tool) => {
        const status = statusByTool[tool.id];
        const pending = pendingTool === tool.id;
        const isScript = tool.id === 'script';

        return (
          <div
            key={tool.id}
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: 6,
              padding: 'var(--space-3)',
              borderRadius: 'var(--radius-md)',
              background: 'var(--color-surface-raised)',
              border: '1px dashed var(--color-border)',
            }}
          >
            <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <span style={{ fontSize: 13, fontWeight: 600 }}>{tool.label}</span>
              <span style={{ fontSize: 11, color: 'var(--color-text-secondary)' }}>{tool.description}</span>
            </div>

            {isScript && (
              <input
                value={scriptPrompt}
                onChange={(e) => setScriptPrompt(e.target.value)}
                placeholder="What's the video about?"
                style={{
                  background: 'var(--color-surface)',
                  border: '1px solid var(--color-border)',
                  borderRadius: 'var(--radius-sm)',
                  color: 'var(--color-text-primary)',
                  padding: 'var(--space-2)',
                  fontSize: 13,
                }}
              />
            )}

            <button
              type="button"
              onClick={() => runTool(tool.id)}
              disabled={pending}
              style={{
                alignSelf: 'flex-start',
                background: 'var(--color-accent)',
                color: '#fff',
                border: 'none',
                borderRadius: 'var(--radius-pill)',
                padding: 'var(--space-1) var(--space-3)',
                fontSize: 12,
                cursor: pending ? 'default' : 'pointer',
                opacity: pending ? 0.6 : 1,
              }}
            >
              {isScript ? 'Generate' : 'Run'}
            </button>

            {pending && <span style={{ fontSize: 11, color: 'var(--color-text-secondary)' }}>Processing…</span>}
            {!pending && status?.status === 'error' && (
              <span style={{ fontSize: 11, color: 'var(--color-danger)' }}>{status.message}</span>
            )}
            {!pending && status?.status === 'unavailable' && (
              <span style={{ fontSize: 11, color: 'var(--color-warning)' }}>{status.message}</span>
            )}
            {!pending && status?.status === 'done' && status.text && (
              <pre
                style={{
                  margin: 0,
                  padding: 'var(--space-2)',
                  background: 'var(--color-surface)',
                  border: '1px solid var(--color-border)',
                  borderRadius: 'var(--radius-sm)',
                  fontSize: 12,
                  color: 'var(--color-text-primary)',
                  whiteSpace: 'pre-wrap',
                  fontFamily: 'inherit',
                }}
              >
                {status.text}
              </pre>
            )}
          </div>
        );
      })}
    </div>
  );
}
