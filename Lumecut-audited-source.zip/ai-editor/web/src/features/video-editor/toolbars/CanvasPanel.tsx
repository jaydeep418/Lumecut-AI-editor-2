import type { AspectRatioId } from '@types/project';
import type { UseVideoEditorResult } from '../useVideoEditor';

interface CanvasPanelProps {
  editor: UseVideoEditorResult;
  selectedClipId: string | null;
  aspectRatio: AspectRatioId;
}

export function CanvasPanel({ editor, selectedClipId, aspectRatio }: CanvasPanelProps) {
  const clip = editor.state.clips.find((c) => c.id === selectedClipId);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)', padding: 'var(--space-3) var(--space-4)' }}>
      <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', margin: 0 }}>
        Output frame: <strong style={{ color: 'var(--color-text-primary)' }}>{aspectRatio}</strong> (set when the
        project was created)
      </p>

      {!clip ? (
        <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', margin: 0 }}>
          Tap a clip on the timeline to rotate or flip it.
        </p>
      ) : (
        <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
          <ActionChip label="Rotate 90°" onClick={() => editor.rotateClip90(clip.id)} />
          <ActionChip label="Flip H" onClick={() => editor.flipClipHorizontal(clip.id)} />
          <ActionChip label="Flip V" onClick={() => editor.flipClipVertical(clip.id)} />
        </div>
      )}
    </div>
  );
}

function ActionChip({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        borderRadius: 'var(--radius-pill)',
        padding: 'var(--space-2) var(--space-3)',
        fontSize: 12,
        cursor: 'pointer',
        border: '1px solid var(--color-border)',
        background: 'var(--color-surface-raised)',
        color: 'var(--color-text-primary)',
      }}
    >
      {label}
    </button>
  );
}
