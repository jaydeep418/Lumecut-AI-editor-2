import type { StickerOverlay } from '../types';
import type { UseVideoEditorResult } from '../useVideoEditor';

const STICKER_EMOJIS = ['😀', '😍', '🔥', '✨', '❤️', '👍', '🎉', '⭐', '🌈', '🎬', '📸', '💯'];

export function StickersPanel({ editor }: { editor: UseVideoEditorResult }) {
  const stickerOverlays = editor.state.overlays.filter((o): o is StickerOverlay => o.type === 'sticker');

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)', padding: 'var(--space-3) var(--space-4)' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 'var(--space-2)' }}>
        {STICKER_EMOJIS.map((emoji) => (
          <button
            key={emoji}
            type="button"
            onClick={() => editor.addStickerOverlay(emoji)}
            style={{
              fontSize: 22,
              background: 'var(--color-surface-raised)',
              border: '1px solid var(--color-border)',
              borderRadius: 'var(--radius-md)',
              padding: 'var(--space-2)',
              cursor: 'pointer',
            }}
          >
            {emoji}
          </button>
        ))}
      </div>

      {stickerOverlays.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', margin: 0 }}>
            Drag a placed sticker on the canvas (while it's visible) to move it.
          </p>
          <div style={{ display: 'flex', gap: 'var(--space-2)', flexWrap: 'wrap' }}>
            {stickerOverlays.map((overlay) => (
              <button
                key={overlay.id}
                type="button"
                onClick={() => editor.removeOverlay(overlay.id)}
                title="Remove"
                style={{
                  fontSize: 16,
                  background: 'var(--color-surface-raised)',
                  border: '1px solid var(--color-border)',
                  borderRadius: 'var(--radius-pill)',
                  padding: 'var(--space-1) var(--space-2)',
                  cursor: 'pointer',
                }}
              >
                {overlay.emoji} ✕
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
