import { useRef, type ChangeEvent } from 'react';
import type { UseVideoEditorResult } from '../useVideoEditor';

interface EditPanelProps {
  editor: UseVideoEditorResult;
  selectedClipId: string | null;
  onSelectClip: (id: string | null) => void;
}

export function EditPanel({ editor, selectedClipId, onSelectClip }: EditPanelProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const selectedClip = editor.state.clips.find((c) => c.id === selectedClipId) ?? null;

  async function handleFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const id = await editor.addClip(file);
    onSelectClip(id);
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)', padding: 'var(--space-3) var(--space-4)' }}>
      <button type="button" onClick={() => inputRef.current?.click()} style={primaryButtonStyle}>
        + Import video
      </button>
      <input ref={inputRef} type="file" accept="video/*" onChange={handleFile} style={{ display: 'none' }} />

      {!selectedClip ? (
        <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', margin: 0 }}>
          Tap a clip on the timeline to edit it.
        </p>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-2)' }}>
          <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', margin: 0 }}>
            Editing: <strong style={{ color: 'var(--color-text-primary)' }}>{selectedClip.name}</strong>
          </p>

          <div style={{ display: 'flex', gap: 'var(--space-2)', flexWrap: 'wrap' }}>
            <ActionButton label="Split at playhead" onClick={editor.splitAtPlayhead} />
            <ActionButton label="◀ Move" onClick={() => editor.moveClip(selectedClip.id, 'left')} />
            <ActionButton label="Move ▶" onClick={() => editor.moveClip(selectedClip.id, 'right')} />
          </div>

          <div style={{ display: 'flex', gap: 'var(--space-2)', alignItems: 'center' }}>
            {selectedClip.groupId ? (
              <>
                <span style={{ fontSize: 11, color: 'var(--color-text-secondary)' }}>🔗 Merged</span>
                <ActionButton label="Unmerge" onClick={() => editor.unmergeGroup(selectedClip.groupId!)} />
              </>
            ) : (
              <ActionButton label="🔗 Merge with next" onClick={() => editor.mergeWithNext(selectedClip.id)} />
            )}
          </div>

          <div style={{ display: 'flex', gap: 'var(--space-2)', alignItems: 'flex-end' }}>
            <label style={numberFieldStyle}>
              Trim in (s)
              <input
                type="number"
                min={0}
                max={selectedClip.outPoint - 0.2}
                step={0.1}
                value={selectedClip.inPoint.toFixed(1)}
                onChange={(e) => editor.trimClip(selectedClip.id, Number(e.target.value), selectedClip.outPoint)}
                style={inputStyle}
              />
            </label>
            <label style={numberFieldStyle}>
              Trim out (s)
              <input
                type="number"
                min={selectedClip.inPoint + 0.2}
                max={selectedClip.sourceDuration}
                step={0.1}
                value={selectedClip.outPoint.toFixed(1)}
                onChange={(e) => editor.trimClip(selectedClip.id, selectedClip.inPoint, Number(e.target.value))}
                style={inputStyle}
              />
            </label>
          </div>

          <button
            type="button"
            onClick={() => {
              editor.removeClip(selectedClip.id);
              onSelectClip(null);
            }}
            style={dangerButtonStyle}
          >
            Delete clip
          </button>
        </div>
      )}
    </div>
  );
}

function ActionButton({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} style={secondaryButtonStyle}>
      {label}
    </button>
  );
}

const primaryButtonStyle = {
  background: 'var(--color-accent)',
  color: '#fff',
  border: 'none',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-2) var(--space-3)',
  fontSize: 13,
  fontWeight: 600,
  cursor: 'pointer',
} as const;

const secondaryButtonStyle = {
  background: 'var(--color-surface-raised)',
  border: '1px solid var(--color-border)',
  color: 'var(--color-text-primary)',
  borderRadius: 'var(--radius-pill)',
  padding: 'var(--space-2) var(--space-3)',
  fontSize: 12,
  cursor: 'pointer',
} as const;

const dangerButtonStyle = {
  background: 'transparent',
  border: '1px solid var(--color-danger)',
  color: 'var(--color-danger)',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-2) var(--space-3)',
  fontSize: 12,
  cursor: 'pointer',
  alignSelf: 'flex-start',
} as const;

const numberFieldStyle = {
  display: 'flex',
  flexDirection: 'column',
  gap: 4,
  fontSize: 11,
  color: 'var(--color-text-secondary)',
  flex: 1,
} as const;

const inputStyle = {
  background: 'var(--color-surface-raised)',
  border: '1px solid var(--color-border)',
  borderRadius: 'var(--radius-sm)',
  color: 'var(--color-text-primary)',
  padding: 'var(--space-2)',
  fontSize: 13,
  width: '100%',
} as const;
