import type { UseVideoEditorResult } from '../useVideoEditor';

interface AudioPanelProps {
  editor: UseVideoEditorResult;
  selectedClipId: string | null;
}

export function AudioPanel({ editor, selectedClipId }: AudioPanelProps) {
  const clip = editor.state.clips.find((c) => c.id === selectedClipId);

  if (!clip) {
    return (
      <div style={{ padding: 'var(--space-3) var(--space-4)' }}>
        <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', margin: 0 }}>
          Tap a clip on the timeline to adjust its audio.
        </p>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)', padding: 'var(--space-3) var(--space-4)' }}>
      <label style={{ display: 'flex', flexDirection: 'column', gap: 4, fontSize: 12, color: 'var(--color-text-secondary)' }}>
        Volume: {Math.round(clip.volume * 100)}%
        <input
          type="range"
          min={0}
          max={100}
          value={Math.round(clip.volume * 100)}
          onChange={(e) => editor.setClipVolume(clip.id, Number(e.target.value) / 100)}
          disabled={clip.muted}
        />
      </label>

      <button
        type="button"
        onClick={() => editor.toggleClipMuted(clip.id)}
        style={{
          alignSelf: 'flex-start',
          borderRadius: 'var(--radius-pill)',
          padding: 'var(--space-2) var(--space-3)',
          fontSize: 12,
          cursor: 'pointer',
          border: clip.muted ? '1px solid var(--color-accent)' : '1px solid var(--color-border)',
          background: clip.muted ? 'var(--color-accent)' : 'var(--color-surface-raised)',
          color: clip.muted ? '#fff' : 'var(--color-text-secondary)',
        }}
      >
        {clip.muted ? 'Muted' : 'Mute clip'}
      </button>

      <p style={{ fontSize: 11, color: 'var(--color-text-secondary)', margin: 0 }}>
        Adding external background music/voice-over tracks lands with the full audio
        mixing pipeline in a later stage.
      </p>
    </div>
  );
}
