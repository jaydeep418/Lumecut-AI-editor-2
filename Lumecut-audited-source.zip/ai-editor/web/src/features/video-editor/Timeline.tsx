import { useRef, type PointerEvent as ReactPointerEvent } from 'react';
import { clipTimelineDuration } from './types';
import type { UseVideoEditorResult } from './useVideoEditor';

interface TimelineProps {
  editor: UseVideoEditorResult;
  selectedClipId: string | null;
  onSelectClip: (id: string) => void;
}

export function Timeline({ editor, selectedClipId, onSelectClip }: TimelineProps) {
  const trackRef = useRef<HTMLDivElement>(null);

  function seekFromClientX(clientX: number) {
    const rect = trackRef.current?.getBoundingClientRect();
    if (!rect || rect.width === 0 || editor.totalDuration <= 0) return;
    const ratio = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
    editor.seek(ratio * editor.totalDuration);
  }

  function handleScrubberPointerDown(e: ReactPointerEvent) {
    e.stopPropagation();
    seekFromClientX(e.clientX);
    const handleMove = (ev: PointerEvent) => seekFromClientX(ev.clientX);
    const handleUp = () => {
      window.removeEventListener('pointermove', handleMove);
      window.removeEventListener('pointerup', handleUp);
    };
    window.addEventListener('pointermove', handleMove);
    window.addEventListener('pointerup', handleUp);
  }

  const playedPct = editor.totalDuration > 0 ? (editor.timelineTime / editor.totalDuration) * 100 : 0;

  return (
    <div style={{ padding: 'var(--space-2) var(--space-4) var(--space-3)' }}>
      <div
        ref={trackRef}
        onPointerDown={handleScrubberPointerDown}
        style={{
          position: 'relative',
          display: 'flex',
          height: 52,
          borderRadius: 'var(--radius-sm)',
          overflow: 'hidden',
          background: 'var(--color-surface-raised)',
          cursor: 'pointer',
          touchAction: 'none',
        }}
      >
        {editor.state.clips.length === 0 ? (
          <div
            style={{
              flex: 1,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 11,
              color: 'var(--color-text-secondary)',
            }}
          >
            Import a video to get started
          </div>
        ) : (
          editor.state.clips.map((clip, index) => {
            const duration = clipTimelineDuration(clip);
            const widthPct = editor.totalDuration > 0 ? (duration / editor.totalDuration) * 100 : 0;
            const selected = clip.id === selectedClipId;
            const nextClip = editor.state.clips[index + 1];
            // Merged clips render edge-to-edge (no gap) as a visual cue that
            // they're presented as one continuous unit — see mergeClips in
            // useVideoEditor.ts. Purely visual; each clip keeps its own data.
            const mergedWithNext = clip.groupId !== null && nextClip?.groupId === clip.groupId;
            return (
              <button
                key={clip.id}
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectClip(clip.id);
                }}
                style={{
                  flex: `0 0 ${widthPct}%`,
                  minWidth: 24,
                  height: '100%',
                  marginRight: mergedWithNext ? 0 : 2,
                  border: selected ? '2px solid var(--color-accent)' : '1px solid var(--color-border)',
                  background: 'var(--color-surface)',
                  color: 'var(--color-text-secondary)',
                  fontSize: 10,
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  whiteSpace: 'nowrap',
                  padding: '0 4px',
                  cursor: 'pointer',
                }}
                title={clip.name}
              >
                {clip.groupId ? '🔗 ' : ''}
                {clip.name}
              </button>
            );
          })
        )}

        {/* playhead */}
        <div
          style={{
            position: 'absolute',
            left: `${playedPct}%`,
            top: 0,
            bottom: 0,
            width: 2,
            background: '#fff',
            pointerEvents: 'none',
          }}
        />
      </div>
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          fontSize: 10,
          color: 'var(--color-text-secondary)',
          marginTop: 4,
        }}
      >
        <span>{formatTime(editor.timelineTime)}</span>
        <span>{formatTime(editor.totalDuration)}</span>
      </div>
    </div>
  );
}

function formatTime(seconds: number): string {
  const s = Math.max(0, Math.floor(seconds));
  const m = Math.floor(s / 60);
  const remaining = s % 60;
  return `${m}:${remaining.toString().padStart(2, '0')}`;
}
