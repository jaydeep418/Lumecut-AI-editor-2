import { useState, type CSSProperties } from 'react';
import { useNavigate } from 'react-router-dom';
import { ASPECT_RATIOS } from '@/constants/aspectRatios';
import type { AspectRatioId, Project } from '@types/project';
import { PhotoCanvas } from './PhotoCanvas';
import { computeCenteredCrop, computeNormalizedAspectRatio } from './cropMath';
import { PHOTO_TOOLS, type PhotoTool } from './constants';
import type { CropRect } from './types';
import { usePhotoEditor } from './usePhotoEditor';
import { AdjustPanel } from './toolbars/AdjustPanel';
import { AiToolsPanel } from './toolbars/AiToolsPanel';
import { CropPanel } from './toolbars/CropPanel';
import { DrawPanel } from './toolbars/DrawPanel';
import { FiltersPanel } from './toolbars/FiltersPanel';
import { StickersPanel } from './toolbars/StickersPanel';
import { TextPanel } from './toolbars/TextPanel';
import { PhotoExportPanel } from '@/features/export/PhotoExportPanel';

export function PhotoEditor({ project }: { project: Project }) {
  const navigate = useNavigate();
  const editor = usePhotoEditor(project.previewUrl);

  const [activeTool, setActiveTool] = useState<PhotoTool>('adjust');
  const [draftCrop, setDraftCrop] = useState<CropRect | null>(null);
  const [lockedRatioId, setLockedRatioId] = useState<AspectRatioId | 'free'>(project.aspectRatio);
  const [drawColor, setDrawColor] = useState('#ffffff');
  const [drawSize, setDrawSize] = useState(8);
  const [showExport, setShowExport] = useState(false);

  function ratioById(id: AspectRatioId | 'free') {
    return id === 'free' ? null : (ASPECT_RATIOS.find((r) => r.id === id) ?? null);
  }

  function openCropTool() {
    if (!editor.image) return;
    const existing = editor.state.transform.crop;
    if (existing) {
      // Editing an already-applied crop — start from it rather than recomputing.
      setDraftCrop(existing);
      setLockedRatioId('free');
    } else {
      setDraftCrop(computeCenteredCrop(ratioById(lockedRatioId), editor.image.width, editor.image.height));
    }
    setActiveTool('crop');
  }

  function selectTool(tool: PhotoTool) {
    if (tool === 'crop') {
      openCropTool();
      return;
    }
    setDraftCrop(null); // discard any unapplied crop draft when leaving the crop tool
    setActiveTool(tool);
  }

  function handleSelectRatio(id: AspectRatioId | 'free') {
    setLockedRatioId(id);
    if (!editor.image) return;
    setDraftCrop(computeCenteredCrop(ratioById(id), editor.image.width, editor.image.height));
  }

  function handleApplyCrop() {
    if (draftCrop) editor.commitCrop(draftCrop);
    setDraftCrop(null);
    setActiveTool('adjust');
  }

  function handleCancelCrop() {
    setDraftCrop(null);
    setActiveTool('adjust');
  }

  const lockedNormalizedRatio =
    editor.image && lockedRatioId !== 'free'
      ? computeNormalizedAspectRatio(ratioById(lockedRatioId)!, editor.image.width, editor.image.height)
      : null;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Top bar */}
      <header
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: 'var(--space-3) var(--space-4)',
          borderBottom: '1px solid var(--color-border)',
          background: 'var(--color-surface)',
        }}
      >
        <button onClick={() => navigate('/')} style={iconButtonStyle} aria-label="Back">
          ←
        </button>
        <span style={{ fontSize: 14, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {project.name}{' '}
          <span style={{ fontWeight: 400, fontSize: 12, color: 'var(--color-text-secondary)' }}>
            · {project.aspectRatio}
          </span>
        </span>
        <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
          <button
            onClick={editor.undo}
            disabled={!editor.canUndo}
            style={{ ...iconButtonStyle, opacity: editor.canUndo ? 1 : 0.35 }}
            title="Undo"
          >
            ↶
          </button>
          <button
            onClick={editor.redo}
            disabled={!editor.canRedo}
            style={{ ...iconButtonStyle, opacity: editor.canRedo ? 1 : 0.35 }}
            title="Redo"
          >
            ↷
          </button>
          <button
            onClick={() => setShowExport(true)}
            disabled={!editor.image}
            style={{ ...iconButtonStyle, opacity: editor.image ? 1 : 0.35 }}
            title="Export"
          >
            Export
          </button>
        </div>
      </header>

      {/* Center preview */}
      <div style={{ flex: 1, minHeight: 0, background: '#000' }}>
        {editor.loadError ? (
          <div style={centerMessageStyle}>Couldn't load this image: {editor.loadError}</div>
        ) : !editor.image ? (
          <div style={centerMessageStyle}>Loading photo…</div>
        ) : (
          <PhotoCanvas
            editor={editor}
            activeTool={activeTool}
            drawColor={drawColor}
            drawSize={drawSize}
            cropMode={
              activeTool === 'crop' && draftCrop
                ? { draftCrop, onDraftCropChange: setDraftCrop, lockedNormalizedRatio }
                : undefined
            }
          />
        )}
      </div>

      {/* Bottom: active tool panel + tool tabs */}
      <div style={{ borderTop: '1px solid var(--color-border)', background: 'var(--color-surface)' }}>
        {editor.image && (
          <div>
            {activeTool === 'crop' && draftCrop && (
              <CropPanel
                editor={editor}
                lockedRatioId={lockedRatioId}
                onSelectRatio={handleSelectRatio}
                onApply={handleApplyCrop}
                onCancel={handleCancelCrop}
              />
            )}
            {activeTool === 'adjust' && <AdjustPanel editor={editor} />}
            {activeTool === 'filters' && <FiltersPanel editor={editor} />}
            {activeTool === 'text' && <TextPanel editor={editor} />}
            {activeTool === 'stickers' && <StickersPanel editor={editor} />}
            {activeTool === 'draw' && (
              <DrawPanel editor={editor} color={drawColor} size={drawSize} onColorChange={setDrawColor} onSizeChange={setDrawSize} />
            )}
            {activeTool === 'ai' && <AiToolsPanel sourceUrl={project.previewUrl} />}
          </div>
        )}

        <div style={{ display: 'flex', overflowX: 'auto', padding: 'var(--space-2) var(--space-2) var(--space-3)', gap: 'var(--space-2)' }}>
          {PHOTO_TOOLS.map((tool) => {
            const active = activeTool === tool.id;
            return (
              <button
                key={tool.id}
                type="button"
                onClick={() => selectTool(tool.id)}
                style={{
                  flex: '0 0 auto',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: 2,
                  background: active ? 'var(--color-accent)' : 'var(--color-surface-raised)',
                  border: active ? '1px solid var(--color-accent)' : '1px solid var(--color-border)',
                  color: active ? '#fff' : 'var(--color-text-secondary)',
                  borderRadius: 'var(--radius-pill)',
                  padding: 'var(--space-2) var(--space-3)',
                  fontSize: 11,
                }}
              >
                <span style={{ fontSize: 16 }}>{tool.icon}</span>
                {tool.label}
              </button>
            );
          })}
        </div>
      </div>

      {showExport && editor.image && (
        <PhotoExportPanel image={editor.image} state={editor.state} project={project} onClose={() => setShowExport(false)} />
      )}
    </div>
  );
}

const iconButtonStyle: CSSProperties = {
  background: 'transparent',
  border: 'none',
  color: 'var(--color-text-primary)',
  fontSize: 16,
  cursor: 'pointer',
};

const centerMessageStyle: CSSProperties = {
  height: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  color: 'var(--color-text-secondary)',
  fontSize: 13,
  padding: 'var(--space-4)',
  textAlign: 'center',
};
