import { useEffect, useState } from 'react';
import { useHistoryState } from '@/features/shared/history';
import { loadImage, type LoadedImage } from './canvasRenderer';
import {
  createInitialPhotoEditState,
  type Adjustments,
  type CropRect,
  type DrawingStroke,
  type FilterId,
  type Layer,
  type LayerPatch,
  type PhotoEditState,
} from './types';

export function usePhotoEditor(sourceUrl: string) {
  const [image, setImage] = useState<LoadedImage | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const history = useHistoryState<PhotoEditState>(createInitialPhotoEditState());

  useEffect(() => {
    let cancelled = false;
    setImage(null);
    setLoadError(null);
    loadImage(sourceUrl)
      .then((loaded) => {
        if (!cancelled) setImage(loaded);
      })
      .catch((err: Error) => {
        if (!cancelled) setLoadError(err.message);
      });
    return () => {
      cancelled = true;
    };
  }, [sourceUrl]);

  const { state } = history;

  // --- Adjustments: live while dragging, one history entry on release ---
  function previewAdjustment(partial: Partial<Adjustments>) {
    history.setLive({ ...state, adjustments: { ...state.adjustments, ...partial } });
  }
  function commitAdjustment(partial: Partial<Adjustments>) {
    history.commit({ ...state, adjustments: { ...state.adjustments, ...partial } });
  }

  // --- Filter preset: single discrete action, always a full history entry ---
  function setFilter(filter: FilterId) {
    history.commit({ ...state, filter });
  }

  // --- Transform: rotate/flip/crop are discrete actions ---
  function rotate90() {
    const rotationDeg = ((state.transform.rotationDeg + 90) % 360) as 0 | 90 | 180 | 270;
    history.commit({ ...state, transform: { ...state.transform, rotationDeg } });
  }
  function flipHorizontal() {
    history.commit({
      ...state,
      transform: { ...state.transform, flipHorizontal: !state.transform.flipHorizontal },
    });
  }
  function flipVertical() {
    history.commit({
      ...state,
      transform: { ...state.transform, flipVertical: !state.transform.flipVertical },
    });
  }
  function setTargetMaxDimension(targetMaxDimension: number | null) {
    history.commit({ ...state, transform: { ...state.transform, targetMaxDimension } });
  }
  function commitCrop(crop: CropRect | null) {
    history.commit({ ...state, transform: { ...state.transform, crop } });
  }

  // --- Layers: add/update/remove text & sticker layers ---
  function addLayer(layer: Layer) {
    history.commit({ ...state, layers: [...state.layers, layer] });
  }
  function updateLayer(id: string, partial: LayerPatch) {
    history.commit({
      ...state,
      layers: state.layers.map((l) => (l.id === id ? ({ ...l, ...partial } as Layer) : l)),
    });
  }
  function previewLayerPosition(id: string, x: number, y: number) {
    history.setLive({
      ...state,
      layers: state.layers.map((l) => (l.id === id ? { ...l, x, y } : l)),
    });
  }
  function removeLayer(id: string) {
    history.commit({ ...state, layers: state.layers.filter((l) => l.id !== id) });
  }

  // --- Drawing: a stroke is committed once, when the pointer lifts ---
  function addStroke(stroke: DrawingStroke) {
    history.commit({ ...state, strokes: [...state.strokes, stroke] });
  }
  function clearStrokes() {
    history.commit({ ...state, strokes: [] });
  }

  return {
    image,
    loadError,
    state,
    canUndo: history.canUndo,
    canRedo: history.canRedo,
    undo: history.undo,
    redo: history.redo,
    previewAdjustment,
    commitAdjustment,
    setFilter,
    rotate90,
    flipHorizontal,
    flipVertical,
    setTargetMaxDimension,
    commitCrop,
    addLayer,
    updateLayer,
    previewLayerPosition,
    removeLayer,
    addStroke,
    clearStrokes,
  };
}

export type UsePhotoEditorResult = ReturnType<typeof usePhotoEditor>;
