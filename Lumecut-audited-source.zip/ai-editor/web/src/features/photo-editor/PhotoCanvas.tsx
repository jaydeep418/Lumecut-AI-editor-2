import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import { renderPhotoEdit } from './canvasRenderer';
import { CropOverlay } from './CropOverlay';
import { NEUTRAL_ADJUSTMENTS } from './types';
import type { CropRect, DrawingStroke, Layer } from './types';
import type { PhotoTool } from './constants';
import type { UsePhotoEditorResult } from './usePhotoEditor';

interface CropModeProps {
  draftCrop: CropRect;
  onDraftCropChange: (next: CropRect) => void;
  lockedNormalizedRatio: number | null;
}

interface PhotoCanvasProps {
  editor: UsePhotoEditorResult;
  activeTool: PhotoTool;
  drawColor: string;
  drawSize: number;
  cropMode?: CropModeProps;
}

const LAYER_HIT_RADIUS = 0.08; // normalized distance; generous enough for touch

export function PhotoCanvas({ editor, activeTool, drawColor, drawSize, cropMode }: PhotoCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  // Sized via inline-block + line-height:0 so it shrink-wraps exactly to the canvas's
  // rendered box — pointer math and the crop overlay both key off THIS element's
  // bounding rect, not the (possibly larger, letterboxed) outer flex container.
  const mediaRef = useRef<HTMLDivElement>(null);
  const [draftStroke, setDraftStroke] = useState<DrawingStroke | null>(null);
  const draggingLayerId = useRef<string | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !editor.image) return;

    if (cropMode) {
      // Crop is defined relative to the ORIGINAL, un-rotated-by-this-step image —
      // show it plainly (no crop, neutral color) so the user can see the whole frame.
      renderPhotoEdit(canvas, editor.image, {
        ...editor.state,
        transform: { ...editor.state.transform, crop: null },
        adjustments: NEUTRAL_ADJUSTMENTS,
        filter: 'none',
      });
    } else {
      renderPhotoEdit(canvas, editor.image, editor.state, draftStroke ? { draftStroke } : undefined);
    }
  }, [editor.image, editor.state, draftStroke, cropMode]);

  function getNormalizedPoint(e: ReactPointerEvent): { x: number; y: number } | null {
    const rect = mediaRef.current?.getBoundingClientRect();
    if (!rect || rect.width === 0 || rect.height === 0) return null;
    return {
      x: clamp01((e.clientX - rect.left) / rect.width),
      y: clamp01((e.clientY - rect.top) / rect.height),
    };
  }

  function hitTestLayer(layers: Layer[], point: { x: number; y: number }, tool: PhotoTool): Layer | null {
    for (let i = layers.length - 1; i >= 0; i--) {
      const layer = layers[i];
      if (tool === 'text' && layer.type !== 'text') continue;
      if (tool === 'stickers' && layer.type !== 'sticker') continue;
      const dx = layer.x - point.x;
      const dy = layer.y - point.y;
      if (Math.sqrt(dx * dx + dy * dy) < LAYER_HIT_RADIUS) return layer;
    }
    return null;
  }

  function handlePointerDown(e: ReactPointerEvent) {
    if (cropMode) return; // CropOverlay owns pointer handling while cropping
    const point = getNormalizedPoint(e);
    if (!point) return;

    if (activeTool === 'draw') {
      setDraftStroke({ id: crypto.randomUUID(), points: [point], color: drawColor, size: drawSize });
      (e.target as Element).setPointerCapture?.(e.pointerId);
      return;
    }

    if (activeTool === 'text' || activeTool === 'stickers') {
      const hit = hitTestLayer(editor.state.layers, point, activeTool);
      if (hit) {
        draggingLayerId.current = hit.id;
        (e.target as Element).setPointerCapture?.(e.pointerId);
      }
    }
  }

  function handlePointerMove(e: ReactPointerEvent) {
    if (cropMode) return;
    const point = getNormalizedPoint(e);
    if (!point) return;

    if (activeTool === 'draw' && draftStroke) {
      setDraftStroke({ ...draftStroke, points: [...draftStroke.points, point] });
      return;
    }

    if (draggingLayerId.current) {
      editor.previewLayerPosition(draggingLayerId.current, point.x, point.y);
    }
  }

  function handlePointerUp() {
    if (cropMode) return;

    if (activeTool === 'draw' && draftStroke) {
      if (draftStroke.points.length > 1) {
        editor.addStroke(draftStroke);
      }
      setDraftStroke(null);
    }

    if (draggingLayerId.current) {
      const id = draggingLayerId.current;
      const layer = editor.state.layers.find((l) => l.id === id);
      draggingLayerId.current = null;
      // Records ONE history entry for the whole drag (previewLayerPosition above was
      // live-only) — same value it's already showing, just now committed.
      if (layer) {
        editor.updateLayer(id, { x: layer.x, y: layer.y });
      }
    }
  }

  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <div
        ref={mediaRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        style={{
          position: 'relative',
          display: 'inline-block',
          lineHeight: 0,
          maxWidth: '100%',
          maxHeight: '100%',
          touchAction: activeTool === 'draw' || cropMode ? 'none' : 'auto',
          userSelect: 'none',
        }}
      >
        <canvas ref={canvasRef} style={{ display: 'block', maxWidth: '100%', maxHeight: '100%' }} />
        {cropMode && (
          <CropOverlay
            crop={cropMode.draftCrop}
            onChange={cropMode.onDraftCropChange}
            lockedNormalizedRatio={cropMode.lockedNormalizedRatio}
          />
        )}
      </div>
    </div>
  );
}

function clamp01(v: number): number {
  return Math.min(1, Math.max(0, v));
}
