import { useRef, type CSSProperties, type PointerEvent as ReactPointerEvent } from 'react';
import type { CropRect } from './types';

interface CropOverlayProps {
  crop: CropRect;
  onChange: (next: CropRect) => void;
  /** Locked width/height ratio in NORMALIZED terms (already adjusted for the source
   *  image's real pixel aspect ratio) — see computeNormalizedAspectRatio in
   *  cropMath.ts. null = free-form resize. */
  lockedNormalizedRatio: number | null;
}

const MIN_SIZE = 0.1;

function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

export function CropOverlay({ crop, onChange, lockedNormalizedRatio }: CropOverlayProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<{
    mode: 'move' | 'resize';
    startClientX: number;
    startClientY: number;
    startCrop: CropRect;
    containerWidth: number;
    containerHeight: number;
  } | null>(null);

  function handlePointerMove(e: PointerEvent) {
    const drag = dragRef.current;
    if (!drag) return;
    const dxNorm = (e.clientX - drag.startClientX) / drag.containerWidth;
    const dyNorm = (e.clientY - drag.startClientY) / drag.containerHeight;

    if (drag.mode === 'move') {
      const x = clamp(drag.startCrop.x + dxNorm, 0, 1 - drag.startCrop.width);
      const y = clamp(drag.startCrop.y + dyNorm, 0, 1 - drag.startCrop.height);
      onChange({ ...drag.startCrop, x, y });
    } else {
      let width = clamp(drag.startCrop.width + dxNorm, MIN_SIZE, 1 - drag.startCrop.x);
      let height = lockedNormalizedRatio
        ? width / lockedNormalizedRatio
        : clamp(drag.startCrop.height + dyNorm, MIN_SIZE, 1 - drag.startCrop.y);

      if (drag.startCrop.y + height > 1) {
        height = 1 - drag.startCrop.y;
        if (lockedNormalizedRatio) width = height * lockedNormalizedRatio;
      }
      onChange({ ...drag.startCrop, width, height });
    }
  }

  function endDrag() {
    dragRef.current = null;
    window.removeEventListener('pointermove', handlePointerMove);
    window.removeEventListener('pointerup', endDrag);
  }

  function beginDrag(e: ReactPointerEvent, mode: 'move' | 'resize') {
    e.preventDefault();
    e.stopPropagation();
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    dragRef.current = {
      mode,
      startClientX: e.clientX,
      startClientY: e.clientY,
      startCrop: crop,
      containerWidth: rect.width,
      containerHeight: rect.height,
    };
    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', endDrag);
  }

  return (
    <div ref={containerRef} style={{ position: 'absolute', inset: 0 }}>
      {/* dim mask outside the crop rect, as 4 non-overlapping bands */}
      <div style={maskStyle(0, 0, 100, crop.y * 100)} />
      <div style={maskStyle(0, (crop.y + crop.height) * 100, 100, 100 - (crop.y + crop.height) * 100)} />
      <div style={maskStyle(0, crop.y * 100, crop.x * 100, crop.height * 100)} />
      <div
        style={maskStyle(
          (crop.x + crop.width) * 100,
          crop.y * 100,
          100 - (crop.x + crop.width) * 100,
          crop.height * 100
        )}
      />

      <div
        onPointerDown={(e) => beginDrag(e, 'move')}
        style={{
          position: 'absolute',
          left: `${crop.x * 100}%`,
          top: `${crop.y * 100}%`,
          width: `${crop.width * 100}%`,
          height: `${crop.height * 100}%`,
          border: '2px solid #fff',
          boxSizing: 'border-box',
          cursor: 'move',
          touchAction: 'none',
        }}
      >
        <div
          onPointerDown={(e) => beginDrag(e, 'resize')}
          style={{
            position: 'absolute',
            right: -12,
            bottom: -12,
            width: 26,
            height: 26,
            borderRadius: '50%',
            background: '#fff',
            border: '2px solid var(--color-accent)',
            cursor: 'nwse-resize',
            touchAction: 'none',
          }}
        />
      </div>
    </div>
  );
}

function maskStyle(leftPct: number, topPct: number, widthPct: number, heightPct: number): CSSProperties {
  return {
    position: 'absolute',
    left: `${leftPct}%`,
    top: `${topPct}%`,
    width: `${Math.max(0, widthPct)}%`,
    height: `${Math.max(0, heightPct)}%`,
    background: 'rgba(0, 0, 0, 0.55)',
  };
}
