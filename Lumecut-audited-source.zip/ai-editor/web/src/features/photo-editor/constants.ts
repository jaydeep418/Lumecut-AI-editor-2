export type PhotoTool = 'crop' | 'adjust' | 'filters' | 'text' | 'stickers' | 'draw' | 'ai';

export const PHOTO_TOOLS: Array<{ id: PhotoTool; label: string; icon: string }> = [
  { id: 'crop', label: 'Crop', icon: '⬚' },
  { id: 'adjust', label: 'Adjust', icon: '☀' },
  { id: 'filters', label: 'Filters', icon: '◐' },
  { id: 'text', label: 'Text', icon: 'T' },
  { id: 'stickers', label: 'Stickers', icon: '☺' },
  { id: 'draw', label: 'Draw', icon: '✎' },
  { id: 'ai', label: 'AI', icon: '✦' },
];

export const STICKER_EMOJIS = ['😀', '😍', '🔥', '✨', '❤️', '👍', '🎉', '⭐', '🌈', '🎬', '📸', '💯'];

export const TEXT_COLORS = ['#ffffff', '#000000', '#ff5c5c', '#5c9dff', '#ffd15c', '#5cff9d'];
export const DRAW_COLORS = ['#ffffff', '#000000', '#ff5c5c', '#5c9dff', '#ffd15c', '#5cff9d'];
export const FONT_FAMILIES = ['sans-serif', 'serif', 'monospace', 'cursive'];

export const AI_TOOLS: Array<{ id: string; label: string; description: string }> = [
  { id: 'remove-bg', label: 'Background Remover', description: 'Cut the subject out from its background.' },
  { id: 'replace-bg', label: 'Background Replacement', description: 'Swap in an AI-generated background.' },
  { id: 'enhance', label: 'Photo Enhancer', description: 'Sharpen detail and balance exposure automatically.' },
  { id: 'upscale', label: 'Image Upscaler', description: 'Increase resolution while preserving detail.' },
  { id: 'object-removal', label: 'Object Removal', description: 'Erase unwanted objects from the photo.' },
  { id: 'effects', label: 'AI Effects', description: 'Apply generative style effects.' },
];
