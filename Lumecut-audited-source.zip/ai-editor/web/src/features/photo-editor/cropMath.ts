import type { CropRect } from './types';

interface SimpleRatio {
  w: number;
  h: number;
}

/** Largest centered crop rect matching `ratio`'s real-world aspect within the full
 *  image. Returns the full-image rect (no ratio lock) when `ratio` is null. */
export function computeCenteredCrop(ratio: SimpleRatio | null, imageWidth: number, imageHeight: number): CropRect {
  if (!ratio || imageWidth <= 0 || imageHeight <= 0) {
    return { x: 0, y: 0, width: 1, height: 1 };
  }
  const imageAspect = imageWidth / imageHeight;
  const targetAspect = ratio.w / ratio.h;
  const normWidth = Math.min(1, targetAspect / imageAspect);
  const normHeight = Math.min(1, imageAspect / targetAspect);
  return { x: (1 - normWidth) / 2, y: (1 - normHeight) / 2, width: normWidth, height: normHeight };
}

/** Converts a real-world aspect ratio (e.g. 9:16) into the normalized width/height
 *  ratio that keeps CropOverlay's resize-drag locked to that shape, accounting for
 *  the source image's own (usually non-square-pixel-space) dimensions. */
export function computeNormalizedAspectRatio(ratio: SimpleRatio, imageWidth: number, imageHeight: number): number {
  const imageAspect = imageWidth / imageHeight;
  const targetAspect = ratio.w / ratio.h;
  return targetAspect / imageAspect;
}
