import type { ChangeEvent, KeyboardEvent, PointerEvent } from 'react';

interface AdjustmentSliderProps {
  label: string;
  value: number;
  min: number;
  max: number;
  onLiveChange: (value: number) => void;
  onCommit: (value: number) => void;
}

export function AdjustmentSlider({ label, value, min, max, onLiveChange, onCommit }: AdjustmentSliderProps) {
  function handleChange(e: ChangeEvent<HTMLInputElement>) {
    onLiveChange(Number(e.target.value));
  }
  function handleRelease(e: PointerEvent<HTMLInputElement> | KeyboardEvent<HTMLInputElement>) {
    onCommit(Number((e.target as HTMLInputElement).value));
  }

  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 4, fontSize: 12 }}>
      <span style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--color-text-secondary)' }}>
        <span>{label}</span>
        <span>{value}</span>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={handleChange}
        onPointerUp={handleRelease}
        onKeyUp={handleRelease}
        style={{ width: '100%' }}
      />
    </label>
  );
}
