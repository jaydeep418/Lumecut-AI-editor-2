import { useState } from 'react';
import { AI_TOOLS } from '../constants';
import { photoAiService, type AiJobResult } from '@/features/ai/photoAiService';

interface AiToolsPanelProps {
  sourceUrl: string;
}

/**
 * Every button here calls through `photoAiService`. Two tools (Background
 * Remover, Photo Enhancer) hit the real backend built in Stage 5 — the rest stay
 * on the stub and report a clear "not part of this stage" message. Nothing here
 * needed to change to pick up the real ones; only the service implementation
 * behind the interface did (see features/ai/photoAiService.ts).
 */
export function AiToolsPanel({ sourceUrl }: AiToolsPanelProps) {
  const [statusByTool, setStatusByTool] = useState<Record<string, AiJobResult | undefined>>({});
  const [pendingTool, setPendingTool] = useState<string | null>(null);

  async function runTool(id: string) {
    setPendingTool(id);
    let result: AiJobResult;
    switch (id) {
      case 'remove-bg':
        result = await photoAiService.removeBackground(sourceUrl);
        break;
      case 'replace-bg':
        result = await photoAiService.replaceBackground(sourceUrl, 'default');
        break;
      case 'enhance':
        result = await photoAiService.enhance(sourceUrl);
        break;
      case 'upscale':
        result = await photoAiService.upscale(sourceUrl, 2);
        break;
      default:
        result = await photoAiService.applyEffect(sourceUrl, id);
    }
    setStatusByTool((prev) => ({ ...prev, [id]: result }));
    setPendingTool(null);
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-2)', padding: 'var(--space-3) var(--space-4)' }}>
      <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', margin: 0 }}>
        Background Remover and Photo Enhancer call the real backend now (dev mock by
        default — see server/.env.example to point it at a real provider). The rest
        are wired the same way but not part of this stage's build.
      </p>
      {AI_TOOLS.map((tool) => {
        const status = statusByTool[tool.id];
        const pending = pendingTool === tool.id;
        return (
          <div
            key={tool.id}
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: 6,
              padding: 'var(--space-3)',
              borderRadius: 'var(--radius-md)',
              background: 'var(--color-surface-raised)',
              border: '1px dashed var(--color-border)',
            }}
          >
            <button
              type="button"
              onClick={() => runTool(tool.id)}
              disabled={pending}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'flex-start',
                gap: 2,
                background: 'none',
                border: 'none',
                padding: 0,
                color: 'var(--color-text-primary)',
                textAlign: 'left',
                cursor: pending ? 'default' : 'pointer',
                opacity: pending ? 0.6 : 1,
              }}
            >
              <span style={{ fontSize: 13, fontWeight: 600 }}>{tool.label}</span>
              <span style={{ fontSize: 11, color: 'var(--color-text-secondary)' }}>{tool.description}</span>
            </button>

            {pending && (
              <span style={{ fontSize: 11, color: 'var(--color-text-secondary)' }}>Processing…</span>
            )}
            {!pending && status && status.status === 'error' && (
              <span style={{ fontSize: 11, color: 'var(--color-danger)' }}>{status.message}</span>
            )}
            {!pending && status && status.status === 'unavailable' && (
              <span style={{ fontSize: 11, color: 'var(--color-warning)' }}>{status.message}</span>
            )}
            {!pending && status?.status === 'done' && status.resultUrl && (
              <img
                src={status.resultUrl}
                alt={`${tool.label} result`}
                style={{ maxWidth: '100%', maxHeight: 160, borderRadius: 'var(--radius-sm)', objectFit: 'contain' }}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}
