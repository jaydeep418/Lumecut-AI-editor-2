import { useState } from 'react';
import { DRAW_COLORS } from '../constants';
import type { UsePhotoEditorResult } from '../usePhotoEditor';

interface DrawPanelProps {
  editor: UsePhotoEditorResult;
  color: string;
  size: number;
  onColorChange: (color: string) => void;
  onSizeChange: (size: number) => void;
}

export function DrawPanel({ editor, color, size, onColorChange, onSizeChange }: DrawPanelProps) {
  const [confirmingClear, setConfirmingClear] = useState(false);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)', padding: 'var(--space-3) var(--space-4)' }}>
      <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', margin: 0 }}>
        Draw directly on the photo above with your finger or mouse.
      </p>

      <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
        {DRAW_COLORS.map((c) => (
          <button
            key={c}
            type="button"
            aria-label={`Color ${c}`}
            onClick={() => onColorChange(c)}
            style={{
              width: 28,
              height: 28,
              borderRadius: '50%',
              background: c,
              border: color === c ? '2px solid var(--color-accent)' : '1px solid var(--color-border)',
              cursor: 'pointer',
            }}
          />
        ))}
      </div>

      <label style={{ display: 'flex', flexDirection: 'column', gap: 4, fontSize: 12, color: 'var(--color-text-secondary)' }}>
        Brush size: {size}
        <input
          type="range"
          min={2}
          max={40}
          value={size}
          onChange={(e) => onSizeChange(Number(e.target.value))}
        />
      </label>

      {editor.state.strokes.length > 0 &&
        (confirmingClear ? (
          <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
            <span style={{ fontSize: 12, color: 'var(--color-text-secondary)', alignSelf: 'center' }}>Clear all drawing?</span>
            <button
              type="button"
              onClick={() => {
                editor.clearStrokes();
                setConfirmingClear(false);
              }}
              style={dangerButtonStyle}
            >
              Yes, clear
            </button>
            <button type="button" onClick={() => setConfirmingClear(false)} style={secondaryButtonStyle}>
              Cancel
            </button>
          </div>
        ) : (
          <button type="button" onClick={() => setConfirmingClear(true)} style={secondaryButtonStyle}>
            Clear drawing
          </button>
        ))}
    </div>
  );
}

const secondaryButtonStyle = {
  alignSelf: 'flex-start',
  background: 'var(--color-surface-raised)',
  border: '1px solid var(--color-border)',
  color: 'var(--color-text-primary)',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-2) var(--space-3)',
  fontSize: 12,
  cursor: 'pointer',
} as const;

const dangerButtonStyle = {
  background: 'var(--color-danger)',
  border: 'none',
  color: '#fff',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-2) var(--space-3)',
  fontSize: 12,
  cursor: 'pointer',
} as const;
