import { useState } from 'react';
import { FONT_FAMILIES, TEXT_COLORS } from '../constants';
import type { TextLayer } from '../types';
import type { UsePhotoEditorResult } from '../usePhotoEditor';

export function TextPanel({ editor }: { editor: UsePhotoEditorResult }) {
  const textLayers = editor.state.layers.filter((l): l is TextLayer => l.type === 'text');
  const [selectedId, setSelectedId] = useState<string | null>(textLayers[0]?.id ?? null);
  const selected = textLayers.find((l) => l.id === selectedId) ?? null;

  function addText() {
    const layer: TextLayer = {
      id: crypto.randomUUID(),
      type: 'text',
      text: 'Tap to edit',
      x: 0.5,
      y: 0.5,
      fontSize: 60,
      color: '#ffffff',
      fontFamily: 'sans-serif',
      rotationDeg: 0,
    };
    editor.addLayer(layer);
    setSelectedId(layer.id);
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)', padding: 'var(--space-3) var(--space-4)' }}>
      <button type="button" onClick={addText} style={addButtonStyle}>
        + Add text
      </button>

      {textLayers.length > 0 && (
        <div style={{ display: 'flex', gap: 'var(--space-2)', overflowX: 'auto' }}>
          {textLayers.map((layer) => (
            <button
              key={layer.id}
              type="button"
              onClick={() => setSelectedId(layer.id)}
              style={{
                flex: '0 0 auto',
                padding: 'var(--space-2) var(--space-3)',
                borderRadius: 'var(--radius-pill)',
                fontSize: 12,
                border: layer.id === selectedId ? '1px solid var(--color-accent)' : '1px solid var(--color-border)',
                background: layer.id === selectedId ? 'var(--color-accent)' : 'var(--color-surface-raised)',
                color: layer.id === selectedId ? '#fff' : 'var(--color-text-secondary)',
                maxWidth: 120,
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              }}
            >
              {layer.text || 'Text'}
            </button>
          ))}
        </div>
      )}

      {selected && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-2)' }}>
          <input
            value={selected.text}
            onChange={(e) => editor.updateLayer(selected.id, { text: e.target.value })}
            placeholder="Text"
            style={inputStyle}
          />

          <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
            {TEXT_COLORS.map((color) => (
              <button
                key={color}
                type="button"
                aria-label={`Color ${color}`}
                onClick={() => editor.updateLayer(selected.id, { color })}
                style={{
                  width: 26,
                  height: 26,
                  borderRadius: '50%',
                  background: color,
                  border: selected.color === color ? '2px solid var(--color-accent)' : '1px solid var(--color-border)',
                  cursor: 'pointer',
                }}
              />
            ))}
          </div>

          <div style={{ display: 'flex', gap: 'var(--space-2)', overflowX: 'auto' }}>
            {FONT_FAMILIES.map((font) => (
              <button
                key={font}
                type="button"
                onClick={() => editor.updateLayer(selected.id, { fontFamily: font })}
                style={{
                  flex: '0 0 auto',
                  padding: 'var(--space-2) var(--space-3)',
                  borderRadius: 'var(--radius-pill)',
                  fontFamily: font,
                  fontSize: 12,
                  border: selected.fontFamily === font ? '1px solid var(--color-accent)' : '1px solid var(--color-border)',
                  background: selected.fontFamily === font ? 'var(--color-accent)' : 'var(--color-surface-raised)',
                  color: selected.fontFamily === font ? '#fff' : 'var(--color-text-secondary)',
                }}
              >
                {font}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => {
              editor.removeLayer(selected.id);
              setSelectedId(null);
            }}
            style={removeButtonStyle}
          >
            Remove text
          </button>
        </div>
      )}
    </div>
  );
}

const addButtonStyle = {
  background: 'var(--color-accent)',
  color: '#fff',
  border: 'none',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-2) var(--space-3)',
  fontSize: 13,
  fontWeight: 600,
  cursor: 'pointer',
} as const;

const inputStyle = {
  background: 'var(--color-surface-raised)',
  border: '1px solid var(--color-border)',
  borderRadius: 'var(--radius-sm)',
  color: 'var(--color-text-primary)',
  padding: 'var(--space-2) var(--space-3)',
  fontSize: 14,
} as const;

const removeButtonStyle = {
  background: 'transparent',
  border: '1px solid var(--color-danger)',
  color: 'var(--color-danger)',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-2) var(--space-3)',
  fontSize: 12,
  cursor: 'pointer',
  alignSelf: 'flex-start',
} as const;
