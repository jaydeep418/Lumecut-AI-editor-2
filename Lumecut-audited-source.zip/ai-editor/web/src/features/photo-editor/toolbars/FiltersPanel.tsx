import { FILTERS } from '@/features/shared/filters';
import type { UsePhotoEditorResult } from '../usePhotoEditor';

export function FiltersPanel({ editor }: { editor: UsePhotoEditorResult }) {
  return (
    <div
      style={{
        display: 'flex',
        gap: 'var(--space-2)',
        padding: 'var(--space-3) var(--space-4)',
        overflowX: 'auto',
      }}
    >
      {FILTERS.map((filter) => {
        const active = editor.state.filter === filter.id;
        return (
          <button
            key={filter.id}
            type="button"
            onClick={() => editor.setFilter(filter.id)}
            style={{
              flex: '0 0 auto',
              borderRadius: 'var(--radius-pill)',
              padding: 'var(--space-2) var(--space-3)',
              fontSize: 12,
              cursor: 'pointer',
              border: active ? '1px solid var(--color-accent)' : '1px solid var(--color-border)',
              background: active ? 'var(--color-accent)' : 'var(--color-surface-raised)',
              color: active ? '#fff' : 'var(--color-text-secondary)',
            }}
          >
            {filter.label}
          </button>
        );
      })}
    </div>
  );
}
