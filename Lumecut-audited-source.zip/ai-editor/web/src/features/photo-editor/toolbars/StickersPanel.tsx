import { STICKER_EMOJIS } from '../constants';
import type { StickerLayer } from '../types';
import type { UsePhotoEditorResult } from '../usePhotoEditor';

export function StickersPanel({ editor }: { editor: UsePhotoEditorResult }) {
  const stickerLayers = editor.state.layers.filter((l): l is StickerLayer => l.type === 'sticker');

  function addSticker(emoji: string) {
    const layer: StickerLayer = {
      id: crypto.randomUUID(),
      type: 'sticker',
      emoji,
      x: 0.5,
      y: 0.5,
      scale: 1,
      rotationDeg: 0,
    };
    editor.addLayer(layer);
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)', padding: 'var(--space-3) var(--space-4)' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 'var(--space-2)' }}>
        {STICKER_EMOJIS.map((emoji) => (
          <button
            key={emoji}
            type="button"
            onClick={() => addSticker(emoji)}
            style={{
              fontSize: 22,
              background: 'var(--color-surface-raised)',
              border: '1px solid var(--color-border)',
              borderRadius: 'var(--radius-md)',
              padding: 'var(--space-2)',
              cursor: 'pointer',
            }}
          >
            {emoji}
          </button>
        ))}
      </div>

      {stickerLayers.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', margin: 0 }}>
            Drag a placed sticker on the canvas to move it.
          </p>
          <div style={{ display: 'flex', gap: 'var(--space-2)', flexWrap: 'wrap' }}>
            {stickerLayers.map((layer) => (
              <button
                key={layer.id}
                type="button"
                onClick={() => editor.removeLayer(layer.id)}
                title="Remove"
                style={{
                  fontSize: 16,
                  background: 'var(--color-surface-raised)',
                  border: '1px solid var(--color-border)',
                  borderRadius: 'var(--radius-pill)',
                  padding: 'var(--space-1) var(--space-2)',
                  cursor: 'pointer',
                }}
              >
                {layer.emoji} ✕
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
