import { AdjustmentSlider } from './AdjustmentSlider';
import type { Adjustments } from '../types';
import type { UsePhotoEditorResult } from '../usePhotoEditor';

const FIELDS: Array<{ key: keyof Adjustments; label: string; min: number; max: number }> = [
  { key: 'brightness', label: 'Brightness', min: -100, max: 100 },
  { key: 'contrast', label: 'Contrast', min: -100, max: 100 },
  { key: 'saturation', label: 'Saturation', min: -100, max: 100 },
  { key: 'exposure', label: 'Exposure', min: -100, max: 100 },
  { key: 'temperature', label: 'Temperature', min: -100, max: 100 },
  { key: 'sharpness', label: 'Sharpness', min: 0, max: 100 },
  { key: 'blur', label: 'Blur', min: 0, max: 20 },
];

export function AdjustPanel({ editor }: { editor: UsePhotoEditorResult }) {
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 'var(--space-3)',
        padding: 'var(--space-3) var(--space-4)',
        maxHeight: 220,
        overflowY: 'auto',
      }}
    >
      {FIELDS.map((field) => (
        <AdjustmentSlider
          key={field.key}
          label={field.label}
          value={editor.state.adjustments[field.key]}
          min={field.min}
          max={field.max}
          onLiveChange={(value) => editor.previewAdjustment({ [field.key]: value } as Partial<Adjustments>)}
          onCommit={(value) => editor.commitAdjustment({ [field.key]: value } as Partial<Adjustments>)}
        />
      ))}
    </div>
  );
}
