/**
 * Resolution presets are conventionally defined for 16:9 landscape (e.g. "1080p"
 * = 1920x1080), but projects here can be 9:16, 1:1, or 4:5. Rather than hard-code
 * per-orientation dimension tables, each preset stores its LONGEST EDGE pixel
 * count; `computeExportDimensions` below applies that to whichever aspect ratio
 * the project actually is — "1080p" on a 9:16 project exports at 1080x1920 (same
 * pixel-count class, portrait), on a 1:1 project at 1080x1080, and so on. This is
 * the same convention most short-form video editors use.
 */
export interface ResolutionPreset {
  id: '480p' | '720p' | '1080p' | '2K' | '4K' | '8K';
  label: string;
  longestEdge: number;
}

// Longest-edge values below exactly match the specified 16:9 reference
// dimensions (480p=854x480, 720p=1280x720, 1080p=1920x1080, 2K=2560x1440,
// 4K=3840x2160, 8K=7680x4320) — for a 16:9 project, computeExportDimensions
// reproduces those exact pixel values. For other project aspect ratios
// (9:16/1:1/4:5), the same longest edge is applied proportionally.
export const RESOLUTION_PRESETS: ResolutionPreset[] = [
  { id: '480p', label: '480p', longestEdge: 854 },
  { id: '720p', label: '720p', longestEdge: 1280 },
  { id: '1080p', label: '1080p', longestEdge: 1920 },
  { id: '2K', label: '2K', longestEdge: 2560 },
  { id: '4K', label: '4K Ultra HD', longestEdge: 3840 },
  { id: '8K', label: '8K Ultra HD', longestEdge: 7680 },
];

export function computeExportDimensions(longestEdge: number, aspectW: number, aspectH: number): { width: number; height: number } {
  if (aspectW >= aspectH) {
    const width = longestEdge;
    const height = Math.round((longestEdge * aspectH) / aspectW);
    return { width, height: height + (height % 2) }; // even height — friendlier to video encoders
  }
  const height = longestEdge;
  const width = Math.round((longestEdge * aspectW) / aspectH);
  return { width: width + (width % 2), height }; // even width — friendlier to video encoders
}

export const FPS_OPTIONS = [24, 30, 60] as const;
export type FpsOption = (typeof FPS_OPTIONS)[number];

export type QualityPreset = 'standard' | 'high' | 'ultra';

/** jpegQuality is used by photo export (client-side canvas encode). Video
 *  export quality is mapped to an FFmpeg CRF/preset SERVER-SIDE (see
 *  server/src/services/export/exportJobManager.ts's QUALITY_TO_ENCODE) — the
 *  frontend only sends the quality id, not a bitrate, for video. */
export const QUALITY_PRESETS: Array<{ id: QualityPreset; label: string; jpegQuality: number }> = [
  { id: 'standard', label: 'Standard', jpegQuality: 0.75 },
  { id: 'high', label: 'High', jpegQuality: 0.88 },
  { id: 'ultra', label: 'Ultra', jpegQuality: 0.96 },
];

export function getQualityPreset(id: QualityPreset) {
  return QUALITY_PRESETS.find((q) => q.id === id) ?? QUALITY_PRESETS[0];
}
