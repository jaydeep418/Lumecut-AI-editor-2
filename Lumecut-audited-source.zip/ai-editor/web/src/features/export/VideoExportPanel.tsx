import { useRef, useState, type CSSProperties, type ReactNode } from 'react';
import { ASPECT_RATIOS } from '@/constants/aspectRatios';
import type { Project } from '@types/project';
import { FPS_OPTIONS, QUALITY_PRESETS, RESOLUTION_PRESETS, computeExportDimensions, type QualityPreset } from './constants';
import { downloadBlob } from './imageExport';
import { exportVideo, type VideoExportHandle, type VideoExportProgress } from './videoExport';
import type { VideoEditState } from '../video-editor/types';

interface VideoExportPanelProps {
  editState: VideoEditState;
  project: Project;
  onClose: () => void;
}

export function VideoExportPanel({ editState, project, onClose }: VideoExportPanelProps) {
  const [resolutionId, setResolutionId] = useState<(typeof RESOLUTION_PRESETS)[number]['id']>('1080p');
  const [fps, setFps] = useState<(typeof FPS_OPTIONS)[number]>(30);
  const [quality, setQuality] = useState<QualityPreset>('high');
  const [progress, setProgress] = useState<VideoExportProgress>({ status: 'uploading', progressRatio: 0 });
  const [phase, setPhase] = useState<'idle' | 'exporting'>('idle');
  const handleRef = useRef<VideoExportHandle | null>(null);

  const aspect = ASPECT_RATIOS.find((r) => r.id === project.aspectRatio) ?? { w: 9, h: 16 };
  const preset = RESOLUTION_PRESETS.find((p) => p.id === resolutionId)!;
  const dimensions = computeExportDimensions(preset.longestEdge, aspect.w, aspect.h);

  function handleStart() {
    setPhase('exporting');
    setProgress({ status: 'uploading', progressRatio: 0 });
    handleRef.current = exportVideo(editState, { width: dimensions.width, height: dimensions.height, fps, quality }, setProgress);
  }

  function handleCancel() {
    handleRef.current?.cancel();
  }

  function handleDownload() {
    if (!progress.resultBlob) return;
    downloadBlob(progress.resultBlob, `${sanitizeFilename(project.name)}_${resolutionId}.mp4`);
  }

  function handleReset() {
    setPhase('idle');
    setProgress({ status: 'uploading', progressRatio: 0 });
  }

  return (
    <div style={overlayStyle} role="dialog" aria-modal="true" aria-label="Export video">
      <div style={panelStyle}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ fontSize: 16, margin: 0 }}>Export Video</h2>
          <button onClick={onClose} style={closeButtonStyle} aria-label="Close">
            ✕
          </button>
        </div>

        {phase === 'idle' ? (
          <>
            <Section label="Resolution">
              <div style={chipRowStyle}>
                {RESOLUTION_PRESETS.map((p) => (
                  <Chip key={p.id} label={p.label} active={p.id === resolutionId} onClick={() => setResolutionId(p.id)} />
                ))}
              </div>
              <p style={hintStyle}>
                {dimensions.width} × {dimensions.height}px
              </p>
            </Section>

            <Section label="Frame rate">
              <div style={chipRowStyle}>
                {FPS_OPTIONS.map((f) => (
                  <Chip key={f} label={`${f} fps`} active={f === fps} onClick={() => setFps(f)} />
                ))}
              </div>
            </Section>

            <Section label="Quality">
              <div style={chipRowStyle}>
                {QUALITY_PRESETS.map((q) => (
                  <Chip key={q.id} label={q.label} active={q.id === quality} onClick={() => setQuality(q.id)} />
                ))}
              </div>
            </Section>

            <p style={hintStyle}>
              Exported server-side with FFmpeg as a real MP4, with audio when your clips have
              it. Fade transitions render as true crossfades. Text/sticker timing may drift
              slightly right after a transition, and emoji stickers depend on server font
              support — see the export docs for details.
            </p>

            <button onClick={handleStart} style={primaryButtonStyle}>
              Export
            </button>
          </>
        ) : (
          <ExportProgressView
            progress={progress}
            onCancel={handleCancel}
            onDownload={handleDownload}
            onReset={handleReset}
          />
        )}
      </div>
    </div>
  );
}

function ExportProgressView({
  progress,
  onCancel,
  onDownload,
  onReset,
}: {
  progress: VideoExportProgress;
  onCancel: () => void;
  onDownload: () => void;
  onReset: () => void;
}) {
  const isActive =
    progress.status === 'uploading' ||
    progress.status === 'queued' ||
    progress.status === 'probing' ||
    progress.status === 'processing';

  if (isActive) {
    const label =
      progress.status === 'uploading'
        ? 'Uploading clips…'
        : progress.status === 'queued'
          ? 'Queued…'
          : progress.status === 'probing'
            ? 'Preparing…'
            : `Encoding… ${Math.round(progress.progressRatio * 100)}%`;
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
        <p style={{ margin: 0, fontSize: 13 }}>{label}</p>
        <div style={progressTrackStyle}>
          <div style={{ ...progressFillStyle, width: `${progress.progressRatio * 100}%` }} />
        </div>
        <button onClick={onCancel} style={secondaryButtonStyle}>
          Cancel
        </button>
      </div>
    );
  }

  if (progress.status === 'done') {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
        <p style={{ margin: 0, fontSize: 13, color: 'var(--color-success)' }}>✓ Export ready</p>
        <button onClick={onDownload} style={primaryButtonStyle}>
          Download
        </button>
        <button onClick={onReset} style={secondaryButtonStyle}>
          Export another version
        </button>
      </div>
    );
  }

  // 'error' or 'cancelled'
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
      <p
        style={{
          margin: 0,
          fontSize: 13,
          color: progress.status === 'error' ? 'var(--color-danger)' : 'var(--color-text-secondary)',
        }}
      >
        {progress.message ?? (progress.status === 'error' ? 'Export failed.' : 'Export cancelled.')}
      </p>
      <button onClick={onReset} style={secondaryButtonStyle}>
        Try again
      </button>
    </div>
  );
}

function Section({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', margin: '0 0 6px' }}>{label}</p>
      {children}
    </div>
  );
}

function Chip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        borderRadius: 'var(--radius-pill)',
        padding: 'var(--space-2) var(--space-3)',
        fontSize: 12,
        cursor: 'pointer',
        border: active ? '1px solid var(--color-accent)' : '1px solid var(--color-border)',
        background: active ? 'var(--color-accent)' : 'var(--color-surface-raised)',
        color: active ? '#fff' : 'var(--color-text-secondary)',
      }}
    >
      {label}
    </button>
  );
}

function sanitizeFilename(name: string): string {
  return name.trim().replace(/[^a-z0-9_-]+/gi, '_') || 'export';
}

const overlayStyle: CSSProperties = {
  position: 'fixed',
  inset: 0,
  background: 'rgba(0, 0, 0, 0.6)',
  display: 'flex',
  alignItems: 'flex-end',
  justifyContent: 'center',
  zIndex: 200,
};

const panelStyle: CSSProperties = {
  width: '100%',
  maxWidth: 480,
  background: 'var(--color-surface)',
  borderTopLeftRadius: 'var(--radius-lg)',
  borderTopRightRadius: 'var(--radius-lg)',
  padding: 'var(--space-5) var(--space-4)',
  paddingBottom: 'calc(var(--space-5) + env(safe-area-inset-bottom))',
  display: 'flex',
  flexDirection: 'column',
  gap: 'var(--space-4)',
  maxHeight: '80vh',
  overflowY: 'auto',
};

const closeButtonStyle: CSSProperties = {
  background: 'none',
  border: 'none',
  color: 'var(--color-text-secondary)',
  fontSize: 16,
  cursor: 'pointer',
};

const chipRowStyle: CSSProperties = { display: 'flex', gap: 'var(--space-2)', flexWrap: 'wrap' };

const hintStyle: CSSProperties = { fontSize: 11, color: 'var(--color-text-secondary)', margin: '6px 0 0' };

const progressTrackStyle: CSSProperties = {
  height: 8,
  borderRadius: 'var(--radius-pill)',
  background: 'var(--color-surface-raised)',
  overflow: 'hidden',
};

const progressFillStyle: CSSProperties = {
  height: '100%',
  background: 'var(--color-accent)',
  transition: 'width 0.15s linear',
};

const primaryButtonStyle: CSSProperties = {
  background: 'var(--color-accent)',
  border: 'none',
  color: '#fff',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-3)',
  fontSize: 14,
  fontWeight: 600,
  cursor: 'pointer',
};

const secondaryButtonStyle: CSSProperties = {
  background: 'var(--color-surface-raised)',
  border: '1px solid var(--color-border)',
  color: 'var(--color-text-primary)',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-3)',
  fontSize: 13,
  cursor: 'pointer',
};
