import { useState, type CSSProperties, type ReactNode } from 'react';
import { RESOLUTION_PRESETS, QUALITY_PRESETS, computeExportDimensions, type QualityPreset } from './constants';
import { downloadBlob, exportPhotoToBlob, getEffectiveAspectRatio, type ImageExportFormat } from './imageExport';
import type { LoadedImage } from '../photo-editor/canvasRenderer';
import type { PhotoEditState } from '../photo-editor/types';
import type { Project } from '@types/project';

interface PhotoExportPanelProps {
  image: LoadedImage;
  state: PhotoEditState;
  project: Project;
  onClose: () => void;
}

type ExportPhase = 'idle' | 'rendering' | 'done' | 'error';

export function PhotoExportPanel({ image, state, project, onClose }: PhotoExportPanelProps) {
  const [resolutionId, setResolutionId] = useState<(typeof RESOLUTION_PRESETS)[number]['id']>('1080p');
  const [format, setFormat] = useState<ImageExportFormat>('png');
  const [quality, setQuality] = useState<QualityPreset>('high');
  const [phase, setPhase] = useState<ExportPhase>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [resultBlob, setResultBlob] = useState<Blob | null>(null);

  const aspect = getEffectiveAspectRatio(image, state);
  const preset = RESOLUTION_PRESETS.find((p) => p.id === resolutionId)!;
  const dimensions = computeExportDimensions(preset.longestEdge, aspect.w, aspect.h);
  const qualityPreset = QUALITY_PRESETS.find((q) => q.id === quality)!;

  async function handleExport() {
    setPhase('rendering');
    setErrorMessage(null);
    try {
      const blob = await exportPhotoToBlob(image, state, {
        width: dimensions.width,
        height: dimensions.height,
        format,
        quality: qualityPreset.jpegQuality,
      });
      setResultBlob(blob);
      setPhase('done');
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Export failed.');
      setPhase('error');
    }
  }

  function handleDownload() {
    if (!resultBlob) return;
    const ext = format === 'png' ? 'png' : 'jpg';
    downloadBlob(resultBlob, `${sanitizeFilename(project.name)}_${resolutionId}.${ext}`);
  }

  return (
    <div style={overlayStyle} role="dialog" aria-modal="true" aria-label="Export photo">
      <div style={panelStyle}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ fontSize: 16, margin: 0 }}>Export Photo</h2>
          <button onClick={onClose} style={closeButtonStyle} aria-label="Close">
            ✕
          </button>
        </div>

        {phase === 'idle' || phase === 'error' ? (
          <>
            <Section label="Resolution">
              <div style={chipRowStyle}>
                {RESOLUTION_PRESETS.map((p) => (
                  <Chip key={p.id} label={p.label} active={p.id === resolutionId} onClick={() => setResolutionId(p.id)} />
                ))}
              </div>
              <p style={hintStyle}>
                {dimensions.width} × {dimensions.height}px
              </p>
            </Section>

            <Section label="Format">
              <div style={chipRowStyle}>
                <Chip label="PNG (lossless)" active={format === 'png'} onClick={() => setFormat('png')} />
                <Chip label="JPEG" active={format === 'jpeg'} onClick={() => setFormat('jpeg')} />
              </div>
            </Section>

            {format === 'jpeg' && (
              <Section label="Quality">
                <div style={chipRowStyle}>
                  {QUALITY_PRESETS.map((q) => (
                    <Chip key={q.id} label={q.label} active={q.id === quality} onClick={() => setQuality(q.id)} />
                  ))}
                </div>
              </Section>
            )}

            {phase === 'error' && errorMessage && <p style={errorTextStyle}>{errorMessage}</p>}

            <button onClick={handleExport} style={primaryButtonStyle}>
              Export
            </button>
          </>
        ) : phase === 'rendering' ? (
          <div style={centerMessageStyle}>
            <p style={{ margin: 0 }}>Rendering at {dimensions.width}×{dimensions.height}…</p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
            <p style={{ margin: 0, fontSize: 13, color: 'var(--color-success)' }}>
              ✓ Export ready — {dimensions.width}×{dimensions.height}
            </p>
            <button onClick={handleDownload} style={primaryButtonStyle}>
              Download
            </button>
            <button onClick={() => setPhase('idle')} style={secondaryButtonStyle}>
              Export another version
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function Section({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', margin: '0 0 6px' }}>{label}</p>
      {children}
    </div>
  );
}

function Chip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        borderRadius: 'var(--radius-pill)',
        padding: 'var(--space-2) var(--space-3)',
        fontSize: 12,
        cursor: 'pointer',
        border: active ? '1px solid var(--color-accent)' : '1px solid var(--color-border)',
        background: active ? 'var(--color-accent)' : 'var(--color-surface-raised)',
        color: active ? '#fff' : 'var(--color-text-secondary)',
      }}
    >
      {label}
    </button>
  );
}

function sanitizeFilename(name: string): string {
  return name.trim().replace(/[^a-z0-9_-]+/gi, '_') || 'export';
}

const overlayStyle: CSSProperties = {
  position: 'fixed',
  inset: 0,
  background: 'rgba(0, 0, 0, 0.6)',
  display: 'flex',
  alignItems: 'flex-end',
  justifyContent: 'center',
  zIndex: 200,
};

const panelStyle: CSSProperties = {
  width: '100%',
  maxWidth: 480,
  background: 'var(--color-surface)',
  borderTopLeftRadius: 'var(--radius-lg)',
  borderTopRightRadius: 'var(--radius-lg)',
  padding: 'var(--space-5) var(--space-4)',
  paddingBottom: 'calc(var(--space-5) + env(safe-area-inset-bottom))',
  display: 'flex',
  flexDirection: 'column',
  gap: 'var(--space-4)',
  maxHeight: '80vh',
  overflowY: 'auto',
};

const closeButtonStyle: CSSProperties = {
  background: 'none',
  border: 'none',
  color: 'var(--color-text-secondary)',
  fontSize: 16,
  cursor: 'pointer',
};

const chipRowStyle: CSSProperties = { display: 'flex', gap: 'var(--space-2)', flexWrap: 'wrap' };

const hintStyle: CSSProperties = { fontSize: 11, color: 'var(--color-text-secondary)', margin: '6px 0 0' };

const errorTextStyle: CSSProperties = { fontSize: 12, color: 'var(--color-danger)', margin: 0 };

const centerMessageStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  padding: 'var(--space-5) 0',
  color: 'var(--color-text-secondary)',
  fontSize: 13,
};

const primaryButtonStyle: CSSProperties = {
  background: 'var(--color-accent)',
  border: 'none',
  color: '#fff',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-3)',
  fontSize: 14,
  fontWeight: 600,
  cursor: 'pointer',
};

const secondaryButtonStyle: CSSProperties = {
  background: 'var(--color-surface-raised)',
  border: '1px solid var(--color-border)',
  color: 'var(--color-text-primary)',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-3)',
  fontSize: 13,
  cursor: 'pointer',
};
