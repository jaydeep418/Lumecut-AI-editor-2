# Export feature

**Photo export** (unchanged since its original delivery — still real,
client-side, working): `imageExport.ts` renders the photo's edit state at the
true requested resolution via canvas (bypassing the editor's smaller working-
resolution cap) and encodes to PNG/JPEG. `PhotoExportPanel.tsx` is the UI.
`getEffectiveAspectRatio()` reads the CURRENT crop/rotation state rather than
the project's original `aspectRatio` field, since the crop tool can change it.

**Video export** (Stage 6 upgrade — now a real server-side FFmpeg pipeline,
replacing an earlier browser-`MediaRecorder`-based approach entirely):
`videoExport.ts` uploads each clip's actual bytes (deduped by source) plus a
JSON manifest describing the EDL to the backend's `/api/export/video`, polls
job progress (real FFmpeg progress, not simulated), and downloads the
resulting MP4. `VideoExportPanel.tsx` is the UI — resolution (480p–8K, per the
LONGEST EDGE convention in `constants.ts` so portrait/square projects size
correctly)/FPS/quality pickers, a real progress bar, cancel, and download.

See `server/src/services/export/README.md` and `server/EXPORT_SETUP.md` for
the actual FFmpeg pipeline: real trims, speed, reverse, rotate/flip, filters,
real `xfade`/`acrossfade` crossfade transitions, and text/sticker overlays —
plus the documented limitations (emoji stickers confirmed to render as
nothing with the default font; overlay timing can drift slightly after a
transition) and exactly what was and wasn't tested against a real FFmpeg
binary (most of the core pipeline was; the actual Express server process and
browser frontend flow weren't, for lack of a runnable environment here).

## Constants

`constants.ts` — resolution presets (480p–8K) stored as a LONGEST EDGE pixel
count rather than fixed width×height, since projects can be 9:16/1:1/4:5, not
just 16:9 — `computeExportDimensions()` applies a preset to whichever aspect
ratio the project actually is. FPS options (24/30/60). Quality presets:
`jpegQuality` is used by photo export (client-side); video quality maps to an
FFmpeg CRF/preset SERVER-SIDE (`server/src/services/export/exportJobManager.ts`)
— the frontend only sends the quality id for video, not a bitrate.
