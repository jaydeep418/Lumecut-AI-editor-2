import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ProjectsProvider } from '@/state/ProjectsContext';
import { BottomNav } from '@components/BottomNav';
import Home from '@/pages/Home';
import Projects from '@/pages/Projects';
import AiToolsStub from '@/pages/AiToolsStub';
import ProfileStub from '@/pages/ProfileStub';
import PremiumStub from '@/pages/PremiumStub';
import EditorPlaceholder from '@/pages/EditorPlaceholder';

/**
 * Stage 2: routing + navigation shell + project creation.
 *
 * The editor route intentionally hides the bottom nav (it needs the full screen,
 * per spec §12) while every other route keeps it visible for quick navigation.
 */
export default function App() {
  return (
    <BrowserRouter>
      <ProjectsProvider>
        <Routes>
          <Route path="/editor/:projectId" element={<EditorPlaceholder />} />
          <Route path="*" element={<AppShell />} />
        </Routes>
      </ProjectsProvider>
    </BrowserRouter>
  );
}

function AppShell() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div style={{ flex: 1, overflowY: 'auto', minHeight: 0 }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/ai-tools" element={<AiToolsStub />} />
          <Route path="/profile" element={<ProfileStub />} />
          <Route path="/premium" element={<PremiumStub />} />
          <Route path="*" element={<Home />} />
        </Routes>
      </div>
      <BottomNav />
    </div>
  );
}
