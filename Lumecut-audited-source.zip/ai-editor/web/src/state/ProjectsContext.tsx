import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import type { AspectRatioId, Project, ProjectKind } from '@types/project';
import type { VideoEditState } from '@/features/video-editor/types';

interface ProjectsContextValue {
  projects: Project[];
  createProject: (file: File, kind: ProjectKind, name: string, aspectRatio: AspectRatioId) => Project;
  getProject: (id: string) => Project | undefined;
  deleteProject: (id: string) => void;
  /** Stage 4 "draft saving": the video editor's non-destructive edit state (clips,
   *  trims, effects — see features/video-editor/types.ts) lives here so it survives
   *  navigating away from and back to the editor within the same session. Still
   *  in-memory only, same Stage 2 rule as everything else in this file — Stage 9
   *  replaces the internals with real persistence without changing these call sites. */
  getVideoEditState: (projectId: string) => VideoEditState | undefined;
  setVideoEditState: (projectId: string, state: VideoEditState) => void;
}

const ProjectsContext = createContext<ProjectsContextValue | null>(null);

/**
 * Stage 2 scope: projects live only in memory for the current tab session. This is
 * intentional, not an oversight — Stage 9 swaps this provider's internals for real
 * backend-backed persistence (cloud projects) without changing the `useProjects()`
 * call sites in Home/Projects/Editor.
 */
export function ProjectsProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [videoEditStates, setVideoEditStates] = useState<Record<string, VideoEditState>>({});

  const createProject = useCallback(
    (file: File, kind: ProjectKind, name: string, aspectRatio: AspectRatioId): Project => {
      const project: Project = {
        id: crypto.randomUUID(),
        name: name.trim() || 'Untitled project',
        kind,
        aspectRatio,
        previewUrl: URL.createObjectURL(file),
        createdAt: Date.now(),
      };
      setProjects((prev) => [project, ...prev]);
      return project;
    },
    []
  );

  const getProject = useCallback(
    (id: string) => projects.find((p) => p.id === id),
    [projects]
  );

  const deleteProject = useCallback((id: string) => {
    setProjects((prev) => {
      const toDelete = prev.find((p) => p.id === id);
      // Release the object URL's underlying memory — otherwise every deleted
      // project's source file stays pinned in memory for the rest of the tab's life.
      if (toDelete) {
        URL.revokeObjectURL(toDelete.previewUrl);
      }
      return prev.filter((p) => p.id !== id);
    });
    setVideoEditStates((prev) => {
      const state = prev[id];
      if (state) {
        // A video project can have imported additional clips beyond its original
        // file — each holds its own object URL that needs releasing too. Safe to
        // revoke immediately here (unlike inside useVideoEditor's own mutations —
        // see that file's URL lifecycle comment): by the time a project can be
        // deleted, its editor (if ever opened) has already unmounted — this app
        // has no route where the editor and the Projects list are both mounted at
        // once — so any clip removed mid-session was already revoked by that
        // editor's own unmount cleanup, and its local undo/redo stack is gone.
        // Only clips still present in this FINAL saved draft remain to revoke.
        for (const clip of state.clips) {
          URL.revokeObjectURL(clip.sourceUrl);
        }
      }
      const next = { ...prev };
      delete next[id];
      return next;
    });
  }, []);

  const getVideoEditState = useCallback(
    (projectId: string) => videoEditStates[projectId],
    [videoEditStates]
  );

  const setVideoEditState = useCallback((projectId: string, nextState: VideoEditState) => {
    setVideoEditStates((prev) => ({ ...prev, [projectId]: nextState }));
  }, []);

  const value = useMemo(
    () => ({ projects, createProject, getProject, deleteProject, getVideoEditState, setVideoEditState }),
    [projects, createProject, getProject, deleteProject, getVideoEditState, setVideoEditState]
  );

  return <ProjectsContext.Provider value={value}>{children}</ProjectsContext.Provider>;
}

export function useProjects(): ProjectsContextValue {
  const ctx = useContext(ProjectsContext);
  if (!ctx) throw new Error('useProjects must be used within <ProjectsProvider>');
  return ctx;
}
