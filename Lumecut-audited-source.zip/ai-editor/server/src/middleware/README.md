# Middleware

- `usageLimiter.ts` (Stage 5 — implemented) — in-memory per-anonymous-session
  request cap on all `/api/ai/*` routes. Explicitly temporary/non-tamper-resistant
  since there's no authentication yet; Stage 8/9 replaces it with real per-account
  entitlements.
- `validateUpload.ts` (Stage 5 — implemented) — `multer`-based image upload
  validation (size cap, MIME-type allowlist, in-memory storage) used by the AI
  photo routes.

Still to come:

- `requireAuth` — verifies the user's session token (Stage 9)
- `requireEntitlement(feature)` — checks the user's plan allows a given action
  (Stage 8), replacing `usageLimiter`'s demo-grade counter
