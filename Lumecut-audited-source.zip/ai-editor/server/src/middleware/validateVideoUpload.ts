import multer from 'multer';
import path from 'path';
import type { Request } from 'express';

/** 2GB per file — generous for a single source clip at up to 8K. Streamed
 *  straight to disk (never buffered in memory) via multer's disk storage. */
const MAX_VIDEO_BYTES = 2 * 1024 * 1024 * 1024;

/**
 * Requires `req.exportTempDir` to already be set (see api/export.ts, which
 * creates the job — and therefore its temp dir — before this middleware runs).
 * Each uploaded file is named after its multipart field name (e.g.
 * "source_0"), which the frontend controls and which becomes the `sourceKey`
 * referenced by the manifest — see services/export/types.ts.
 */
export function createVideoUpload(tempDir: string) {
  return multer({
    storage: multer.diskStorage({
      destination: (_req, _file, cb) => cb(null, tempDir),
      filename: (_req, file, cb) => cb(null, sanitizeFieldName(file.fieldname) + guessExtension(file.originalname)),
    }),
    limits: { fileSize: MAX_VIDEO_BYTES },
    fileFilter: (_req: Request, file, callback) => {
      if (!file.mimetype.startsWith('video/')) {
        callback(new Error('Only video uploads are supported for export sources'));
        return;
      }
      callback(null, true);
    },
  }).any();
}

function sanitizeFieldName(fieldname: string): string {
  return fieldname.replace(/[^a-zA-Z0-9_-]/g, '_');
}

function guessExtension(originalName: string): string {
  const ext = path.extname(originalName);
  return /^\.[a-zA-Z0-9]{2,5}$/.test(ext) ? ext : '.mp4';
}
