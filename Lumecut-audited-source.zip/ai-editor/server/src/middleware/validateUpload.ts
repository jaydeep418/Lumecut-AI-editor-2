import multer from 'multer';

/** 10MB — generous enough for a phone photo, small enough to keep an in-memory
 *  buffer per request reasonable (Stage 5 has no disk/cloud storage yet — every
 *  upload lives only in RAM for the duration of one request). remove.bg's own
 *  documented limit is 12MB, so this stays comfortably under it too. */
const MAX_IMAGE_BYTES = 10 * 1024 * 1024;

/** First-pass filter using the client-supplied MIME type — cheap, but this value
 *  (like a filename extension) is client-controlled metadata, not verified
 *  content. `sniffImageMimeType` below is the real, content-based check, run
 *  after the buffer is available. */
export const uploadImage = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_IMAGE_BYTES },
  fileFilter: (_req, file, callback) => {
    if (!file.mimetype.startsWith('image/')) {
      callback(new Error('Only image uploads are supported'));
      return;
    }
    callback(null, true);
  },
}).single('image');

/**
 * Verifies the UPLOADED BYTES actually look like one of these image formats, by
 * checking each format's magic-number file signature — not the client-supplied
 * MIME type or filename, both of which are just metadata a client controls.
 * Returns the sniffed MIME type, or null if the content doesn't match any of
 * them (in which case the route should reject the upload).
 */
export function sniffImageMimeType(buffer: Buffer): string | null {
  if (buffer.length >= 8 && buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) {
    return 'image/png';
  }
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return 'image/jpeg';
  }
  if (
    buffer.length >= 12 &&
    buffer.subarray(0, 4).toString('ascii') === 'RIFF' &&
    buffer.subarray(8, 12).toString('ascii') === 'WEBP'
  ) {
    return 'image/webp';
  }
  if (buffer.length >= 6 && ['GIF87a', 'GIF89a'].includes(buffer.subarray(0, 6).toString('ascii'))) {
    return 'image/gif';
  }
  return null;
}
