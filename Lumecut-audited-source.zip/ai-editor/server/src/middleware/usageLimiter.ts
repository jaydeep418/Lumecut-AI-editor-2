import type { NextFunction, Request, Response } from 'express';

/**
 * Stage 5 scope: there's no authentication yet (Stage 9), so "usage limits" can
 * only be approximate — keyed by an anonymous session id the frontend generates
 * and persists in localStorage (see web/src/services/sessionId.ts), sent as the
 * X-Session-Id header. This is intentionally simple and NOT tamper-resistant (a
 * client could send a new id to reset their count) — Stage 8/9 replaces this with
 * real per-account entitlements enforced server-side against authenticated users.
 * In-memory only: resets on server restart, does not scale past a single process.
 */
const FREE_TIER_REQUEST_LIMIT = 5;
const usageBySession = new Map<string, number>();

export function usageLimiter(req: Request, res: Response, next: NextFunction): void {
  const sessionId = req.header('x-session-id') ?? 'anonymous';
  const used = usageBySession.get(sessionId) ?? 0;

  if (used >= FREE_TIER_REQUEST_LIMIT) {
    res.status(429).json({
      status: 'error',
      message: `Insufficient AI credits for this demo session (limit ${FREE_TIER_REQUEST_LIMIT}). Stage 8/9 adds real plans and credits.`,
    });
    return;
  }

  usageBySession.set(sessionId, used + 1);
  next();
}
