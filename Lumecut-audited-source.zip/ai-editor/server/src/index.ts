import express from 'express';
import cors from 'cors';
import { env, assertRequiredEnv } from './config/env.js';
import { healthRouter } from './api/health.js';
import { aiRouter } from './api/ai.js';
import { exportRouter } from './api/export.js';
import { isFfmpegAvailable, isFfprobeAvailable } from './services/export/ffmpegBinary.js';
import { sweepStaleJobs } from './services/export/exportJobManager.js';

assertRequiredEnv();

const app = express();

app.use(cors({ origin: env.CORS_ORIGIN }));
app.use(express.json({ limit: '1mb' })); // AI image uploads and video export uploads use multipart (see middleware/), not JSON, so this limit doesn't apply to them

app.use('/api', healthRouter);
app.use('/api/ai', aiRouter);
app.use('/api/export', exportRouter);

// Safety net for export jobs a client never polled/downloaded/cancelled to
// completion (closed tab, dropped connection) — see exportJobManager.ts.
setInterval(() => sweepStaleJobs(), 5 * 60 * 1000);

app.listen(env.PORT, () => {
  // eslint-disable-next-line no-console
  console.log(`Lumecut server listening on http://localhost:${env.PORT} (${env.NODE_ENV})`);
  // eslint-disable-next-line no-console
  console.log(
    `[export] FFmpeg: ${isFfmpegAvailable() ? 'available' : 'NOT FOUND — video export will fail, see server/EXPORT_SETUP.md'} | ffprobe: ${isFfprobeAvailable() ? 'available' : 'NOT FOUND'}`
  );
});
