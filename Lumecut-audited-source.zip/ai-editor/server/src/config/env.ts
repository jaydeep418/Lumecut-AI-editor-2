import 'dotenv/config';

/**
 * Single source of truth for backend environment variables.
 *
 * Every server-side secret (AI provider keys, payment secret keys, ad mediation
 * secrets, database credentials) is read ONLY here and passed explicitly into the
 * service that needs it — never imported ad-hoc from process.env elsewhere. That
 * keeps every secret's usage auditable to one file per concern.
 *
 * Stage 1 only requires PORT. Everything else is declared now (undefined is fine)
 * so later stages don't need to redesign this file, only fill values in.
 */
export const env = {
  // --- Stage 1 ---
  PORT: Number(process.env.PORT ?? 8787),
  NODE_ENV: process.env.NODE_ENV ?? 'development',
  CORS_ORIGIN: process.env.CORS_ORIGIN ?? 'http://localhost:5173',

  // --- Stage 5 (AI providers — each is a genuinely different, real, documented
  // service; there is no single generic "AI_PROVIDER" contract. See
  // services/ai/index.ts for how these combine, and .env.example for exactly
  // what's required and where to get each key). All optional: any capability
  // whose key is unset falls back to the dev mock independently. ---
  REMOVE_BG_API_KEY: process.env.REMOVE_BG_API_KEY, // Background Removal — remove.bg
  DEEPAI_API_KEY: process.env.DEEPAI_API_KEY, // Photo Enhancer — DeepAI torch-srgan
  OPENAI_API_KEY: process.env.OPENAI_API_KEY, // Script Generator — OpenAI Chat Completions
  OPENAI_MODEL: process.env.OPENAI_MODEL, // optional override, defaults to gpt-4o-mini in code

  // --- Stage 6 (real FFmpeg export pipeline — see services/export/) ---
  // FFmpeg/ffprobe are NOT bundled with this app — they must be installed on
  // whatever machine runs the server (or point these at a downloaded static
  // build). See server/EXPORT_SETUP.md for exact install steps and the
  // licensing note for static-binary distribution.
  FFMPEG_PATH: process.env.FFMPEG_PATH ?? 'ffmpeg', // resolved via PATH if not absolute
  FFPROBE_PATH: process.env.FFPROBE_PATH ?? 'ffprobe',
  // Optional: a TrueType font FFmpeg's drawtext filter can use for text/sticker
  // overlays. Falls back to a common Linux path in code if unset; if THAT path
  // doesn't exist either on your machine, text overlays will fail to render —
  // set this explicitly. See EXPORT_SETUP.md.
  FFMPEG_FONT_PATH: process.env.FFMPEG_FONT_PATH,
  // Optional override for where per-job temp files are written; defaults to
  // the OS temp dir (os.tmpdir()) in code.
  EXPORT_TMP_DIR: process.env.EXPORT_TMP_DIR,

  // --- Stage 7 (Ads — server-side ad mediation secrets, if the provider needs any) ---
  AD_MEDIATION_SERVER_KEY: process.env.AD_MEDIATION_SERVER_KEY,

  // --- Stage 8 (Payments) ---
  BILLING_PROVIDER: process.env.BILLING_PROVIDER, // e.g. "stripe" | "revenuecat"
  BILLING_SECRET_KEY: process.env.BILLING_SECRET_KEY,
  BILLING_WEBHOOK_SECRET: process.env.BILLING_WEBHOOK_SECRET,

  // --- Stage 9 (Auth/DB/Storage) ---
  DATABASE_URL: process.env.DATABASE_URL,
  AUTH_PROVIDER: process.env.AUTH_PROVIDER, // e.g. "firebase" | "supabase"
  AUTH_SERVICE_ACCOUNT_JSON: process.env.AUTH_SERVICE_ACCOUNT_JSON,
  STORAGE_BUCKET: process.env.STORAGE_BUCKET,
} as const;

/**
 * Fails fast at boot if a variable required for the CURRENT stage is missing.
 * Later stages will extend `required` as each feature area goes live — this avoids
 * a service silently running with an unset secret and failing confusingly later.
 */
export function assertRequiredEnv(): void {
  const required: Array<keyof typeof env> = ['PORT'];

  const missing = required.filter((key) => env[key] === undefined || env[key] === '');
  if (missing.length > 0) {
    throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
  }
}
