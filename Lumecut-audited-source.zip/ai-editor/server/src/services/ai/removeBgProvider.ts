import type { BackgroundRemovalProvider, ProviderImageResult } from './types.js';

const REMOVE_BG_ENDPOINT = 'https://api.remove.bg/v1.0/removebg';

/**
 * Real adapter for remove.bg's documented API (https://www.remove.bg/api):
 *   POST https://api.remove.bg/v1.0/removebg
 *   Header: X-Api-Key: <key>
 *   Body: multipart/form-data, field "image_file" = the image, field "size" = "auto"
 *   Success: HTTP 200, binary image bytes, Content-Type: image/png or image/jpeg
 *   Error: HTTP 400/402/403/429/500, JSON body { errors: [{ title, code, detail? }] }
 */
export class RemoveBgProvider implements BackgroundRemovalProvider {
  constructor(
    private readonly apiKey: string,
    private readonly timeoutMs = 30_000
  ) {}

  async removeBackground(imageBuffer: Buffer, mimeType: string): Promise<ProviderImageResult> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const form = new FormData();
      form.append('image_file', new Blob([imageBuffer], { type: mimeType }), 'image');
      form.append('size', 'auto');

      const response = await fetch(REMOVE_BG_ENDPOINT, {
        method: 'POST',
        headers: { 'X-Api-Key': this.apiKey },
        body: form,
        signal: controller.signal,
      });

      if (!response.ok) {
        throw new Error(await describeRemoveBgError(response));
      }

      const resultMimeType = response.headers.get('content-type') ?? 'image/png';
      const resultBuffer = Buffer.from(await response.arrayBuffer());
      return { resultBuffer, resultMimeType };
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') {
        throw new Error('Background removal timed out. Please try again.');
      }
      throw err;
    } finally {
      clearTimeout(timeout);
    }
  }
}

/** Reads remove.bg's documented JSON error shape without ever touching the
 *  request we sent (so there is no path by which our own API key could end up
 *  in the message returned to the frontend). */
async function describeRemoveBgError(response: Response): Promise<string> {
  try {
    const data = (await response.json()) as { errors?: Array<{ title?: string }> };
    const title = data.errors?.[0]?.title;
    if (title) return `Background removal failed: ${title}`;
  } catch {
    // Body wasn't JSON (or was empty) — fall through to a generic message.
  }
  return `Background removal failed (provider returned HTTP ${response.status})`;
}
