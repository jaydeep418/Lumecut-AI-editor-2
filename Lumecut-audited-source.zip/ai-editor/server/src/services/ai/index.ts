import { env } from '../../config/env.js';
import { DeepAiProvider } from './deepAiProvider.js';
import { MockAiProvider } from './mockProvider.js';
import { OpenAiScriptProvider } from './openAiScriptProvider.js';
import { RemoveBgProvider } from './removeBgProvider.js';
import type { AiProvider } from './types.js';

/**
 * Assembles the single `AiProvider` every route depends on from whichever real,
 * per-capability adapters are configured — falling back to MockAiProvider
 * independently for any capability whose key is missing. This means, e.g.,
 * configuring only REMOVE_BG_API_KEY gives you real background removal while
 * photo enhancement and script generation stay on the mock, with no code change
 * needed anywhere else.
 *
 * Never logs a key value — only whether each capability ended up real or mock.
 */
function createProvider(): AiProvider {
  const mock = new MockAiProvider();

  const backgroundRemoval = env.REMOVE_BG_API_KEY ? new RemoveBgProvider(env.REMOVE_BG_API_KEY) : mock;
  const photoEnhance = env.DEEPAI_API_KEY ? new DeepAiProvider(env.DEEPAI_API_KEY) : mock;
  const script = env.OPENAI_API_KEY ? new OpenAiScriptProvider(env.OPENAI_API_KEY, env.OPENAI_MODEL) : mock;

  // eslint-disable-next-line no-console
  console.log(
    `[ai] Background Removal: ${env.REMOVE_BG_API_KEY ? 'real (remove.bg)' : 'mock'} | ` +
      `Photo Enhance: ${env.DEEPAI_API_KEY ? 'real (DeepAI)' : 'mock'} | ` +
      `Script Generator: ${env.OPENAI_API_KEY ? 'real (OpenAI)' : 'mock'}`
  );

  return {
    removeBackground: (imageBuffer, mimeType) => backgroundRemoval.removeBackground(imageBuffer, mimeType),
    enhancePhoto: (imageBuffer, mimeType) => photoEnhance.enhancePhoto(imageBuffer, mimeType),
    generateScript: (prompt) => script.generateScript(prompt),
  };
}

/** Singleton, selected once at server startup. Routes in api/ai.ts import ONLY
 *  this — never a concrete provider class — so the selection logic above is the
 *  one place that changes when a capability's provider is added/swapped. */
export const aiProvider: AiProvider = createProvider();
