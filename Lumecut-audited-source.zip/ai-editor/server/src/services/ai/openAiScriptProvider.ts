import type { ProviderTextResult, ScriptProvider } from './types.js';

const OPENAI_ENDPOINT = 'https://api.openai.com/v1/chat/completions';
const DEFAULT_MODEL = 'gpt-4o-mini';
const SYSTEM_PROMPT =
  'You write short, punchy short-form video scripts: a 1-2 sentence hook, 2-3 body beats, and a clear call to action. Keep the whole thing under 150 words.';

/**
 * Real adapter for OpenAI's documented Chat Completions API
 * (https://platform.openai.com/docs/api-reference/chat):
 *   POST https://api.openai.com/v1/chat/completions
 *   Header: Authorization: Bearer <key>
 *   Body: { model, messages: [{ role, content }, ...], temperature }
 *   Success: HTTP 200, JSON { choices: [{ message: { content } }] }
 *   Error: non-200, JSON { error: { message, type, param, code } }
 */
export class OpenAiScriptProvider implements ScriptProvider {
  constructor(
    private readonly apiKey: string,
    private readonly model: string = DEFAULT_MODEL,
    private readonly timeoutMs = 30_000
  ) {}

  async generateScript(prompt: string): Promise<ProviderTextResult> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const response = await fetch(OPENAI_ENDPOINT, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify({
          model: this.model,
          messages: [
            { role: 'system', content: SYSTEM_PROMPT },
            { role: 'user', content: prompt.trim() || 'A short video about something interesting.' },
          ],
          temperature: 0.8,
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        throw new Error(await describeOpenAiError(response));
      }

      const data = (await response.json()) as { choices?: Array<{ message?: { content?: string } }> };
      const text = data.choices?.[0]?.message?.content;
      if (!text) {
        throw new Error('Script generation failed: provider response did not include any text.');
      }
      return { text };
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') {
        throw new Error('Script generation timed out. Please try again.');
      }
      throw err;
    } finally {
      clearTimeout(timeout);
    }
  }
}

async function describeOpenAiError(response: Response): Promise<string> {
  try {
    const data = (await response.json()) as { error?: { message?: string } };
    if (data.error?.message) return `Script generation failed: ${data.error.message}`;
  } catch {
    // Body wasn't JSON (or was empty) — fall through to a generic message.
  }
  return `Script generation failed (provider returned HTTP ${response.status})`;
}
