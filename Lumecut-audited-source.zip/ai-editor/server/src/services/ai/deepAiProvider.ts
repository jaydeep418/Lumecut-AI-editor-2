import type { PhotoEnhanceProvider, ProviderImageResult } from './types.js';

const DEEPAI_ENDPOINT = 'https://api.deepai.org/api/torch-srgan';

/**
 * Real adapter for DeepAI's documented Super Resolution API (https://deepai.org/docs,
 * model "torch-srgan" — upscales and sharpens, i.e. genuine enhancement, not a
 * passthrough):
 *   POST https://api.deepai.org/api/torch-srgan
 *   Header: api-key: <key>
 *   Body: multipart/form-data, field "image" = the image
 *   Success: HTTP 200, JSON { id, output_url } — output_url must be fetched
 *     separately to get the actual result bytes (DeepAI returns a link, not
 *     inline bytes)
 *   Error: non-200, JSON body shape varies by failure type; handled generically
 *     below since DeepAI doesn't document one fixed error schema
 */
export class DeepAiProvider implements PhotoEnhanceProvider {
  constructor(
    private readonly apiKey: string,
    private readonly timeoutMs = 60_000 // two round trips (submit + download result)
  ) {}

  async enhancePhoto(imageBuffer: Buffer, mimeType: string): Promise<ProviderImageResult> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const form = new FormData();
      form.append('image', new Blob([imageBuffer], { type: mimeType }), 'image');

      const submitResponse = await fetch(DEEPAI_ENDPOINT, {
        method: 'POST',
        headers: { 'api-key': this.apiKey },
        body: form,
        signal: controller.signal,
      });

      if (!submitResponse.ok) {
        throw new Error(await describeDeepAiError(submitResponse));
      }

      const submitData = (await submitResponse.json()) as { output_url?: string };
      if (!submitData.output_url) {
        throw new Error('Photo enhancement failed: provider response did not include a result.');
      }

      const resultResponse = await fetch(submitData.output_url, { signal: controller.signal });
      if (!resultResponse.ok) {
        throw new Error(`Photo enhancement failed: could not retrieve the result (HTTP ${resultResponse.status}).`);
      }

      const resultMimeType = resultResponse.headers.get('content-type') ?? 'image/jpeg';
      const resultBuffer = Buffer.from(await resultResponse.arrayBuffer());
      return { resultBuffer, resultMimeType };
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') {
        throw new Error('Photo enhancement timed out. Please try again.');
      }
      throw err;
    } finally {
      clearTimeout(timeout);
    }
  }
}

async function describeDeepAiError(response: Response): Promise<string> {
  try {
    const data = (await response.json()) as { status?: string; err?: string };
    const detail = data.status ?? data.err;
    if (detail) return `Photo enhancement failed: ${detail}`;
  } catch {
    // Body wasn't JSON (or was empty) — fall through to a generic message.
  }
  return `Photo enhancement failed (provider returned HTTP ${response.status})`;
}
