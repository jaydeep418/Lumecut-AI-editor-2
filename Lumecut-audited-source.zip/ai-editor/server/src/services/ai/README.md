# AI service layer (Stage 5 — real provider integrations)

Three genuinely different, independently-documented real providers, one per
capability — there is no single generic "AI provider API" here, by design (see
`types.ts`'s header comment for why the interface is split into three small
capability interfaces).

- `types.ts` — `BackgroundRemovalProvider` / `PhotoEnhanceProvider` /
  `ScriptProvider`, combined into `AiProvider`. Routes in `api/ai.ts` call only
  this — never a concrete provider class.
- `removeBgProvider.ts` — **Background Removal**, real adapter for
  [remove.bg](https://www.remove.bg/api)'s documented API: `POST
  https://api.remove.bg/v1.0/removebg`, `X-Api-Key` header, multipart
  `image_file` field, returns binary image bytes on success or a JSON
  `{ errors: [...] }` body on failure.
- `deepAiProvider.ts` — **Photo Enhancer**, real adapter for
  [DeepAI](https://deepai.org/docs)'s `torch-srgan` (Super Resolution) model:
  `POST https://api.deepai.org/api/torch-srgan`, `api-key` header, multipart
  `image` field, returns `{ output_url }` which is then fetched separately for
  the actual result bytes. This genuinely upscales/sharpens — not a passthrough.
- `openAiScriptProvider.ts` — **Script Generator**, real adapter for
  [OpenAI Chat Completions](https://platform.openai.com/docs/api-reference/chat):
  `POST https://api.openai.com/v1/chat/completions`, `Authorization: Bearer`
  header, JSON body, returns `{ choices: [{ message: { content } }] }`.
- `mockProvider.ts` — `MockAiProvider`. No real processing, no network calls,
  clearly labeled in every response. Used per-capability as a fallback.
- `index.ts` — assembles the combined `AiProvider` from whichever of the three
  real adapters have a configured key, falling back to the mock independently
  per capability (e.g. configuring only `REMOVE_BG_API_KEY` gives real
  background removal while the other two stay mocked). Logs which mode each
  capability ended up in at startup — never a key value.

## Configuration

See `server/.env.example` for exactly which environment variables each provider
needs and where to obtain a key. All three are optional and independent.

## Scope: 3 of ~11 tools, end-to-end

Background Removal, Photo Enhancer, and Script Generator are real, end-to-end.
The remaining AI tools from Stages 3/4's panels stay on the frontend stub with a
message naming which of these three to follow as a template for wiring up a new
one: a new provider adapter file here (implementing that provider's own real,
documented API — never an invented generic contract), one line in `index.ts`,
one route in `api/ai.ts`, one case in the matching frontend `Backend*AiService`.

## Usage limiting

`middleware/usageLimiter.ts` applies an in-memory, per-anonymous-session request
cap to every route here — there's no authentication yet (Stage 9), so this is an
explicitly temporary, non-tamper-resistant stand-in. Real per-account entitlements
land with Stages 8/9.

## Security notes

- Uploaded images are validated by actual file content (magic-number signature
  sniffing in `middleware/validateUpload.ts`), not just the client-supplied MIME
  type or filename — both are client-controlled metadata, not verified content.
- Every provider call has a request timeout (`AbortController`), surfaced to the
  frontend as a clear "timed out" message rather than hanging indefinitely.
- Provider credentials are read only in `config/env.ts` and passed directly into
  the one adapter file that uses each — never logged, and the frontend never
  sees or holds any of them.
- Error messages relayed to the frontend come from each adapter's own sanitized
  `describe*Error()` helper, which reads only the PROVIDER's response — never our
  own outgoing request — so there is no path by which our API key could leak
  into a message shown to the user.
