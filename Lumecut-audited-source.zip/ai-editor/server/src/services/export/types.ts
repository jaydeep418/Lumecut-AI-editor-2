import type { ChildProcess } from 'child_process';

/**
 * JSON-serializable description of the edit decisions the frontend sends
 * alongside the uploaded clip files. Mirrors web/src/features/video-editor/
 * types.ts's VideoEditState, but with `sourceUrl` (a browser-only blob: URL,
 * meaningless server-side) replaced by `sourceKey` — a reference to one of the
 * uploaded files in the same multipart request. Clips that share a source file
 * (e.g. a split clip's two halves) share the same `sourceKey` so the file is
 * uploaded and decoded by FFmpeg only once.
 */

export type FilterId = 'none' | 'grayscale' | 'sepia' | 'vintage' | 'cool' | 'warm' | 'highContrast' | 'fade';

export interface ExportClipManifest {
  id: string;
  sourceKey: string;
  inPoint: number;
  outPoint: number;
  speed: number;
  reversed: boolean;
  volume: number;
  muted: boolean;
  rotationDeg: 0 | 90 | 180 | 270;
  flipHorizontal: boolean;
  flipVertical: boolean;
  filter: FilterId;
}

export interface ExportTransitionManifest {
  afterClipId: string;
  type: 'fade';
  duration: number;
}

interface ExportOverlayBase {
  startTime: number;
  endTime: number;
  x: number;
  y: number;
  rotationDeg: number;
}

export interface ExportTextOverlayManifest extends ExportOverlayBase {
  type: 'text';
  text: string;
  fontSize: number;
  color: string;
  fontFamily: string;
}

export interface ExportStickerOverlayManifest extends ExportOverlayBase {
  type: 'sticker';
  emoji: string;
  scale: number;
}

export type ExportOverlayManifest = ExportTextOverlayManifest | ExportStickerOverlayManifest;

export type ExportQuality = 'standard' | 'high' | 'ultra';

export interface ExportRequestManifest {
  clips: ExportClipManifest[];
  transitions: ExportTransitionManifest[];
  overlays: ExportOverlayManifest[];
  width: number;
  height: number;
  fps: 24 | 30 | 60;
  quality: ExportQuality;
}

export type ExportJobStatus = 'queued' | 'probing' | 'processing' | 'done' | 'error' | 'cancelled';

export interface ExportJobState {
  id: string;
  status: ExportJobStatus;
  progressRatio: number;
  errorMessage?: string;
  tempDir: string;
  outputPath?: string;
  process?: ChildProcess;
  createdAt: number;
  /** Total expected output duration in seconds — used to turn FFmpeg's
   *  out_time_ms progress readout into a 0..1 ratio. */
  expectedDurationSeconds: number;
}
