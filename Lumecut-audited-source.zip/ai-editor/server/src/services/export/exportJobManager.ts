import { spawn } from 'child_process';
import { randomUUID } from 'crypto';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { env } from '../../config/env.js';
import { buildFilterGraph } from './buildFilterGraph.js';
import { getFfmpegPath } from './ffmpegBinary.js';
import type { ExportJobState, ExportQuality, ExportRequestManifest } from './types.js';

const jobs = new Map<string, ExportJobState>();

const QUALITY_TO_ENCODE: Record<ExportQuality, { crf: number; preset: string }> = {
  standard: { crf: 28, preset: 'veryfast' },
  high: { crf: 23, preset: 'fast' },
  ultra: { crf: 18, preset: 'slow' },
};

// A font drawtext (used for both text and sticker overlays) can render with.
// Most Linux distros ship DejaVu Sans at this path; override via
// FFMPEG_FONT_PATH if your environment differs (see EXPORT_SETUP.md).
const DEFAULT_FONT_PATH = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf';

function getTempRoot(): string {
  return env.EXPORT_TMP_DIR || os.tmpdir();
}

export function createExportJob(): ExportJobState {
  const id = randomUUID();
  const tempDir = path.join(getTempRoot(), `lumecut-export-${id}`);
  fs.mkdirSync(tempDir, { recursive: true });

  const job: ExportJobState = {
    id,
    status: 'queued',
    progressRatio: 0,
    tempDir,
    createdAt: Date.now(),
    expectedDurationSeconds: 0,
  };
  jobs.set(id, job);
  return job;
}

export function getExportJob(id: string): ExportJobState | undefined {
  return jobs.get(id);
}

export function cleanupExportJob(id: string): void {
  const job = jobs.get(id);
  if (!job) return;
  fs.rm(job.tempDir, { recursive: true, force: true }, () => {});
  jobs.delete(id);
}

export function cancelExportJob(id: string): boolean {
  const job = jobs.get(id);
  if (!job) return false;
  if (job.status === 'done' || job.status === 'error' || job.status === 'cancelled') return false;
  job.process?.kill('SIGKILL');
  job.status = 'cancelled';
  cleanupExportJob(id);
  return true;
}

/** Safety net: if a client starts an export and never polls/downloads/cancels
 *  it (tab closed, network dropped), don't leak temp files forever. */
export function sweepStaleJobs(maxAgeMs = 30 * 60 * 1000): void {
  const now = Date.now();
  for (const [id, job] of jobs) {
    if (now - job.createdAt > maxAgeMs) {
      job.process?.kill('SIGKILL');
      cleanupExportJob(id);
    }
  }
}

/**
 * Starts the actual FFmpeg process for a prepared job (files already uploaded
 * to job.tempDir). Runs asynchronously — updates job.status/progressRatio as
 * it goes; callers poll getExportJob(id) for status.
 */
export function runExportJob(
  job: ExportJobState,
  manifest: ExportRequestManifest,
  filePathBySourceKey: Map<string, string>
): void {
  job.status = 'probing';

  const inputIndexBySourceKey = new Map<string, number>();
  const inputPaths: string[] = [];
  let nextIndex = 0;
  for (const sourceKey of filePathBySourceKey.keys()) {
    inputIndexBySourceKey.set(sourceKey, nextIndex++);
    inputPaths.push(filePathBySourceKey.get(sourceKey)!);
  }

  const fontPath = env.FFMPEG_FONT_PATH || DEFAULT_FONT_PATH;

  buildFilterGraph(manifest, inputIndexBySourceKey, filePathBySourceKey, fontPath)
    .then((graph) => {
      job.expectedDurationSeconds = graph.totalDurationSeconds;
      job.status = 'processing';

      const outputPath = path.join(job.tempDir, 'output.mp4');
      job.outputPath = outputPath;

      const { crf, preset } = QUALITY_TO_ENCODE[manifest.quality];

      const args: string[] = ['-y'];
      for (const inputPath of inputPaths) {
        args.push('-i', inputPath);
      }
      args.push('-filter_complex', graph.filterComplex);
      args.push('-map', `[${graph.finalVideoLabel}]`);
      if (graph.hasAnyRealAudio && graph.finalAudioLabel) {
        args.push('-map', `[${graph.finalAudioLabel}]`);
      }
      args.push('-c:v', 'libx264', '-preset', preset, '-crf', String(crf), '-pix_fmt', 'yuv420p');
      if (graph.hasAnyRealAudio) {
        args.push('-c:a', 'aac', '-b:a', '192k');
      } else {
        args.push('-an');
      }
      args.push('-movflags', '+faststart');
      args.push('-progress', 'pipe:1', '-nostats');
      args.push(outputPath);

      const child = spawn(getFfmpegPath(), args);
      job.process = child;

      let stdoutBuffer = '';
      child.stdout.on('data', (chunk: Buffer) => {
        stdoutBuffer += chunk.toString();
        const lines = stdoutBuffer.split('\n');
        stdoutBuffer = lines.pop() ?? '';
        for (const line of lines) {
          const match = line.match(/^out_time_ms=(\d+)/);
          if (match && job.expectedDurationSeconds > 0) {
            const seconds = Number(match[1]) / 1_000_000;
            job.progressRatio = Math.max(0, Math.min(1, seconds / job.expectedDurationSeconds));
          }
        }
      });

      let stderrTail = '';
      child.stderr.on('data', (chunk: Buffer) => {
        // Keep only a bounded tail for a useful error message — never log or
        // surface the full verbose output, and this never contains request
        // bodies/keys, only FFmpeg's own diagnostic text.
        stderrTail = (stderrTail + chunk.toString()).slice(-4000);
      });

      child.on('error', (err) => {
        job.status = 'error';
        job.errorMessage = `Could not start FFmpeg: ${err.message}. Is it installed? See server/EXPORT_SETUP.md.`;
      });

      child.on('close', (code) => {
        if (job.status === 'cancelled') return; // already handled by cancelExportJob
        if (job.status === 'error' && job.errorMessage) return; // already handled by the 'error' event above (e.g. binary not found) — don't overwrite with a less specific message
        if (code === 0 && fs.existsSync(outputPath)) {
          job.status = 'done';
          job.progressRatio = 1;
        } else {
          job.status = 'error';
          job.errorMessage = summarizeFfmpegFailure(stderrTail, code);
        }
      });
    })
    .catch((err) => {
      job.status = 'error';
      job.errorMessage = err instanceof Error ? err.message : 'Export failed while preparing the render.';
    });
}

/** Reduces FFmpeg's verbose stderr to a short, safe message — never echoes
 *  input file paths (which live under a per-job temp dir, not sensitive, but
 *  needlessly detailed) or anything from our own request construction. */
function summarizeFfmpegFailure(stderrTail: string, exitCode: number | null): string {
  const lastLine = stderrTail
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean)
    .slice(-1)[0];
  return lastLine
    ? `Export failed (FFmpeg exited with code ${exitCode}): ${lastLine}`
    : `Export failed (FFmpeg exited with code ${exitCode}).`;
}
