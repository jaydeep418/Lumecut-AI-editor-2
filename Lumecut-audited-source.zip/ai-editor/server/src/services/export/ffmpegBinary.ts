import { spawnSync } from 'child_process';
import { env } from '../../config/env.js';

/**
 * FFmpeg/ffprobe are external system dependencies — NOT an npm package bundled
 * with this app. See server/EXPORT_SETUP.md for exact install instructions and
 * why a bundled static binary (e.g. the `ffmpeg-static` npm package) was
 * deliberately NOT used here (its bundled builds are typically compiled with
 * GPL components like libx264, which carries real distribution/licensing
 * obligations for whoever ships the resulting app — documented rather than
 * silently taken on).
 */

let cachedFfmpegAvailable: boolean | null = null;
let cachedFfprobeAvailable: boolean | null = null;

export function getFfmpegPath(): string {
  return env.FFMPEG_PATH;
}

export function getFfprobePath(): string {
  return env.FFPROBE_PATH;
}

function checkBinary(path: string): boolean {
  try {
    const result = spawnSync(path, ['-version'], { timeout: 5000 });
    return result.status === 0;
  } catch {
    return false;
  }
}

export function isFfmpegAvailable(): boolean {
  if (cachedFfmpegAvailable === null) cachedFfmpegAvailable = checkBinary(getFfmpegPath());
  return cachedFfmpegAvailable;
}

export function isFfprobeAvailable(): boolean {
  if (cachedFfprobeAvailable === null) cachedFfprobeAvailable = checkBinary(getFfprobePath());
  return cachedFfprobeAvailable;
}
