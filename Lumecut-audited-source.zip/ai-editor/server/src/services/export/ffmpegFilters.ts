import type { FilterId } from './types.js';

/**
 * Best-effort mappings from our editor's filter presets to real FFmpeg filters.
 * These approximate the LOOK of the browser preview's CSS-based filters (see
 * web/src/features/shared/filters.ts) — exact pixel parity is NOT guaranteed,
 * since FFmpeg's filter primitives and the browser's CSS `filter` property use
 * different underlying math. Every one of these is a real, documented FFmpeg
 * filter (eq, colorchannelmixer, colorbalance, hue, curves) — none are stubs.
 */
export function getFfmpegFilterExpression(filter: FilterId): string | null {
  switch (filter) {
    case 'none':
      return null;
    case 'grayscale':
      return 'hue=s=0';
    case 'sepia':
      // Standard sepia color-channel-mixing matrix.
      return 'colorchannelmixer=.393:.769:.189:0:.349:.686:.168:0:.272:.534:.131:0';
    case 'vintage':
      // FFmpeg's `curves` filter ships a built-in "vintage" tone-curve preset.
      return 'curves=preset=vintage,eq=saturation=0.85';
    case 'cool':
      return 'colorbalance=rs=-0.15:gs=0.0:bs=0.15,eq=saturation=1.1';
    case 'warm':
      return 'colorbalance=rs=0.15:gs=0.05:bs=-0.15,eq=saturation=1.1';
    case 'highContrast':
      return 'eq=contrast=1.4:saturation=1.15';
    case 'fade':
      return 'eq=contrast=0.85:saturation=0.85:brightness=0.08';
    default:
      return null;
  }
}
