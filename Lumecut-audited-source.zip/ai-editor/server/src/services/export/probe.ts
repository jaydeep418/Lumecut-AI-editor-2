import { spawn } from 'child_process';
import { getFfprobePath } from './ffmpegBinary.js';

/**
 * Some source videos have no audio track at all — referencing `{input}:a` in an
 * FFmpeg filter graph when that stream doesn't exist fails the whole export, not
 * just that one clip. This checks first via `ffprobe`, so the filter-graph
 * builder can substitute a generated silent track for such sources instead.
 */
export function probeHasAudioStream(filePath: string): Promise<boolean> {
  return new Promise((resolve) => {
    const args = ['-v', 'error', '-select_streams', 'a', '-show_entries', 'stream=index', '-of', 'csv=p=0', filePath];
    const child = spawn(getFfprobePath(), args);

    let stdout = '';
    child.stdout.on('data', (chunk) => {
      stdout += chunk.toString();
    });

    child.on('error', () => resolve(false)); // ffprobe missing/unusable — treat as "no audio", safest fallback
    child.on('close', (code) => {
      resolve(code === 0 && stdout.trim().length > 0);
    });
  });
}
