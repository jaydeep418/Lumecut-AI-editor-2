import { probeHasAudioStream } from './probe.js';
import { getFfmpegFilterExpression } from './ffmpegFilters.js';
import type { ExportOverlayManifest, ExportRequestManifest } from './types.js';

export interface BuiltGraph {
  filterComplex: string;
  finalVideoLabel: string;
  /** Null when hasAnyRealAudio is false — the graph does not generate ANY
   *  audio filter chain in that case (not even silence), since an unmapped
   *  filter output makes FFmpeg reject the whole graph — confirmed via a live
   *  FFmpeg run. */
  finalAudioLabel: string | null;
  /** Whether ANY source clip actually had real audio. If false, the caller
   *  should omit audio from the final output entirely rather than muxing in a
   *  fabricated silent track for content that never had sound. */
  hasAnyRealAudio: boolean;
  totalDurationSeconds: number;
}

/** atempo only accepts 0.5..2.0 per filter instance — chain multiple instances
 *  to reach speeds outside that range (our UI allows 0.25x–4x). */
function buildAtempoChain(speed: number): string[] {
  if (speed <= 0) return ['atempo=1.0'];
  const filters: string[] = [];
  let remaining = speed;
  while (remaining > 2.0) {
    filters.push('atempo=2.0');
    remaining /= 2.0;
  }
  while (remaining < 0.5) {
    filters.push('atempo=0.5');
    remaining /= 0.5;
  }
  filters.push(`atempo=${remaining.toFixed(4)}`);
  return filters;
}

function buildRotateFlipFilters(rotationDeg: 0 | 90 | 180 | 270, flipHorizontal: boolean, flipVertical: boolean): string[] {
  const filters: string[] = [];
  if (rotationDeg === 90) filters.push('transpose=1');
  else if (rotationDeg === 180) filters.push('transpose=1', 'transpose=1');
  else if (rotationDeg === 270) filters.push('transpose=2');
  if (flipHorizontal) filters.push('hflip');
  if (flipVertical) filters.push('vflip');
  return filters;
}

/** Escapes a value for safe interpolation inside a SINGLE-QUOTED FFmpeg filter
 *  option (drawtext's text=/fontfile=, in particular — every call site below
 *  wraps the result in single quotes). Single-quoting already protects colons
 *  and most other filter-graph-special characters, so those do NOT need
 *  backslash-escaping here — verified against a live FFmpeg binary that doing
 *  so is unnecessary. A literal single quote is the one real exception: a
 *  naive backslash-escape (`\'`) inside a single-quoted value corrupts
 *  FFmpeg's quote-nesting for the REST of the filter string (confirmed with a
 *  live test — see PROJECT_PLAN.md), so it needs the POSIX-shell-style
 *  close-quote/escaped-quote/reopen-quote workaround instead. `%` is escaped
 *  separately since drawtext's `text` independently treats it as the start of
 *  an expansion sequence even inside quotes. */
function escapeFilterValue(value: string): string {
  return value
    .replace(/\\/g, '\\\\')
    .replace(/'/g, `'\\''`)
    .replace(/%/g, '\\%');
}

function buildOverlayFilter(overlay: ExportOverlayManifest, width: number, height: number, fontPath: string): string {
  // Commas inside `between(...)` must be escaped — FFmpeg's filtergraph parser
  // splits on commas to find chained filters at a level "above" a single
  // option's own quoting, so an unescaped comma here breaks the entire graph
  // (verified against a live FFmpeg binary; this was a real bug, not a
  // hypothetical one — see PROJECT_PLAN.md).
  const enableExpr = `between(t\\,${overlay.startTime.toFixed(3)}\\,${overlay.endTime.toFixed(3)})`;
  const escapedFont = escapeFilterValue(fontPath);
  // Our model stores x/y as normalized CENTER positions; drawtext's x/y are the
  // top-left corner of the rendered text box, so shift back by half its size.
  const x = `(${overlay.x}*${width}-text_w/2)`;
  const y = `(${overlay.y}*${height}-text_h/2)`;

  if (overlay.type === 'text') {
    const fontSizePx = Math.max(1, Math.round((overlay.fontSize / 1000) * width));
    const color = overlay.color.startsWith('#') ? `0x${overlay.color.slice(1)}` : overlay.color;
    return `drawtext=fontfile='${escapedFont}':text='${escapeFilterValue(overlay.text)}':fontsize=${fontSizePx}:fontcolor=${color}:x=${x}:y=${y}:enable='${enableExpr}'`;
  }

  // Sticker (emoji): best-effort. Whether this actually renders as the emoji
  // glyph (vs. an empty box) depends entirely on whether the server's font
  // supports color emoji — most don't by default. See EXPORT_SETUP.md.
  const size = Math.max(1, Math.round((overlay.scale * width) / 8));
  return `drawtext=fontfile='${escapedFont}':text='${escapeFilterValue(overlay.emoji)}':fontsize=${size}:x=${x}:y=${y}:enable='${enableExpr}'`;
}

/**
 * Builds the full filter_complex graph string plus the labels the caller maps
 * to the output. See this module's and EXPORT_SETUP.md's notes for the two
 * documented approximations: (1) overlay timing uses the pre-transition
 * timeline and can drift slightly after a crossfade boundary; (2) filter/
 * transition visuals are FFmpeg-native approximations of the browser preview's
 * CSS-based look, not pixel-identical to it.
 */
export async function buildFilterGraph(
  manifest: ExportRequestManifest,
  inputIndexBySourceKey: Map<string, number>,
  filePathBySourceKey: Map<string, string>,
  fontPath: string
): Promise<BuiltGraph> {
  const { clips, transitions, overlays, width, height, fps } = manifest;
  if (clips.length === 0) {
    throw new Error('Nothing to export — no clips in the timeline.');
  }

  const hasAudioBySourceKey = new Map<string, boolean>();
  for (const [sourceKey, filePath] of filePathBySourceKey) {
    hasAudioBySourceKey.set(sourceKey, await probeHasAudioStream(filePath));
  }
  const hasAnyRealAudio = Array.from(hasAudioBySourceKey.values()).some(Boolean);

  const segments: string[] = [];
  const clipDurations: number[] = [];

  clips.forEach((clip, i) => {
    const inputIdx = inputIndexBySourceKey.get(clip.sourceKey);
    if (inputIdx === undefined) {
      throw new Error('Export failed: an uploaded file was missing for one of the clips.');
    }

    const clipDuration = Math.max(0.01, (clip.outPoint - clip.inPoint) / clip.speed);
    clipDurations.push(clipDuration);

    // --- video chain for this clip ---
    const videoFilters: string[] = [`trim=start=${clip.inPoint}:end=${clip.outPoint}`, 'setpts=PTS-STARTPTS'];
    if (clip.reversed) videoFilters.push('reverse');
    if (clip.speed !== 1) videoFilters.push(`setpts=PTS/${clip.speed}`);
    videoFilters.push(...buildRotateFlipFilters(clip.rotationDeg, clip.flipHorizontal, clip.flipVertical));
    const colorFilter = getFfmpegFilterExpression(clip.filter);
    if (colorFilter) videoFilters.push(colorFilter);
    // "Cover" fit — matches the live preview's compositor (videoCompositor.ts).
    videoFilters.push(`scale=${width}:${height}:force_original_aspect_ratio=increase`, `crop=${width}:${height}`);
    videoFilters.push(`fps=${fps}`);
    segments.push(`[${inputIdx}:v]${videoFilters.join(',')}[v${i}]`);

    // --- audio chain for this clip (only when SOME source actually has audio —
    // see the hasAnyRealAudio check below for why) ---
    if (hasAnyRealAudio) {
      const sourceHasAudio = hasAudioBySourceKey.get(clip.sourceKey) ?? false;
      if (clip.muted || !sourceHasAudio) {
        // A muted clip, or one whose source never had audio, still needs a
        // stream of the right duration so concat/acrossfade downstream see a
        // consistent structure — generated silence, normalized to the same
        // format real audio segments use (see below).
        segments.push(`anullsrc=channel_layout=stereo:sample_rate=48000:d=${clipDuration.toFixed(3)}[a${i}]`);
      } else {
        const audioFilters: string[] = [`atrim=start=${clip.inPoint}:end=${clip.outPoint}`, 'asetpts=PTS-STARTPTS'];
        if (clip.reversed) audioFilters.push('areverse');
        if (clip.speed !== 1) audioFilters.push(...buildAtempoChain(clip.speed));
        audioFilters.push(`volume=${Math.max(0, Math.min(1, clip.volume))}`);
        // Normalize format — concat/acrossfade require matching sample
        // rate/channel layout across every segment being combined, and
        // different source files can differ here.
        audioFilters.push('aformat=sample_rates=48000:channel_layouts=stereo');
        segments.push(`[${inputIdx}:a]${audioFilters.join(',')}[a${i}]`);
      }
    }
  });

  // --- chain clips together: real xfade+acrossfade at a fade transition, concat elsewhere ---
  // Audio is chained ONLY when hasAnyRealAudio — see the bug note above: FFmpeg
  // rejects a filter_complex graph that defines a filter output (like an
  // all-silence anullsrc chain) which is never mapped to the output. Confirmed
  // via a live FFmpeg run (a source with genuinely no audio anywhere) — this
  // isn't a hypothetical edge case.
  let runningVideo = 'v0';
  let runningAudio = 'a0';
  let cumulativeDuration = clipDurations[0];
  const chainLines: string[] = [];

  for (let i = 1; i < clips.length; i++) {
    const transition = transitions.find((t) => t.afterClipId === clips[i - 1].id && t.type === 'fade');
    const clipDuration = clipDurations[i];
    const nextVideo = `vx${i}`;
    const nextAudio = `ax${i}`;

    if (transition && transition.duration > 0) {
      // A crossfade can never exceed either side's own duration, minus a
      // small safety margin.
      const maxDuration = Math.max(0.05, Math.min(cumulativeDuration, clipDuration) - 0.05);
      const td = Math.min(transition.duration, maxDuration);
      const offset = Math.max(0, cumulativeDuration - td);
      chainLines.push(`[${runningVideo}][v${i}]xfade=transition=fade:duration=${td.toFixed(3)}:offset=${offset.toFixed(3)}[${nextVideo}]`);
      if (hasAnyRealAudio) {
        chainLines.push(`[${runningAudio}][a${i}]acrossfade=d=${td.toFixed(3)}[${nextAudio}]`);
      }
      cumulativeDuration = cumulativeDuration + clipDuration - td;
    } else if (hasAnyRealAudio) {
      chainLines.push(`[${runningVideo}][${runningAudio}][v${i}][a${i}]concat=n=2:v=1:a=1[${nextVideo}][${nextAudio}]`);
      cumulativeDuration = cumulativeDuration + clipDuration;
    } else {
      chainLines.push(`[${runningVideo}][v${i}]concat=n=2:v=1:a=0[${nextVideo}]`);
      cumulativeDuration = cumulativeDuration + clipDuration;
    }
    runningVideo = nextVideo;
    if (hasAnyRealAudio) runningAudio = nextAudio;
  }

  // --- overlays, applied to the final merged video stream ---
  // DOCUMENTED LIMITATION: overlay start/end times are the ORIGINAL,
  // pre-transition-compression timeline values. Each xfade shortens the
  // timeline by its duration from that point forward, but overlay timing is
  // NOT re-adjusted for that shift here — an overlay scheduled after a
  // transition boundary may appear slightly earlier than intended, by however
  // many seconds of total crossfade overlap preceded it. See EXPORT_SETUP.md.
  let finalVideoLabel = runningVideo;
  if (overlays.length > 0) {
    overlays.forEach((overlay, idx) => {
      const inLabel = idx === 0 ? runningVideo : `vo${idx - 1}`;
      const outLabel = `vo${idx}`;
      chainLines.push(`[${inLabel}]${buildOverlayFilter(overlay, width, height, fontPath)}[${outLabel}]`);
    });
    finalVideoLabel = `vo${overlays.length - 1}`;
  }

  return {
    filterComplex: [...segments, ...chainLines].join(';\n'),
    finalVideoLabel,
    finalAudioLabel: hasAnyRealAudio ? runningAudio : null,
    hasAnyRealAudio,
    totalDurationSeconds: cumulativeDuration,
  };
}
