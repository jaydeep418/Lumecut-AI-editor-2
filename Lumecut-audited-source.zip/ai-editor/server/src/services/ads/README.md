# Ads config service

Populated in Stage 7. In most ad networks (AdMob included) the SDK runs client-side —
this backend layer's job is serving remote ad configuration (which placements are
live, rewarded-ad credit values, frequency caps) so those can change without an app
release, and validating reward callbacks server-side to prevent client-side reward
tampering.
